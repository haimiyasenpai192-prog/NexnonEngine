package com.nexnon.engine

import android.os.SystemClock
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable fun Sp(h: Int) = Spacer(Modifier.height(h.dp))
@Composable fun Label(s: String) = T(s, 12, MUT, true)

@Composable
fun Chip(text: String, bg: Color = Color(0x1FFFFFFF)) =
    Text(text, color = TX, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1,
        modifier = Modifier.background(bg, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 4.dp))

@Composable
fun Tile(label: String, value: String, mod: Modifier) =
    Column(mod.background(Color(0x14FFFFFF), RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 10.dp)) {
        T(label, 11, MUT, maxLines = 1); T(value, 17, TX, true, maxLines = 1)
    }

@Composable
fun Bar(frac: Float, h: Int = 6, colors: List<Color> = listOf(MUT, TX)) =
    Box(Modifier.fillMaxWidth().height(h.dp).clip(RoundedCornerShape(50)).background(Color(0x1FFFFFFF))) {
        Box(Modifier.fillMaxWidth(frac.coerceIn(0.02f, 1f)).fillMaxHeight().background(Brush.horizontalGradient(colors)))
    }

@Composable
fun Hero() {
    Box(Modifier.fillMaxWidth()
        .background(Brush.linearGradient(listOf(Color(0xFFFF7A2F), Color(0xFFD6246E), Color(0xFF2B1466))))
        .drawBehind {
            var x = -size.height
            while (x < size.width) {
                drawLine(Color.White.copy(alpha = 0.07f), Offset(x, size.height), Offset(x + size.height * 0.47f, 0f), 2.dp.toPx())
                x += 18.dp.toPx()
            }
        }.padding(horizontal = 20.dp, vertical = 36.dp)) {
        Text("NEXNON\nENGINE", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp, lineHeight = 36.sp)
    }
}

@Composable
fun DeviceCard() {
    val dev by produceState(DevInfo()) { value = withContext(Dispatchers.IO) { loadDevInfo() } }
    val up by produceState(0L to 0L) { while (true) { value = SystemClock.elapsedRealtime() to SystemClock.uptimeMillis(); delay(1000) } }
    val awake = up.first
    val sleep = (up.first - up.second).coerceAtLeast(0L)
    val pct = if (awake > 0) (sleep * 100 / awake).toInt() else 0
    val poco = dev.brand.equals("POCO", true)
    Card2 {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(Modifier.size(56.dp).background(if (poco) Color(0xFFFFD500) else Color(0xFF101116), RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                T(if (poco) "POCO" else dev.brand.take(7), 12, if (poco) Color.Black else Color.White, true)
            }
            Column(Modifier.weight(1f)) {
                T(dev.name, 18, TX, true, maxLines = 1)
                Sp(6)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (dev.soc.isNotEmpty()) Chip(dev.soc)
                    Chip(dev.android, Color(0x33FFFFFF))
                }
            }
        }
        Sp(14)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile("Waktu aktif", fmtUp(awake), Modifier.weight(1f))
            Tile("Deep sleep • $pct%", fmtUp(sleep), Modifier.weight(1f))
        }
        Sp(12)
        Bar(pct / 100f)
    }
}

@Composable
fun Toggle(on: Boolean, onChange: (Boolean) -> Unit) =
    Box(Modifier.size(50.dp, 30.dp).clip(RoundedCornerShape(15.dp)).background(if (on) CYAN else Color(0xFF2B2F3A)).clickable { onChange(!on) }) {
        Box(Modifier.padding(4.dp).offset(x = if (on) 20.dp else 0.dp).size(22.dp).background(Color.White, CircleShape))
    }

@Composable
fun FpsCard() = Card2 {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Column { T("FPS", 13, MUT); T("${FpsMeter.fps}", 32, CYAN, true) }
        Column(horizontalAlignment = Alignment.End) {
            T("Frametime", 13, MUT)
            T("%.1f ms".format(FpsMeter.frameMs).replace('.', ','), 24, TX, true)
        }
    }
    Sp(10)
    Canvas(Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(12.dp)).background(CYAN.copy(alpha = 0.12f))) {
        val h = FpsMeter.history
        if (h.isNotEmpty()) {
            val mx = maxOf(60, h.max()) * 1.1f
            val step = size.width / 59f
            val x0 = size.width - (h.size - 1) * step
            val path = Path()
            h.forEachIndexed { i, v ->
                val x = x0 + i * step
                val y = size.height - 4.dp.toPx() - (v / mx) * (size.height - 8.dp.toPx())
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, CYAN, style = Stroke(2.dp.toPx()))
            path.lineTo(size.width, size.height); path.lineTo(x0, size.height); path.close()
            drawPath(path, CYAN.copy(alpha = 0.18f))
        }
    }
    Sp(8)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        T("Layar diam · 30 detik terakhir", 12); T("AVG ${FpsMeter.avg} · LOW ${FpsMeter.low}", 12)
    }
    Sp(12); Box(Modifier.fillMaxWidth().height(1.dp).background(BD)); Sp(12)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column { T("Overlay", 16, TX, true); T(if (FpsMeter.overlay) "Aktif" else "Mati", 13, MUT) }
        Toggle(FpsMeter.overlay) { FpsMeter.overlay = it }
    }
}

@Composable
fun HomeScreen() {
    val pr = PRESETS.firstOrNull { it.key == Store.game } ?: PRESETS[0]
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Hero()
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            DeviceCard()
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Card2(Modifier.weight(1f)) {
                    Label("TARGET FPS"); Sp(6)
                    T(FPS[Store.profile].toString(), 38, TX, true); Sp(10)
                    Bar(FPS[Store.profile] / 240f, 8, listOf(AC, Color(0xFFD6246E)))
                }
                Card2(Modifier.weight(1f)) {
                    Label("TUJUAN"); Sp(6)
                    T("Game", 12, MUT); T(pr.name, 16, TX, true); Sp(6)
                    T("File", 12, MUT); T(pr.file, 14, TX, true)
                }
            }
            FpsCard()
            RecCard()
        }
    }
}

@Composable
fun Pill(text: String, ok: Boolean) =
    Text(text, color = if (ok) Color(0xFF4ADE80) else MUT, fontSize = 13.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.background(if (ok) Color(0x2E2EA043) else BD, RoundedCornerShape(50)).padding(horizontal = 14.dp, vertical = 8.dp))

@Composable
fun GameCard(p: Preset) {
    val sh = RoundedCornerShape(20.dp)
    val cfg = Store.configured[p.key]
    Row(Modifier.fillMaxWidth().background(cardBg, sh).border(1.dp, BD, sh).clickable { Store.game = p.key }.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(Modifier.size(76.dp).background(p.color, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) { Ico(p.icon, Color.White, 32.dp) }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            T(p.name, 18, TX, true, maxLines = 1)
            Pill(if (cfg != null) "Configured" else "Not Configured", cfg != null)
            if (cfg != null) T(cfg, 12, MUT)
        }
        T("›", 28, AC)
    }
}

@Composable
fun ConfigList() = Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    T("Game Profiles", 24, TX, true)
    T("Kelola config dan pengaturan game.", 14, MUT)
    PRESETS.forEach { GameCard(it) }
    val sh = RoundedCornerShape(20.dp)
    Column(Modifier.fillMaxWidth().background(Color(0xFF2A1A10), sh).border(1.dp, AC, sh).padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        T("MORE GAMES", 13, AC, true); T("Segera hadir", 20, TX, true); T("Game kamu, aturan kamu.", 13, MUT)
    }
    T("Kartu tanpa konfigurasi sengaja dikosongkan, tidak ada tombol atau pengaturan palsu.", 12, MUT)
}

@Composable
fun GameDetail(p: Preset) {
    val scope = rememberCoroutineScope()
    var msg by remember(p.key) { mutableStateOf("") }
    var open by remember { mutableStateOf(false) }
    val path = Store.paths[p.key] ?: p.defaultPath
    val content = p.content(Store.profile)
    val sh = RoundedCornerShape(22.dp)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        T("‹ Kembali", 15, AC, true, Modifier.clickable { Store.game = null }.padding(vertical = 4.dp))
        T(p.name, 24, TX, true)
        // Baris game + Ganti
        Row(Modifier.fillMaxWidth().background(cardBg, sh).border(1.dp, BD, sh).padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Ico(4, Color(0xFF4F8FE0))
            T("${p.name} · ${p.file}", 14, TX, true, Modifier.weight(1f), 1)
            T("Ganti ›", 14, PINK, true, Modifier.clickable { Store.game = null })
        }
        // Baris Kualitas
        Row(Modifier.fillMaxWidth().background(cardBg, sh).border(1.dp, BD, sh).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Ico(5, Color(0xFFE0B040))
            T("Kualitas", 14, TX, true)
            Spacer(Modifier.weight(1f))
            listOf("Ultra" to 2, "High" to 1, "Medium" to 0).forEach { (label, idx) ->
                Box(Modifier.clip(RoundedCornerShape(16.dp)).background(if (Store.profile == idx) VIOLET else Color(0xFF23252D))
                    .clickable { Store.profile = idx }.padding(horizontal = 11.dp, vertical = 10.dp)) { T(label, 13, Color.White, true) }
            }
        }
        // Tombol Install
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF5B9BDC), VIOLET, PINK)))
            .clickable {
                scope.launch {
                    val r = withContext(Dispatchers.IO) { ConfigInstaller.install(path, content) }
                    msg = r.msg
                    if (r.ok) {
                        Store.configured[p.key] = PROFILES[Store.profile] + " · " + FPS[Store.profile] + " FPS"
                        Store.installs++; Store.last = p.name + " · " + PROFILES[Store.profile]
                    }
                }
            }.padding(vertical = 16.dp), contentAlignment = Alignment.Center) { T("Install", 20, Color.White, true) }
        if (msg.isNotEmpty()) T(msg, 13, MUT)
        T(if (open) "Detail config ▾" else "Detail config ›", 14, MUT, true, Modifier.clickable { open = !open }.padding(vertical = 8.dp))
        if (open) {
            OutlinedTextField(path, { Store.paths[p.key] = it }, label = { Text("Path file config") }, modifier = Modifier.fillMaxWidth())
            if (p.editable) OutlinedTextField(Store.customText, { Store.customText = it }, label = { Text("Isi config") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp))
            else Box(Modifier.fillMaxWidth().background(Color(0xFF07090E), RoundedCornerShape(10.dp)).padding(12.dp)) {
                T(content, 12, Color(0xFF9BF09A))
            }
            Box(Modifier.fillMaxWidth().border(1.dp, BD, RoundedCornerShape(16.dp)).clickable {
                scope.launch { msg = withContext(Dispatchers.IO) { ConfigInstaller.restore(path) }.msg }
            }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) { T("Kembalikan backup", 14, TX, true) }
        }
    }
}

@Composable
fun StatRow(label: String, value: String) =
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) { T(label, 14, MUT); T(value, 14, TX, true) }

@Composable
fun StatsScreen() = Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    T("Statistik", 24, TX, true)
    Card2 {
        StatRow("Config terpasang", "${Store.installs}")
        StatRow("Rekaman FPS", "${rememberRecords().value.size}")
        StatRow("Config terakhir", Store.last)
        StatRow("Akses", Shell.mode().let { if (it == "-") "Belum aktif" else it })
    }
}

const val DISCORD_URL = "https://discord.gg/EFaCxujTcC"
const val AUTHOR_NAME = "lismoyca"
const val AUTHOR_URL = "https://discord.com/users/1426827460187656223"

/** Satu baris berpanah (gaya Pulse Monitor): judul, keterangan, tanda ›. */
@Composable
fun SetItem(title: String, sub: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cardBg).clickable { onClick() }.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            T(title, 16, Color.White, true)
            T(sub, 12, subTx)
        }
        T("›", 22, subTx)
    }
}

@Composable
fun AccessOption(title: String, desc: String, color: Color, bg: Color, selected: Boolean, shield: Boolean, onClick: () -> Unit) {
    val sh = RoundedCornerShape(28.dp)
    Row(Modifier.fillMaxWidth().clip(sh).background(bg, sh)
        .border(if (selected) 2.dp else 1.dp, if (selected) color else color.copy(alpha = 0.35f), sh)
        .clickable { onClick() }.padding(horizontal = 18.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(56.dp), contentAlignment = Alignment.Center) {
            if (shield) Ico(6, color, 36.dp) else Box(Modifier.size(26.dp, 40.dp).background(color, RoundedCornerShape(7.dp)))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            T(title, 22, color, true)
            T(desc, 16, TX)
        }
    }
}

@Composable
fun SettingCard(title: String, content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxWidth().background(cardBg, RoundedCornerShape(20.dp)).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
) { T(title, 16, Color.White, true); content() }

/** Dialog umum: judul, keterangan, isi bisa digulir, tombol Tutup. */
@Composable
fun TabDialog(title: String, sub: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Color.Black, shape = RoundedCornerShape(28.dp),
        title = { Column { Text(title, color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp); Text(sub, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp)) } },
        text = { Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) { content() } },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = VIOLET, fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
    )
}

@Composable
fun SettingsScreen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var dlg by remember { mutableStateOf(false) }
    var wall by remember { mutableStateOf(false) }
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) Thread { Wallpaper.decodePreview(ctx, u)?.let { Wallpaper.cropSrc = it } }.start()
    }
    fun open(url: String) {
        try { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { android.widget.Toast.makeText(ctx, "Tidak ada aplikasi untuk membuka tautan", android.widget.Toast.LENGTH_SHORT).show() }
    }
    val green = Color(0xFF4ADE80)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("SETTINGS", color = TX, fontSize = 20.sp, letterSpacing = 3.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, modifier = Modifier.weight(1f))
            val live = Access.status == 2
            Row(Modifier.background(Color(0x14FFFFFF), RoundedCornerShape(12.dp)).padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).background(if (live) green else MUT, CircleShape)); Spacer(Modifier.width(6.dp))
                Text(if (live) "LIVE" else "OFF", color = if (live) green else MUT, fontSize = 14.sp, letterSpacing = 2.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
            }
        }
        T("Akses dan pengaturan", 18, TX, false, Modifier.padding(horizontal = 4.dp))
        Sp(4)

        SetItem("Akses", when {
            Access.busy > 0 -> "Memeriksa…"
            Access.status == 2 -> (if (Access.choice == Access.ROOT) "Root" else "Shizuku") + " · Terhubung"
            Access.status == 1 -> "Ketuk untuk beri izin"
            else -> "Pilih Shizuku atau Root"
        }, { Access.refresh(); dlg = true })
        if (Access.message.isNotEmpty()) T(Access.message, 12, subTx, false, Modifier.padding(horizontal = 12.dp))

        SetItem("Notifikasi pantauan", if (MonitorPrefs.notifOn) "Aktif · baterai + tombol rekam FPS" else "Mati", { Store.monitorDlg = true })
        SetItem("Wallpaper", "Gambar latar dan tingkat redup", { wall = true })
        SetItem("Kesehatan & log", "Cek fitur jalan atau tidak, lalu kirim laporannya", { Store.health = true })

        SettingCard("Komunitas") {
            LinkRow({ GamepadIcon(Color(0xFF8E86F0), Modifier.size(26.dp)) }, "Komunitas Discord", "") { open(DISCORD_URL) }
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x14FFFFFF)))
            LinkRow({ PersonIcon(Color(0xFFE49A72), Modifier.size(26.dp)) }, "Pembuat aplikasi", AUTHOR_NAME) { open(AUTHOR_URL) }
        }
        Sp(8)
    }

    if (Store.monitorDlg) TabDialog("Notifikasi pantauan", "Baterai, layar nyala/mati, dan tombol rekam FPS", { Store.monitorDlg = false }) {
        SettingCard("Notifikasi") {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("Tetap aktif di latar belakang", 14, Color.White, true)
                    T("Persen, arus, daya, suhu, dan tombol Mulai rekam di notifikasi.", 12, Color.White)
                }
                Toggle(MonitorPrefs.notifOn) { on ->
                    MonitorPrefs.notifOn = on; MonitorPrefs.save(ctx)
                    if (on) RecService.ensureRunning(ctx) else RecService.stop(ctx)
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("Nama aplikasi di notifikasi", 14, Color.White, true)
                    T("Menampilkan game / aplikasi yang sedang di depan.", 12, Color.White)
                }
                Toggle(MonitorPrefs.notifApp) { on -> MonitorPrefs.notifApp = on; MonitorPrefs.save(ctx) }
            }
            if (!android.provider.Settings.canDrawOverlays(ctx)) {
                T("Tips: izinkan \"Tampil di atas aplikasi lain\" supaya nama aplikasi di notifikasi tidak telat saat HP menghemat daya (HyperOS / MIUI).", 12, Color.White)
                PillButton("Buka pengaturan izin", filled = false) {
                    ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        android.net.Uri.parse("package:" + ctx.packageName)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }
    }

    if (wall) TabDialog("Wallpaper", "Gambar latar semua halaman aplikasi", { wall = false }) {
        SettingCard("Wallpaper") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton(if (Wallpaper.image == null) "Pilih gambar" else "Ganti gambar") {
                    picker.launch(androidx.activity.result.PickVisualMediaRequest(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                if (Wallpaper.image != null) PillButton("Hapus", filled = false) { Wallpaper.clear(ctx) }
            }
            if (Wallpaper.image == null) T("Belum ada gambar. Pilih satu untuk jadi latar aplikasi.", 12, Color.White)
            else {
                Row(Modifier.fillMaxWidth()) {
                    T("Redupkan latar", 12, Color.White, false, Modifier.weight(1f))
                    T("${(Wallpaper.dim * 100).toInt()}%", 12, Color.White, true)
                }
                AccSlider(Wallpaper.dim, 0f..0.9f, { Wallpaper.dim = it }) { Wallpaper.saveDim(ctx) }
            }
        }
    }

    Wallpaper.cropSrc?.let { src ->
        val dm = ctx.resources.displayMetrics
        CropDialog(src, dm.widthPixels.toFloat() / dm.heightPixels, "Potong wallpaper aplikasi", onCancel = { Wallpaper.cropSrc = null }) { cropped ->
            Wallpaper.cropSrc = null
            Thread { Wallpaper.saveCropped(ctx, cropped) }.start()
        }
    }

    if (dlg) androidx.compose.ui.window.Dialog(onDismissRequest = { dlg = false }) {
        val dsh = RoundedCornerShape(36.dp)
        Column(Modifier.fillMaxWidth().background(Color.Black, dsh).padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            T("Izinkan Akses", 30, TX, true)
            T("Pilih metode yang ingin dipakai untuk akses tingkat tinggi.", 17, TX)
            AccessOption("Shizuku", "Tanpa root, jalan lewat Wireless Debugging atau ADB.", VIOLET, Color(0xFF131120), Access.choice != Access.ROOT, false) { Access.select(Access.SHIZUKU); dlg = false }
            AccessOption("Root", "Butuh perangkat yang di-root (Magisk, KernelSU, APatch, dll).", Color(0xFFE8A27C), Color(0xFF17120F), Access.choice == Access.ROOT, true) { Access.select(Access.ROOT); dlg = false }
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                TextButton(onClick = { dlg = false }) { Text("Batal", color = VIOLET, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
fun NavBar(tab: Int, onTab: (Int) -> Unit) {
    val items = listOf("Beranda" to 0, "Config" to 1, "Statistik" to 2, "Settings" to 3)
    val sh = RoundedCornerShape(34.dp)
    Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 12.dp).background(cardBg, sh).border(1.dp, BD, sh).padding(8.dp)) {
        items.forEachIndexed { i, (label, icon) ->
            val on = tab == i
            Column(Modifier.weight(1f)
                .drawBehind { if (on) drawRoundRect(AC, Offset(size.width * 0.24f, -8.dp.toPx()), Size(size.width * 0.52f, 4.dp.toPx()), CornerRadius(2.dp.toPx())) }
                .background(if (on) AC.copy(alpha = 0.16f) else Color.Transparent, RoundedCornerShape(16.dp))
                .clickable { onTab(i) }.padding(vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                // ikon: 0 home, 1 petir, 2 daftar, 3 gerigi
                Ico(listOf(0, 1, 2, 3)[icon], if (on) AC else MUT)
                T(if (on) label.uppercase() else label, 11, if (on) AC else MUT, on)
            }
        }
    }
}
