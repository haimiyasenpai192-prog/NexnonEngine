package com.nexnon.engine

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.*
import kotlin.math.abs

/**
 * Sidebar melayang (Gamebar). Tertutup: pegangan tipis di tepi layar (ketuk = buka, geser = pindah, lepas = menempel ke sisi terdekat).
 * Terbuka: kolom tombol Overlay / Rekam / Warna / Layar / Tutup. Ketuk di luar kolom untuk menutup.
 * Dengan "Hanya saat di game" (bawaan), sidebar disembunyikan di luar game; status game dari RecService lewat Gamebar.inGame.
 * Bila RecService tidak hidup (tidak ada pendeteksi game), sidebar tetap tampil supaya tidak hilang tanpa sebab.
 */
class GamebarService : Service() {
    companion object {
        @Volatile var running = false
        private const val CH = "gamebar"
        private const val NID = 3
    }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var host: FrameLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private var handleBox: FrameLayout? = null
    private var panel: LinearLayout? = null
    private var expanded = false
    private var lastSide = -1
    private var job: Job? = null
    private val refreshers = ArrayList<() -> Unit>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    private fun fg(n: Notification) {
        if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(NID, n)
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        runCatching { getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CH, "Gamebar", NotificationManager.IMPORTANCE_LOW)) }
        runCatching {
            fg(Notification.Builder(this, CH).setSmallIcon(R.drawable.ic_stat_nexnon).setContentTitle("Nexnon Engine")
                .setContentText("Gamebar aktif").setOngoing(true).setShowWhen(false).build())
        }.onFailure { AppLog.w("Gamebar", "startForeground gagal: ${it.javaClass.simpleName} ${it.message}") }
        Gamebar.load(this); OverlayPrefs.load(this); GameColor.load(this)
        // Izin overlay bisa dicabut kapan saja; addView akan crash tanpa pengecekan ini
        if (!Gamebar.on || !Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        Access.init(this)
        if (host == null && !show()) { stopSelf(); return START_NOT_STICKY }
        running = true
        return START_STICKY
    }

    private fun refresh() { refreshers.forEach { runCatching { it() } } }

    /** Satu tombol: judul + baris status berwarna. [onClick] jalan di thread utama. */
    private fun tile(title: String, state: () -> String, tint: () -> Int, onClick: () -> Unit): View {
        val t1 = TextView(this).apply { text = title; textSize = 11f; setTextColor(0xFFFFFFFF.toInt()); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }
        val t2 = TextView(this).apply { textSize = 10f; gravity = Gravity.CENTER; setSingleLine(true) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(7), 0, dp(7))
            background = GradientDrawable().apply { setColor(0x1AFFFFFF); cornerRadius = dp(14).toFloat() }
            addView(t1); addView(t2)
            setOnClickListener { onClick(); refresh() }
        }
        refreshers.add { t2.text = state(); t2.setTextColor(tint()) }
        return box
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun show(): Boolean {
        val wm = getSystemService(WindowManager::class.java)
        val pos = getSharedPreferences("gamebar_pos", MODE_PRIVATE)
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val grn = 0xFF7CFFB2.toInt(); val gry = 0xFF99A1B5.toInt(); val red = 0xFFFF5C5C.toInt(); val cy = 0xFF3DF0FF.toInt()

        // Pegangan: pil tipis di tepi, dibungkus bantalan supaya mudah diketuk
        val pill = View(this).apply { background = GradientDrawable().apply { setColor(0xCC8B86EA.toInt()); cornerRadius = dp(4).toFloat() } }
        val hb = FrameLayout(this).apply {
            setPadding(dp(10), dp(8), dp(10), dp(8))
            addView(pill, FrameLayout.LayoutParams(dp(8), dp(56)))
        }
        handleBox = hb

        // Kolom tombol
        val pn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(6), dp(4), dp(6), dp(6)); visibility = View.GONE
            background = GradientDrawable().apply { setColor(0xF0101014.toInt()); cornerRadius = dp(20).toFloat(); setStroke(dp(1), 0x33FFFFFF) }
        }
        panel = pn
        val grip = FrameLayout(this).apply {
            addView(View(this@GamebarService).apply { background = GradientDrawable().apply { setColor(0x66FFFFFF); cornerRadius = dp(2).toFloat() } },
                FrameLayout.LayoutParams(dp(28), dp(4), Gravity.CENTER))
            setOnClickListener { setExpanded(false) }
        }
        pn.addView(grip, LinearLayout.LayoutParams(dp(52), dp(22)))
        fun add(v: View) { pn.addView(v, LinearLayout.LayoutParams(dp(52), wrap).apply { topMargin = dp(4) }) }

        add(tile("Overlay", { if (OverlayPrefs.on) "ON" else "OFF" }, { if (OverlayPrefs.on) grn else gry }) {
            OverlayPrefs.on = !OverlayPrefs.on; OverlayPrefs.save(this); OverlayService.sync(this)
        })
        add(tile("Rekam", { if (Recorder.active) "● REC" else "Mulai" }, { if (Recorder.active) red else gry }) {
            RecCtl.toggle(this); setExpanded(false)
        })
        add(tile("Warna", { GameColor.label() }, { if (GameColor.enabled) cy else gry }) {
            GameColor.cycle(this)
        })
        add(tile("Layar", { "Tangkap" }, { gry }) {
            // Tutup kolom dulu supaya tidak ikut terfoto, lalu tombol tangkapan layar sistem lewat shell
            setExpanded(false)
            Thread {
                try { Thread.sleep(450) } catch (_: InterruptedException) {}
                runCatching { Shell.exec("input keyevent 120") }
            }.start()
        })
        add(tile("Tutup", { "Gamebar" }, { gry }) {
            Gamebar.on = false; Gamebar.save(this); stopSelf()
        })

        val box = FrameLayout(this).apply {
            addView(hb, FrameLayout.LayoutParams(wrap, wrap))
            addView(pn, FrameLayout.LayoutParams(wrap, wrap))
        }
        val p = WindowManager.LayoutParams(wrap, wrap, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = pos.getInt("y", dp(240)) }
        lp = p

        // Ketuk di luar kolom (jendela lain / game) menutupnya
        box.setOnTouchListener { _, e -> if (e.actionMasked == MotionEvent.ACTION_OUTSIDE && expanded) { setExpanded(false); true } else false }

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        hb.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (!moved && (abs(e.rawX - tx) > dp(8) || abs(e.rawY - ty) > dp(8))) moved = true
                    if (moved) {
                        val dm = resources.displayMetrics
                        p.x = (sx + (e.rawX - tx).toInt()).coerceIn(0, maxOf(0, dm.widthPixels - box.width))
                        p.y = (sy + (e.rawY - ty).toInt()).coerceIn(0, maxOf(0, dm.heightPixels - box.height))
                        runCatching { wm.updateViewLayout(box, p) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        val dm = resources.displayMetrics
                        Gamebar.side = if (p.x + box.width / 2 < dm.widthPixels / 2) 0 else 1
                        Gamebar.save(this); pos.edit().putInt("y", p.y).apply(); lastSide = Gamebar.side
                        place()
                    } else setExpanded(true)
                }
            }
            true
        }

        if (!runCatching { wm.addView(box, p) }.onFailure { AppLog.w("Gamebar", "addView gagal: ${it.message}") }.isSuccess) return false
        host = box
        lastSide = Gamebar.side
        refresh()
        box.post { place() }

        // Tampil / sembunyi sesuai game di depan, segarkan teks tombol, dan ikuti perubahan sisi dari pengaturan
        job = scope.launch {
            while (isActive) {
                val visible = !Gamebar.gameOnly || !RecService.alive || Gamebar.inGame
                host?.let { h ->
                    val vis = if (visible) View.VISIBLE else View.GONE
                    if (h.visibility != vis) { h.visibility = vis; if (!visible && expanded) setExpanded(false) }
                    if (visible) {
                        refresh()
                        if (Gamebar.side != lastSide) { lastSide = Gamebar.side; place() }
                    }
                }
                delay(400L)
            }
        }
        return true
    }

    private fun setExpanded(e: Boolean) {
        expanded = e
        handleBox?.visibility = if (e) View.GONE else View.VISIBLE
        panel?.visibility = if (e) View.VISIBLE else View.GONE
        refresh()
        host?.post { place() }
    }

    /** Tempelkan ke sisi pilihan dan pastikan seluruh tinggi sidebar muat di layar. */
    private fun place() {
        val h = host ?: return; val p = lp ?: return
        val dm = resources.displayMetrics
        h.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        p.x = if (Gamebar.side == 0) 0 else maxOf(0, dm.widthPixels - h.measuredWidth)
        p.y = p.y.coerceIn(0, maxOf(0, dm.heightPixels - h.measuredHeight))
        runCatching { getSystemService(WindowManager::class.java).updateViewLayout(h, p) }
    }

    override fun onDestroy() {
        running = false
        job?.cancel(); job = null
        host?.let { v -> runCatching { getSystemService(WindowManager::class.java).removeView(v) } }; host = null
        scope.cancel()
        super.onDestroy()
    }
}
