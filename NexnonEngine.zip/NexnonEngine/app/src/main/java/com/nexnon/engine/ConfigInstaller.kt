package com.nexnon.engine

import android.util.Base64
import androidx.compose.ui.graphics.Color

class Preset(val key: String, val name: String, val file: String, val defaultPath: String,
             val color: Color, val icon: Int, val editable: Boolean = false, val kind: Int = 0, val gen: (Int, Int) -> String)

fun Preset.content(p: Int): String = if (editable) Store.customText else gen(p, FPS[p])

val PRESETS = listOf(
    Preset("wuwa", "Wuthering Waves", "Engine.ini", "", Color(0xFF7C3AED), 1, kind = 1) { _, _ -> "" },
    Preset("ue", "Game Unreal Engine", "Engine.ini",
        "/sdcard/Android/data/NAMA.PAKET/files/UE4Game/Game/Game/Saved/Config/Android/Engine.ini", Color(0xFF3730A3), 1) { p, f ->
        listOf("[SystemSettings]", "t.MaxFPS=$f",
            "r.ScreenPercentage=${listOf(70, 85, 100)[p]}", "r.ViewDistanceScale=${listOf(0.5, 0.8, 1.0)[p]}",
            "sg.ShadowQuality=${listOf(0, 2, 3)[p]}", "sg.PostProcessQuality=${listOf(0, 2, 3)[p]}",
            "sg.TextureQuality=${listOf(1, 2, 3)[p]}", "r.MotionBlurQuality=${if (p == 2) 2 else 0}").joinToString("\n") + "\n"
    },
    Preset("custom", "Config sendiri", "config.ini",
        "/sdcard/Android/data/NAMA.PAKET/files/config.ini", Color(0xFF166534), 5, editable = true) { _, _ -> "" }
)

/** Kartu tampilan saja (belum ada config), tidak ada di PRESETS sehingga tidak bisa dipilih/dibuka. */
val SILVER_PALACE = Preset("silverpalace", "Silver Palace", "", "", Color(0xFF9CA3AF), 1) { _, _ -> "" }

object ConfigInstaller {
    class Result(val ok: Boolean, val msg: String)

    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    /** Backup file lama (sekali, jadi .bak), tulis config baru lewat base64 (aman dari masalah kutip), lalu verifikasi. */
    fun install(path: String, content: String): Result {
        if (Shell.mode() == "-") return Result(false, "Akses belum aktif. Buka tab Settings lalu pilih Shizuku atau Root.")
        if (path.contains("NAMA.PAKET")) return Result(false, "Ganti NAMA.PAKET di Detail config dengan nama paket game.")
        val b64 = Base64.encodeToString(content.toByteArray(), Base64.NO_WRAP)
        val f = q(path); val d = q(path.substringBeforeLast('/')); val bak = q("$path.bak")
        Shell.exec("mkdir -p $d; [ -f $f ] && [ ! -f $bak ] && cp $f $bak; echo $b64 | base64 -d > $f")
        val ok = Shell.exec("[ -s $f ] && echo OK").contains("OK")
        return if (ok) Result(true, "Terpasang lewat ${Shell.mode()}. Backup: $path.bak")
        else Result(false, "Gagal menulis. Cek path dan izin akses.")
    }

    fun restore(path: String): Result {
        if (Shell.mode() == "-") return Result(false, "Akses belum aktif.")
        val f = q(path); val bak = q("$path.bak")
        val ok = Shell.exec("[ -f $bak ] && cp $bak $f && echo OK").contains("OK")
        return if (ok) Result(true, "Config dikembalikan dari backup.") else Result(false, "Tidak ada backup.")
    }
}
