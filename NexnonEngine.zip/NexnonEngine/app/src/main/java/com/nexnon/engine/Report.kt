package com.nexnon.engine

import androidx.compose.runtime.*
import java.util.Calendar
import java.util.Locale

/** state: 0 = menunggu / tidak wajib, 1 = OK, 2 = bermasalah */
class FileRow(val name: String, val state: Int, val note: String = "")

/** Isi kotak hasil: status pemasangan / cek status + daftar file + log. */
object Report {
    var visible by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var kind by mutableStateOf("install")      // install | delete | check
    var ok by mutableStateOf(true)
    var title by mutableStateOf("")
    var sub by mutableStateOf("")
    var rows by mutableStateOf<List<FileRow>>(emptyList())
    val log = mutableStateListOf<String>()

    fun begin(kind: String, title: String, names: List<String>) {
        visible = true; busy = true; ok = true; this.kind = kind
        this.title = title; sub = "Jangan tutup aplikasi"; rows = names.map { FileRow(it, 0) }
    }

    fun end(kind: String, ok: Boolean, title: String, sub: String, rows: List<FileRow>) {
        visible = true; busy = false; this.kind = kind; this.ok = ok; this.title = title; this.sub = sub; this.rows = rows
    }

    /** Gagal sebelum mulai (belum ada akses, game tidak ditemukan, dst.). */
    fun fail(title: String, msg: String) { end("install", false, title, msg, emptyList()); addLog("GAGAL: $msg") }

    fun addLog(s: String) {
        log.add(fmtTime(System.currentTimeMillis()) + "  " + s)
        while (log.size > 200) log.removeAt(0)
    }

    /** "Hari ini 18:29" atau "28 Okt 18:29". */
    fun fmtTime(t: Long): String {
        val now = Calendar.getInstance(); val c = Calendar.getInstance().apply { timeInMillis = t }
        val hm = String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
        val same = now.get(Calendar.YEAR) == c.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == c.get(Calendar.DAY_OF_YEAR)
        if (same) return "Hari ini $hm"
        val bln = listOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")
        return "${c.get(Calendar.DAY_OF_MONTH)} ${bln[c.get(Calendar.MONTH)]} $hm"
    }
}
