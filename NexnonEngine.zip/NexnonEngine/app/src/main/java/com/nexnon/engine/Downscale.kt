package com.nexnon.engine

import android.content.Context
import android.os.Build
import android.view.WindowManager
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/**
 * Resolusi game (downscale): game dirender di resolusi lebih rendah (GPU lebih ringan, HP lebih dingin),
 * layar HP dan aplikasi lain tidak berubah. Memakai Game Manager Android 13+ (`cmd game`) lewat Shizuku/Root.
 * Cara kerja mengikuti WuWa Config.
 */
object Downscale {
    val PRESETS = listOf(480, 500, 600, 720, 800, 900, 1080)
    val busy = mutableStateOf(false)
    val status = mutableStateOf<String?>(null)

    /** Sisi pendek layar fisik (mis. 1220 untuk layar 1220x2712): dasar hitungan resolusi game. */
    fun shortSide(ctx: Context): Int {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (Build.VERSION.SDK_INT >= 30) wm.maximumWindowMetrics.bounds.let { minOf(it.width(), it.height()) }
        else android.util.DisplayMetrics().also { @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(it) }.let { minOf(it.widthPixels, it.heightPixels) }
    }

    fun saved(ctx: Context): Float? =
        ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).getFloat("downscale_ratio", -1f).takeIf { it > 0f }

    private fun save(ctx: Context, r: Float?) {
        ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE).edit().putFloat("downscale_ratio", r ?: -1f).apply()
    }

    fun label(short: Int, r: Float?): String =
        if (r == null) "Normal (tanpa downscale)" else "${String.format(java.util.Locale.US, "%.2f", r)}x • ${(short * r).roundToInt()}p"

    /** Jalankan perintah ke game. null = sukses, atau pesan error. */
    private fun cmd(pkg: String, ratio: Float?): String? {
        val sdk = Build.VERSION.SDK_INT
        if (sdk < 33) return "HP ini tidak bisa menskalakan satu aplikasi (butuh Android 13 atau lebih baru)."
        fun lastLine(out: String) = out.lines().lastOrNull { it.isNotBlank() }.orEmpty().take(160)
        fun failed(code: Int, out: String) = code != 0 || out.contains("Exception", ignoreCase = true)
        if (ratio == null) {
            val (code, out) = Shell.run("cmd game set --downscale disable '$pkg' && cmd game mode standard '$pkg'")
            if (!failed(code, out)) return null
            val (c2, o2) = Shell.run("cmd game reset '$pkg'; cmd game mode standard '$pkg'")
            return if (!failed(c2, o2)) null else "Gagal mengembalikan resolusi game: ${lastLine(o2).ifEmpty { lastLine(out) }}"
        }
        // Android 13 hanya menerima kelipatan 0.05 (0.30..0.90); Android 14+ menerima angka bebas di rentang itu.
        val r = ratio.coerceIn(0.30f, 0.90f).let { if (sdk >= 34) it else Math.round(it * 20f) / 20f }
        val text = String.format(java.util.Locale.US, "%.3f", r).trimEnd('0').trimEnd('.')
        val tries = listOf(
            "cmd game set --downscale $text '$pkg' && cmd game mode custom '$pkg'",
            "cmd game set --downscale $text '$pkg' && cmd game mode performance '$pkg'",
            "cmd game set --mode 2 --downscale $text '$pkg' && cmd game mode performance '$pkg'"
        )
        var lastErr = ""
        for (c in tries) {
            val (code, out) = Shell.run(c)
            if (!failed(code, out)) return null
            lastErr = lastLine(out).ifEmpty { "kode $code" }
        }
        return "Gagal mengubah resolusi game: $lastErr"
    }

    /** Terapkan ke game. [r] null = reset. Hasilnya muncul di [status]. */
    fun apply(ctx: Context, scope: CoroutineScope, pkg: String?, r: Float?) {
        if (busy.value) return
        if (Shell.mode() == "-") { status.value = "Akses belum aktif. Buka tab Settings."; return }
        if (pkg == null) { status.value = "Wuthering Waves tidak ditemukan."; return }
        busy.value = true; status.value = "Menerapkan…"
        scope.launch {
            val err = withContext(Dispatchers.IO) { cmd(pkg, r) }
            busy.value = false
            if (err == null) {
                save(ctx, r)
                status.value = if (r == null) "Dikembalikan ke normal. Tutup game sepenuhnya lalu buka lagi supaya perubahan terlihat."
                else "Diterapkan: ${label(shortSide(ctx), r)}. Tutup game sepenuhnya lalu buka lagi supaya perubahan terlihat."
            } else status.value = err
        }
    }
}

@Composable
private fun ResOption(title: String, sub: String, sel: Boolean, onClick: () -> Unit) {
    val sh = RoundedCornerShape(20.dp)
    Row(Modifier.fillMaxWidth().clip(sh).background(if (sel) VIOLET else Color(0xFF1E1E26))
        .clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f)) { T(title, 15, if (sel) Color.White else Color(0xFFC5CAF5), true) }
        T(sub, 12, if (sel) Color.White.copy(0.85f) else Color(0xFF8A8FB5))
    }
}

/** Kartu satu baris "Resolusi game"; pilihan resolusi muncul sebagai popup saat diketuk. */
@Composable
fun DownscaleCard(pkg: String?) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val short = remember { Downscale.shortSide(ctx) }
    var ratio by remember { mutableStateOf(Downscale.saved(ctx)) }
    var showPicker by remember { mutableStateOf(false) }
    val busy = Downscale.busy.value
    val st = Downscale.status.value
    val on = ratio != null
    val sh = RoundedCornerShape(18.dp)
    Column(Modifier.fillMaxWidth().clip(sh).background(cardBg).border(1.dp, BD, sh)) {
        Row(Modifier.fillMaxWidth().clickable(enabled = !busy) { showPicker = true }.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Ico(12, Color(0xFF5B9BE0), 20.dp)
            Spacer(Modifier.width(10.dp))
            T("Resolusi game", 14, TX, true, maxLines = 1)
            Spacer(Modifier.weight(1f))
            Box(Modifier.clip(RoundedCornerShape(12.dp)).background(if (on) VIOLET.copy(alpha = 0.85f) else Color(0xFF23252D)).padding(horizontal = 10.dp, vertical = 4.dp)) {
                T(if (on) "${(short * (ratio ?: 1f)).roundToInt()}p" else "Normal", 12, Color.White, true, maxLines = 1)
            }
            if (on) {
                Spacer(Modifier.width(8.dp))
                Box(Modifier.size(28.dp).clip(CircleShape).background(Color(0xFF23252D))
                    .clickable(enabled = !busy) { ratio = null; Downscale.apply(ctx, scope, pkg, null) }, contentAlignment = Alignment.Center) {
                    Ico(9, Color.White.copy(alpha = if (busy) 0.4f else 1f), 16.dp)
                }
            }
            Spacer(Modifier.width(6.dp))
            T("›", 20, Color.White.copy(0.8f))
        }
        val note = st ?: if (Build.VERSION.SDK_INT < 33) "HP ini butuh Android 13 atau lebih baru." else null
        if (note != null) T(note, 11, Color.White.copy(0.85f), false, Modifier.padding(start = 14.dp, end = 14.dp, bottom = 8.dp), 2)
    }
    if (showPicker) AlertDialog(
        onDismissRequest = { showPicker = false }, containerColor = Color.Black, shape = RoundedCornerShape(28.dp),
        title = { Text("Resolusi game", color = TX, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                T("Hanya tampilan game yang berubah, layar HP tidak.", 12, Color(0xFF8A8FB5))
                ResOption("Normal", "tanpa downscale", ratio == null) {
                    showPicker = false
                    if (ratio != null) { ratio = null; Downscale.apply(ctx, scope, pkg, null) }
                }
                Downscale.PRESETS.filter { it.toFloat() / short in 0.30f..0.90f }.reversed().forEach { h ->
                    val r = h.toFloat() / short
                    val sel = ratio != null && kotlin.math.abs((ratio ?: 0f) * short - h) < 1f
                    ResOption("${h}p", String.format(java.util.Locale.US, "%.2fx", r), sel) {
                        showPicker = false
                        if (!sel) { ratio = r; Downscale.apply(ctx, scope, pkg, r) }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = { showPicker = false }) { Text("Batal", color = VIOLET) } }
    )
}
