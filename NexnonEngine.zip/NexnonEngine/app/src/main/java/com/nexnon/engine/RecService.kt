package com.nexnon.engine

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.RemoteViews
import kotlinx.coroutines.*

/**
 * Layanan latar depan: notifikasi baterai (ringkas + diperluas) dengan tombol "Mulai rekam" / "Berhenti rekam",
 * seperti Pulse Monitor. Ringkas: persen, status, arus, daya, suhu. Diperluas: bilah, Layar Nyala / Mati / Tidur lelap, laju kuras.
 */
class RecService : Service() {
    companion object {
        const val ACTION_REC = "com.nexnon.engine.REC"
        const val ACTION_COLLAPSE = "com.nexnon.engine.COLLAPSE"
        const val ACTION_RESTORE = "com.nexnon.engine.RESTORE"
        private const val CH = "monitor"
        private const val NID = 1

        @Volatile var alive = false
        /** Nama aplikasi yang sedang tampil di notifikasi (untuk pemeriksaan kesehatan). */
        @Volatile var fgShown = ""

        /** Alarm sekali untuk menghidupkan layanan lagi bila proses dimatikan sistem. Gagal = diabaikan (START_STICKY tetap cadangan). */
        fun scheduleRestore(ctx: Context, delayMs: Long) {
            runCatching {
                val app = ctx.applicationContext
                val pi = PendingIntent.getForegroundService(app, 77, Intent(app, RecService::class.java).setAction(ACTION_RESTORE),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                val am = app.getSystemService(AlarmManager::class.java)
                val at = SystemClock.elapsedRealtime() + delayMs
                // Alarm tidak tepat di Android 12+ tidak boleh memulai layanan latar depan; alarm tepat boleh.
                runCatching { am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi) }
                    .onFailure { am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi) }
            }
        }

        /** Dipanggil saat aplikasi dibuka atau HP menyala: bila notifikasi pantauan nyala, hidupkan (atau pasang ulang) layanan. */
        fun ensureRunning(ctx: Context) {
            runCatching {
                val app = ctx.applicationContext
                MonitorPrefs.load(app)
                if (MonitorPrefs.notifOn) app.startForegroundService(Intent(app, RecService::class.java).setAction(ACTION_RESTORE))
            }.onFailure { AppLog.w("Layanan", "ensureRunning gagal: ${it.javaClass.simpleName} ${it.message}") }
        }

        fun stop(ctx: Context) { runCatching { ctx.applicationContext.stopService(Intent(ctx.applicationContext, RecService::class.java)) } }
    }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob() + CoroutineExceptionHandler { _, e ->
        AppLog.w("Layanan", "coroutine gagal: ${e.javaClass.simpleName} ${e.message}")
    })
    private var screenRx: BroadcastReceiver? = null
    private var batteryRx: BroadcastReceiver? = null
    private var loopJob: Job? = null
    private var anchor: View? = null
    private var anchorFailed = false

    @Volatile private var fgLabel = ""
    private val labelCache = HashMap<String, String>()
    private fun labelOf(pkg: String): String = labelCache.getOrPut(pkg) {
        runCatching { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
    }

    /**
     * Bolak-balik antara dua layout kembar tiap pembaruan. Di HyperOS, pembaruan RemoteViews dengan layout yang SAMA tidak tampil
     * di shade (angka beku); layout beda id memaksa pemasangan ulang tampilan.
     */
    private var notifFlip = false

    override fun onBind(i: Intent?): IBinder? = null

    // ---------- Notifikasi ----------
    private fun pi(code: Int, action: String) = PendingIntent.getService(this, code, Intent(this, RecService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun immediate(nb: Notification.Builder) {
        if (Build.VERSION.SDK_INT >= 31) nb.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
    }

    /** Notifikasi paling sederhana, dipakai untuk startForeground supaya tidak pernah gagal. */
    private fun safeNotif(): Notification {
        val nb = Notification.Builder(this, CH).setSmallIcon(R.drawable.ic_stat_nexnon)
            .setContentTitle("Nexnon Engine").setContentText("Berjalan di latar belakang")
            .setOnlyAlertOnce(true).setShowWhen(false).setOngoing(true)
        immediate(nb)
        return nb.build()
    }

    private fun buildNotif(): Notification {
        val rec = Recorder.active
        val recPi = pi(1, ACTION_REC)
        val tap = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val act = Notification.Action.Builder(
            android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_media_play),
            if (rec) "Berhenti rekam" else "Mulai rekam", recPi).build()
        val b = runCatching { BatteryStats.tick() }.getOrNull()
        val head = if (rec) "● Merekam FPS" else "Nexnon Engine"
        val nb = Notification.Builder(this, CH).setSmallIcon(R.drawable.ic_stat_nexnon).setColor(0xFFFFFFFF.toInt())
            .setContentTitle(head).setContentText(b?.line2 ?: "Berjalan di latar belakang")   // cadangan untuk tampilan tanpa layout kustom
            .setOnlyAlertOnce(true).setShowWhen(false).setContentIntent(tap).setOngoing(true)
        immediate(nb)
        if (b == null) nb.addAction(act)
        if (b != null) {
            val pctTxt = if (b.pct >= 0) "${b.pct}%" else "-"
            // Nama aplikasi + status dalam satu teks yang boleh turun ke baris kedua ("Claude  Tidak mengisi daya")
            val app = if (MonitorPrefs.notifApp) fgLabel else ""
            val statusLine = (if (rec) "● Merekam FPS • " else "") + (if (app.isEmpty()) "" else "$app  ") + b.status
            val subLine = (if (rec && Recorder.lastFps > 0) listOf("${Recorder.lastFps} FPS") else emptyList<String>())
                .plus(listOf(b.current, b.power, b.temp).filter { it != "-" }).joinToString(" • ").ifEmpty { "-" }
            val small = RemoteViews(packageName, if (notifFlip) R.layout.notif_collapsed_b else R.layout.notif_collapsed).apply {
                setTextViewText(R.id.n_pct, pctTxt)
                setTextViewText(R.id.n_title, statusLine)
                setTextViewText(R.id.n_sub, subLine)
            }
            val big = RemoteViews(packageName, if (notifFlip) R.layout.notif_expanded_b else R.layout.notif_expanded).apply {
                setTextViewText(R.id.n_pct, pctTxt)
                setTextViewText(R.id.n_title, statusLine)
                setProgressBar(R.id.n_bar, 100, b.pct.coerceAtLeast(0), false)
                setTextViewText(R.id.n_cur, b.current); setTextViewText(R.id.n_pow, b.power); setTextViewText(R.id.n_tmp, b.temp)
                setTextViewText(R.id.n_on, b.screenOn); setTextViewText(R.id.n_on_d, b.screenOnDetail)
                setTextViewText(R.id.n_off, b.screenOff); setTextViewText(R.id.n_off_d, b.screenOffDetail)
                setTextViewText(R.id.n_deep, b.deep); setTextViewText(R.id.n_awake, "Terjaga ${b.awake}")
                setTextViewText(R.id.n_act, b.activeRate); setTextViewText(R.id.n_idle, b.idleRate)
                setViewVisibility(R.id.n_rec, View.VISIBLE)
                setTextViewText(R.id.n_rec, if (rec) "Berhenti rekam" else "Mulai rekam")
                setOnClickPendingIntent(R.id.n_rec, recPi)
                setOnClickPendingIntent(R.id.n_chev, pi(3, ACTION_COLLAPSE))   // panah: kembali ke tampilan ringkas
            }
            nb.setStyle(Notification.DecoratedCustomViewStyle())
            nb.setCustomContentView(small).setCustomBigContentView(big)
        }
        return nb.build()
    }

    private fun fg(n: Notification) {
        if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(NID, n)
    }

    /** Pembaruan lewat startForeground() id sama (di HyperOS notify() biasa untuk notifikasi layanan tidak ikut tampil); notify() hanya cadangan. */
    private fun refreshNotif() {
        if (!alive) return
        notifFlip = !notifFlip
        val n = runCatching { buildNotif() }.getOrElse { AppLog.w("Notifikasi", "buildNotif gagal: ${it.message}"); return }
        val ok = runCatching { fg(n) }.isSuccess
        if (!ok) runCatching { getSystemService(NotificationManager::class.java).notify(NID, n) }
    }

    /** Ciutkan notifikasi: dilepas lalu dipasang ulang, entri baru selalu mulai ringkas. */
    private fun collapseNotif() {
        if (!alive) return
        runCatching { stopForeground(Service.STOP_FOREGROUND_REMOVE) }
        scope.launch { delay(120L); refreshNotif() }
    }

    // ---------- Jangkar jendela 1x1 ----------
    /**
     * Proses yang punya jendela overlay terlihat dinilai sistem sebagai "terlihat", bukan proses latar belakang, jadi tidak dibekukan
     * HyperOS saat aplikasi lain di depan (penyebab nama aplikasi di notifikasi diam). Hanya bila izin "tampil di atas aplikasi lain" ada.
     */
    private fun syncAnchor() {
        val want = MonitorPrefs.notifApp && Settings.canDrawOverlays(this)
        if (!want) { anchorFailed = false; removeAnchor(); return }
        if (anchor != null || anchorFailed) return
        runCatching {
            val v = View(this)
            val lp = WindowManager.LayoutParams(1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
            getSystemService(WindowManager::class.java).addView(v, lp)
            anchor = v
        }.onFailure { anchorFailed = true; AppLog.w("Layanan", "jangkar jendela gagal: ${it.javaClass.simpleName} ${it.message}") }
    }

    private fun removeAnchor() {
        anchor?.let { v -> runCatching { getSystemService(WindowManager::class.java).removeView(v) } }
        anchor = null
    }

    // ---------- Pemantau latar ----------
    private fun startHousekeeping() {
        val rx = object : BroadcastReceiver() {
            override fun onReceive(c: Context, intent: Intent) {
                if (intent.action != Intent.ACTION_USER_PRESENT) runCatching { BatteryStats.setScreen(intent.action == Intent.ACTION_SCREEN_ON) }
                refreshNotif()
                // Data baterai dari sistem sering baru terbarui beberapa saat setelah layar menyala: segarkan lagi
                if (intent.action != Intent.ACTION_SCREEN_OFF) scope.launch { delay(500L); refreshNotif(); delay(1500L); refreshNotif() }
            }
        }
        registerReceiver(rx, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_USER_PRESENT)
        })
        screenRx = rx

        // Persen / status / charger / suhu berubah: perbarui seketika. Perubahan kecil dibatasi 2 detik, dengan satu pembaruan tertunda
        val brx = object : BroadcastReceiver() {
            private var lastKey = ""; private var lastAt = 0L; private var pending: Job? = null
            override fun onReceive(c: Context, intent: Intent) {
                val key = "${intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)}|${intent.getIntExtra(BatteryManager.EXTRA_STATUS, 0)}|" +
                    "${intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)}|${intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)}"
                val now = SystemClock.elapsedRealtime()
                val screenOn = BatteryStats.isScreenOn()
                if (key != lastKey || (screenOn && now - lastAt > 2000L)) {
                    lastKey = key; lastAt = now; pending?.cancel(); pending = null; refreshNotif()
                } else if (screenOn && pending?.isActive != true) {
                    val wait = (2000L - (now - lastAt)).coerceAtLeast(100L)
                    pending = scope.launch { delay(wait); lastAt = SystemClock.elapsedRealtime(); refreshNotif() }
                }
            }
        }
        registerReceiver(brx, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        batteryRx = brx

        // Nama aplikasi di depan + keadaan rekam: dibaca tiap ~1,5 detik di thread latar, hanya saat layar nyala.
        // Notifikasi hanya dipasang ulang bila ada yang berubah.
        loopJob = scope.launch {
            var shown = "\u0000"; var lastRec = Recorder.active; var lastSec = -1; var polled = 0L
            while (isActive) {
                if (BatteryStats.isScreenOn()) {
                    if (MonitorPrefs.notifApp) {
                        val now = SystemClock.elapsedRealtime()
                        if (Recorder.active) {
                            // Saat merekam Sampler sudah membaca paket di depan; jangan jalankan dumpsys dua kali
                            val g = Sampler.lastGamePkg(); if (g.isNotEmpty()) { fgLabel = labelOf(g) }
                        } else if (now - polled >= 3000L && Shell.mode() != "-" || Foreground.hasAccess(this@RecService)) {
                            polled = now
                            val p = withContext(Dispatchers.IO) {
                                Foreground.ensureAccess(this@RecService)
                                Sampler.foregroundPkg()
                            }
                            if (p.isNotEmpty() && !Sampler.isTransientPkg(p, "")) fgLabel = labelOf(p)
                        }
                    } else fgLabel = ""
                    val rec = Recorder.active
                    val sec = if (rec) Recorder.count else -1
                    if (fgLabel != shown || rec != lastRec || sec != lastSec) {
                        shown = fgLabel; lastRec = rec; lastSec = sec; fgShown = fgLabel
                        refreshNotif()
                    }
                }
                delay(1500L)
            }
        }
    }

    // ---------- Siklus hidup ----------
    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val act = i?.action
        if (act == ACTION_COLLAPSE && alive) { collapseNotif(); return START_STICKY }
        // 1) Channel + startForeground SEGERA dengan notifikasi sederhana (batas waktu sistem ~10 detik)
        runCatching {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(CH, "Pantauan", NotificationManager.IMPORTANCE_LOW))
        }
        runCatching { fg(safeNotif()) }.onFailure { AppLog.w("Layanan", "startForeground gagal: ${it.javaClass.simpleName} ${it.message}") }
        MonitorPrefs.load(this)
        if (!MonitorPrefs.notifOn) { stopSelf(); return START_NOT_STICKY }
        Access.init(this)
        BatteryStats.init(this)
        if (!alive) {
            alive = true
            startHousekeeping()
            AppLog.i("Layanan", "notifikasi pantauan dimulai")
        }
        syncAnchor()
        // 2) Ganti dengan versi lengkap (bila gagal, yang sederhana tetap tampil)
        refreshNotif()
        if (act == ACTION_REC) RecCtl.toggle(this)
        scope.launch { delay(300L); refreshNotif() }
        return START_STICKY
    }

    /** Aplikasi di-swipe dari recents: sebagian ROM (MIUI / HyperOS) mematikan layanan juga; jadwalkan alarm pulih. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        MonitorPrefs.load(this)
        if (MonitorPrefs.notifOn) scheduleRestore(this, 1500L)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        AppLog.i("Layanan", "berhenti (onDestroy)")
        removeAnchor()
        screenRx?.let { runCatching { unregisterReceiver(it) } }; screenRx = null
        batteryRx?.let { runCatching { unregisterReceiver(it) } }; batteryRx = null
        loopJob?.cancel()
        scope.cancel()
        alive = false
        super.onDestroy()
    }
}
