package com.nexnon.engine

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Pengaturan notifikasi pantauan (baterai + tombol rekam FPS). State Compose supaya Settings langsung berubah. */
object MonitorPrefs {
    var notifOn by mutableStateOf(true)        // notifikasi pantauan hidup di latar belakang
    var notifApp by mutableStateOf(true)       // tampilkan nama aplikasi / game yang sedang di depan di notifikasi
    @Volatile private var loaded = false

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences("monitor", Context.MODE_PRIVATE)

    fun load(c: Context) {
        if (loaded) return
        val p = prefs(c)
        notifOn = p.getBoolean("notifOn", true); notifApp = p.getBoolean("notifApp", true)
        loaded = true
    }

    fun save(c: Context) { prefs(c).edit().putBoolean("notifOn", notifOn).putBoolean("notifApp", notifApp).apply() }
}

/** Mulai / berhenti rekam FPS. Dipakai tombol di Beranda dan tombol "Mulai rekam" di notifikasi. */
object RecCtl {
    private val main = Handler(Looper.getMainLooper())

    private fun toast(app: Context, s: String, long: Boolean = false) =
        main.post { Toast.makeText(app, s, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show() }

    fun toggle(ctx: Context) {
        val app = ctx.applicationContext
        if (Recorder.active) {
            Thread {
                val r = Recorder.stop(app)
                if (!OverlayService.running) Sampler.stop()   // overlay masih butuh sampler
                if (r != null) toast(app, "Rekaman tersimpan")
                else toast(app, "Tidak ada data FPS yang terekam\n${Recorder.lastFail}", true)
            }.start()
        } else {
            if (Shell.mode() == "-") { toast(app, "Butuh Shizuku atau Root untuk merekam"); return }
            Sampler.start(app)
            Sampler.onRecordStart()
            Recorder.start()
            // Tutup panel notifikasi supaya game kembali di depan dan tidak ikut menurunkan FPS
            Thread { runCatching { Shell.exec("cmd statusbar collapse") } }.start()
            toast(app, "Mulai merekam FPS")
        }
    }
}
