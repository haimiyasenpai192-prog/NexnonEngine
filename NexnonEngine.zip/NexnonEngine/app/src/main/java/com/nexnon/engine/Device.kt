package com.nexnon.engine

import android.os.Build

class DevInfo(val name: String = "Perangkat Android", val soc: String = "", val brand: String = "ANDROID", val android: String = "Android")

fun sysProp(k: String): String = runCatching {
    Class.forName("android.os.SystemProperties").getMethod("get", String::class.java).invoke(null, k) as String
}.getOrDefault("")

/** Sama seperti DeviceCard di Pulse Monitor: nama pasar, chipset, versi Android. */
fun loadDevInfo(): DevInfo {
    val market = sysProp("ro.product.marketname").ifEmpty { sysProp("ro.product.model") }.ifEmpty { Build.MODEL }
    val brand = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
    val name = if (market.startsWith(brand, true)) market else "$brand $market"
    val soc = if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotEmpty() && Build.SOC_MODEL != "unknown")
        "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}".trim() else Build.HARDWARE
    return DevInfo(name, soc, Build.BRAND.uppercase(), "Android ${Build.VERSION.RELEASE}")
}

fun fmtUp(ms: Long): String {
    val t = ms / 1000
    return "%dj %dm %dd".format(t / 3600, (t % 3600) / 60, t % 60)
}
