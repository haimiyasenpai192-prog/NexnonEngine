package com.nexnon.engine

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Satu sesi rekaman. Semua list sama panjang: satu nilai per sampel (kira-kira per detik). */
class Session(
    val id: Long, val pkg: String, val label: String, val res: String, var desc: String,
    val t: List<Float>, val fps: List<Float>,
    // Dari timestamp frame asli (--latency); kosong bila tidak terbaca
    val fN: List<Float> = emptyList(),       // jumlah frame per sampel
    val fMax: List<Float> = emptyList(),     // frametime terburuk per sampel (ms)
    val jank: List<Float> = emptyList(),
    val bigJank: List<Float> = emptyList(),
    val fTop: List<List<Float>> = emptyList(),  // frametime terburuk (ms, maks 12) per sampel
    // Sensor (nilai -1 = tidak terbaca; list kosong pada rekaman lama)
    val cpu: List<Float> = emptyList(), val gpu: List<Float> = emptyList(), val ram: List<Float> = emptyList(),
    val tCpu: List<Float> = emptyList(), val tGpu: List<Float> = emptyList(), val tBat: List<Float> = emptyList(),
    val watt: List<Float> = emptyList(), val tSkin: List<Float> = emptyList(),
    val clusters: List<Int> = emptyList(),              // inti pertama tiap cluster CPU (mis. 0, 4, 7)
    val clCpu: List<List<Float>> = emptyList(),         // beban CPU (%) per cluster, urut sama dengan clusters
    val clFreq: List<List<Float>> = emptyList(),        // frekuensi CPU (MHz) per cluster
    val gpuMhz: List<Float> = emptyList(),              // frekuensi GPU (MHz)
    val ddrMhz: List<Float> = emptyList(),              // frekuensi DDR / RAM fisik (MHz)
    val batLvl: List<Float> = emptyList()               // level baterai (%)
) {
    val n: Int get() = fps.size
    val dur: Int get() = Math.round(t.lastOrNull() ?: 0f)
    /** Suhu HP per sampel: sensor skin; bila tidak terbaca pakai suhu baterai (sensor terdekat ke badan HP). */
    val phoneTemp: List<Float> get() = List(n) { i ->
        val sk = tSkin.getOrElse(i) { -1f }; if (sk >= 0f) sk else tBat.getOrElse(i) { -1f }
    }
    /** Suhu tunggal untuk grafik FPS: suhu baterai. */
    val temp: List<Float> get() = List(n) { i -> tBat.getOrElse(i) { -1f } }
    /**
     * Suhu gabungan untuk garis Temperatur (kuning) di grafik FPS: rata-rata suhu CPU dan GPU, lalu dihaluskan ringan ([smoothTemp]).
     * Sensor CPU/GPU melonjak tajam mengikuti beban; lonjakannya dilunakkan, tapi naik-turun kecil tetap terlihat (tidak dibuat datar).
     * Bila salah satu tidak terbaca (-1), pakai yang terbaca.
     */
    val tHot: List<Float> get() = List(n) { i ->
        val c = tCpu.getOrElse(i) { -1f }; val g = tGpu.getOrElse(i) { -1f }
        when {
            c >= 0f && g >= 0f -> (c + g) / 2f
            c >= 0f -> c
            else -> g
        }
    }.smoothTemp()
    /** Potongan " · 1920x886" untuk header; kosong bila resolusi tidak terbaca. */
    val resPart: String get() = if (res.isBlank()) "" else "  ·  $res"
}

class Stats(
    val max: Float, val min: Float, val avg: Float, val sd: Float, val smooth: Float, val low5: Float,
    val low1: Float = 0f, val ftAvg: Float = 0f, val ftMax: Float = 0f, val drops: Int = 0,
    val jank: Int = 0, val bigJank: Int = 0, val frameBased: Boolean = false,   // frameBased: low5 / low1 / ftMax dari frame asli
    val maxTemp: Float = -1f, val avgWatt: Float = -1f, val energyMwh: Float = -1f
)

class FrameLows(val low5: Float, val low1: Float, val maxMs: Float, val jank: Int, val bigJank: Int, val frames: Int)

/**
 * 5% / 1% low = 1000 / rata-rata frametime dari 5% / 1% frame TERBURUK di seluruh rekaman (definisi PerfDog).
 * Dipakai hanya bila frame terbaca >= 70% dari yang diharapkan dari FPS rekaman; kalau tidak, pakai hitungan dari FPS per detik.
 */
fun Session.frameLows(): FrameLows? {
    val total = fN.filter { it > 0f }.sum().toInt()
    val expected = fps.filter { it > 0f }.sum()
    if (total < 60 || total < expected * 0.7f) return null
    val top = fTop.flatten().sortedDescending()
    if (top.isEmpty()) return null
    fun low(pct: Int): Float {
        val k = maxOf(1, total * pct / 100).coerceAtMost(top.size)
        val ms = top.take(k).average().toFloat()
        return if (ms > 0f) 1000f / ms else 0f
    }
    return FrameLows(low(5), low(1), top.first(), jank.filter { it > 0f }.sum().toInt(), bigJank.filter { it > 0f }.sum().toInt(), total)
}

fun Session.stats(): Stats {
    // Statistik memakai deret yang SAMA dengan grafik FPS (capFps saja). Dulu ditambah despike() (median 3 titik) yang menghapus
    // penurunan 1 detik: di grafik ada drop, tapi Min tetap 60,0 dan Drop 0. Lonjakan atas tetap dipotong capFps.
    val series = capFps(fps)
    val f = series.filter { it > 0f }
    if (f.isEmpty()) return Stats(0f, 0f, 0f, 0f, 0f, 0f)
    // fz = f + freeze nyata: >= 2 sampel (detik) berturut-turut 0 FPS di tengah rekaman ikut dihitung (Min / Average / Variance / Low),
    // 0 tunggal dianggap glitch baca dan dibuang seperti sebelumnya. Frametime tetap dari f (tidak bisa 1000 / 0).
    val fz = withFreezes(series)
    val freezeSec = fz.count { it <= 0f }
    val avg = fz.average().toFloat()
    // Variance = rata-rata kuadrat selisih tiap sampel FPS terhadap rata-rata (varians populasi, TIDAK diakar).
    // Dulu diakar (simpangan baku), jadi angkanya jauh lebih kecil (mis. 3,0 padahal variance-nya ~9). Nama field tetap `sd`.
    val sd = fz.map { (it - avg) * (it - avg) }.average().toFloat()
    val sorted = fz.sorted(); val k = maxOf(1, sorted.size * 5 / 100)
    val low = sorted.take(k).average().toFloat()
    // Kehalusan (Relative / Smoothness) = persen sampel FPS yang masih dalam +-10% dari FPS rata-rata.
    // Dulu pakai ambang tetap ">= 45 FPS" (rumus Scene), sehingga selalu 100% selama FPS tidak turun di bawah 45 walau grafiknya naik-turun.
    val tol = avg * 0.1f
    val smooth = 100f * fz.count { kotlin.math.abs(it - avg) <= tol } / fz.size
    val low1 = sorted.take(maxOf(1, sorted.size / 100)).average().toFloat()
    val fts = f.map { 1000f / it }
    val fl = frameLows()
    // Drop = detik dengan FPS < 90% dari FPS tengah rekaman, atau detik yang memuat Jank / BigJank (frame macet > 83 ms).
    // Dulu hanya hitung FPS < 70% rata-rata pada deret yang sudah di-despike, sehingga stutter pendek tidak pernah terhitung.
    val baseFps = f.sorted().let { it[it.size / 2] }
    var drops = 0
    for (i in series.indices) {
        val v = series[i]; if (v <= 0f) continue
        if (v < baseFps * 0.9f || jank.getOrElse(i) { 0f } + bigJank.getOrElse(i) { 0f } > 0f) drops++
    }
    drops += freezeSec   // detik freeze (0 FPS) juga drop
    // Frame avg asli = durasi / jumlah frame terbaca (bukan 1000 / FPS per detik yang selalu terlihat rata)
    val ftAvgReal = if (fl != null && fl.frames > 0 && dur > 0) dur * 1000f / fl.frames else fts.average().toFloat()
    val mt = temp.despike().filter { it >= 0f }.maxOrNull() ?: phoneTemp.despike().filter { it >= 0f }.maxOrNull() ?: -1f   // kartu Temperatur = suhu baterai (sensor skin hanya cadangan)
    val w = watt.avgValid()
    val energy = if (w >= 0f) w * dur / 3.6f else -1f   // mWh = W x detik / 3,6
    return Stats(f.maxOrNull() ?: 0f, fz.minOrNull() ?: 0f, avg, sd, smooth, fl?.low5 ?: low,
        low1 = fl?.low1 ?: low1, ftAvg = ftAvgReal, ftMax = fl?.maxMs ?: (fts.maxOrNull() ?: 0f),
        drops = drops, jank = fl?.jank ?: 0, bigJank = fl?.bigJank ?: 0, frameBased = fl != null,
        maxTemp = mt, avgWatt = w, energyMwh = energy)
}

/** Buang nilai 0 yang berdiri sendiri (glitch baca); jalur 0 sepanjang >= 2 sampel berturut-turut dipertahankan sebagai freeze nyata. */
fun withFreezes(v: List<Float>): List<Float> {
    val out = ArrayList<Float>(v.size)
    var i = 0
    while (i < v.size) {
        if (v[i] > 0f) { out.add(v[i]); i++; continue }
        var j = i; while (j < v.size && v[j] <= 0f) j++
        if (j - i >= 2) repeat(j - i) { out.add(0f) }
        i = j
    }
    return out
}

/** Batas atas FPS dari rekaman itu sendiri: persentil 90 x 1,05 (game 60 -> ~63). Hanya memotong yang melewati batas. */
fun capFps(v: List<Float>): List<Float> {
    val ok = v.filter { it > 0f }.sorted()
    if (ok.size < 10) return v
    val cap = ok[((ok.size - 1) * 0.9f).toInt()] * 1.05f
    return v.map { if (it > cap) cap else it }
}

/** Buang lonjakan satu sampel: tiap titik diganti median tiga titik di sekitarnya. */
fun List<Float>.despike(): List<Float> = when {
    size < 3 -> this
    else -> List(size) { i ->
        when (i) {
            0 -> minOf(this[0], this[1]).let { if (this[1] < 0f) this[0] else it }
            size - 1 -> minOf(this[i], this[i - 1]).let { if (this[i - 1] < 0f) this[i] else it }
            else -> listOf(this[i - 1], this[i], this[i + 1]).sorted()[1]
        }
    }
}

/**
 * Haluskan deret suhu tanpa membuatnya datar: isi nilai tak terbaca (-1), batasi perubahan antar sampel maks. 0,8 derajat
 * (lonjakan sensor 10 derajat jadi gundukan kecil 2-3 derajat, naik-turun landai tetap terlihat), lalu rata-rata 3 titik.
 */
fun List<Float>.smoothTemp(): List<Float> {
    if (size < 3) return this
    var last = firstOrNull { it >= 0f } ?: return this
    val filled = map { if (it >= 0f) { last = it; it } else last }
    val limited = ArrayList<Float>(filled.size)
    var prev = filled[0]
    for (v in filled) {
        prev = prev + (v - prev).coerceIn(-0.8f, 0.8f)
        limited.add(prev)
    }
    val n = limited.size
    return List(n) { i -> limited.subList(maxOf(0, i - 1), minOf(n, i + 2)).average().toFloat() }
}

fun List<Float>.avgValid(): Float { val v = filter { it >= 0f }; return if (v.isEmpty()) -1f else v.average().toFloat() }
fun List<Float>.maxValid(): Float = filter { it >= 0f }.maxOrNull() ?: -1f
fun fmtDur(sec: Int) = "%d:%02d".format(sec / 60, sec % 60)
fun fmtDate(ms: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(ms))
fun f1(x: Float) = "%.1f".format(x).replace('.', ',')
fun f2(x: Float) = "%.2f".format(x).replace('.', ',')

/** Merekam Snap dari Sampler. Disimpan sebagai JSON di filesDir/records. */
object Recorder {
    var active by mutableStateOf(false); private set
    var count by mutableIntStateOf(0); private set       // jumlah sampel yang sudah terekam
    var version by mutableIntStateOf(0); private set     // naik tiap ada rekaman baru / dihapus, supaya daftar dimuat ulang
    var lastFps by mutableIntStateOf(0); private set      // FPS sampel terakhir (untuk teks "xx FPS saat ini")
    private val buf = ArrayList<Snap>()
    private val ts = ArrayList<Long>()
    private var stopping = false
    /** Alasan stop() terakhir mengembalikan null; ditampilkan di toast supaya mudah didiagnosis. */
    @Volatile var lastFail = ""

    @Synchronized fun start() {
        if (active) return
        buf.clear(); ts.clear(); count = 0; lastFps = 0; stopping = false; active = true
    }

    /** Dipanggil Sampler tiap tick. */
    @Synchronized fun onSample(s: Snap) {
        if (!active || stopping) return
        buf.add(s); ts.add(System.currentTimeMillis()); count = buf.size; lastFps = Math.round(s.fps)
    }

    /** Hentikan dan simpan. Null bila tidak ada data FPS. Panggil dari thread latar (menulis file). */
    fun stop(ctx: Context): Session? {
        var data: List<Snap> = emptyList(); var times: List<Long> = emptyList()
        synchronized(this) {
            if (!active || stopping) { lastFail = "rekaman tidak aktif / sedang berhenti"; return null }
            stopping = true; data = ArrayList(buf); times = ArrayList(ts)
        }
        try {
            val first = data.indexOfFirst { it.fps > 0f }; val last = data.indexOfLast { it.fps > 0f }
            if (first < 0) { lastFail = "${data.size} sampel, tidak ada FPS terbaca | ${Sampler.fpsDiag()}"; return null }
            val d = data.subList(first, last + 1); val tt = times.subList(first, last + 1)
            val own = ctx.packageName
            fun top(l: List<Snap>) = l.filter { !Sampler.isIgnoredPkg(it.pkg, own) }
                .groupingBy { it.pkg }.eachCount().maxByOrNull { it.value }?.key
            // Nama game: paket terbanyak di sampel ber-FPS; bila kosong seluruh sampel; bila masih kosong app terakhir di depan
            val pkg = top(d.filter { it.fps > 0f }) ?: top(data)
                ?: Sampler.lastGamePkg().takeIf { !Sampler.isIgnoredPkg(it, own) } ?: ""
            val label = if (pkg.isEmpty()) "Rekaman" else runCatching {
                val pm = ctx.packageManager; pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            }.getOrDefault(pkg)
            val cids = d.flatMap { sn -> sn.clusterCpu.map { it.first } }.distinct().sorted()
            val s = Session(
                id = System.currentTimeMillis(), pkg = pkg, label = label, res = Resolution.game(ctx, pkg), desc = "",
                t = tt.map { (it - tt[0]) / 1000f }, fps = d.map { it.fps },
                fN = d.map { it.ftN.toFloat() }, fMax = d.map { it.ftMaxMs }, jank = d.map { it.jank.toFloat() },
                bigJank = d.map { it.bigJank.toFloat() }, fTop = d.map { it.ftTop },
                cpu = d.map { it.cpu.toFloat() }, gpu = d.map { it.gpu.toFloat() }, ram = d.map { it.ramPct.toFloat() },
                tCpu = d.map { it.tCpu }, tGpu = d.map { it.tGpu }, tBat = d.map { it.tBat }, watt = d.map { it.watt }, tSkin = d.map { it.tSkin },
                clusters = cids,
                clCpu = cids.map { id -> d.map { sn -> sn.clusterCpu.firstOrNull { it.first == id }?.second?.toFloat() ?: -1f } },
                // Frekuensi cluster = yang tertinggi di antara inti-intinya (inti pertama bisa saja mati), -1 bila tidak terbaca
                clFreq = cids.mapIndexed { ci, id ->
                    val end = cids.getOrElse(ci + 1) { Int.MAX_VALUE }
                    d.map { sn -> sn.coreMhz.withIndex().filter { it.index in id until end && it.value > 0 }.maxOfOrNull { it.value }?.toFloat() ?: -1f }
                }.takeIf { fr -> fr.any { l -> l.any { it >= 0f } } } ?: emptyList(),
                gpuMhz = d.map { it.gpuMhz.toFloat() }, ddrMhz = d.map { it.ddrMhz.toFloat() }, batLvl = d.map { it.batPct.toFloat() }
            )
            save(ctx, s)
            AppLog.i("Rekam", "${s.label} ${s.dur}s, ${s.n} sampel, rata-rata ${f1(s.stats().avg)} FPS")
            return s
        } finally {
            synchronized(this) { stopping = false; active = false; buf.clear(); ts.clear(); count = 0 }
            version += 1
        }
    }

    private fun dir(c: Context) = File(c.filesDir, "records").also { it.mkdirs() }
    private fun arr(l: List<Float>) = JSONArray().also { a -> l.forEach { a.put(Math.round(it * 10f) / 10.0) } }

    private fun toJson(s: Session) = JSONObject().apply {
        put("id", s.id); put("pkg", s.pkg); put("label", s.label); put("res", s.res); put("desc", s.desc)
        put("t", arr(s.t)); put("fps", arr(s.fps))
        put("fN", arr(s.fN)); put("fMax", arr(s.fMax)); put("jank", arr(s.jank)); put("bigJank", arr(s.bigJank))
        put("fTop", JSONArray().also { a -> s.fTop.forEach { a.put(arr(it)) } })
        put("cpu", arr(s.cpu)); put("gpu", arr(s.gpu)); put("ram", arr(s.ram))
        put("tCpu", arr(s.tCpu)); put("tGpu", arr(s.tGpu)); put("tBat", arr(s.tBat)); put("tSkin", arr(s.tSkin)); put("watt", arr(s.watt))
        put("clusters", JSONArray().also { a -> s.clusters.forEach { a.put(it) } })
        put("clCpu", JSONArray().also { a -> s.clCpu.forEach { a.put(arr(it)) } })
        put("clFreq", JSONArray().also { a -> s.clFreq.forEach { a.put(arr(it)) } })
        put("gpuMhz", arr(s.gpuMhz)); put("ddrMhz", arr(s.ddrMhz)); put("batLvl", arr(s.batLvl))
    }

    private fun floats(o: JSONObject, k: String): List<Float> {
        val a = o.optJSONArray(k) ?: return emptyList()
        return List(a.length()) { a.optDouble(it, -1.0).toFloat() }
    }

    private fun fit(l: List<Float>, n: Int, fill: Float) = if (l.size >= n) l.take(n) else l + List(n - l.size) { fill }
    private fun opt(o: JSONObject, k: String, n: Int): List<Float> = floats(o, k).let { if (it.isEmpty()) it else fit(it, n, -1f) }

    private fun parse(txt: String): Session {
        val o = JSONObject(txt)
        val fps = floats(o, "fps"); val n = fps.size
        val t = floats(o, "t").let { if (it.size >= n) it.take(n) else it + List(n - it.size) { i -> (it.size + i).toFloat() } }
        return Session(
            o.getLong("id"), o.optString("pkg"), o.optString("label"), o.optString("res"), o.optString("desc"), t, fps,
            fN = opt(o, "fN", n), fMax = opt(o, "fMax", n), jank = opt(o, "jank", n), bigJank = opt(o, "bigJank", n),
            fTop = o.optJSONArray("fTop")?.let { a ->
                List(a.length()) { k -> a.optJSONArray(k)?.let { b -> List(b.length()) { b.optDouble(it, 0.0).toFloat() } } ?: emptyList() }
            } ?: emptyList(),
            cpu = opt(o, "cpu", n), gpu = opt(o, "gpu", n), ram = opt(o, "ram", n),
            tCpu = opt(o, "tCpu", n), tGpu = opt(o, "tGpu", n), tBat = opt(o, "tBat", n), watt = opt(o, "watt", n), tSkin = opt(o, "tSkin", n),
            clusters = o.optJSONArray("clusters")?.let { a -> List(a.length()) { a.optInt(it, 0) } } ?: emptyList(),
            clCpu = o.optJSONArray("clCpu")?.let { a ->
                List(a.length()) { k -> a.optJSONArray(k)?.let { b -> fit(List(b.length()) { b.optDouble(it, -1.0).toFloat() }, n, -1f) } ?: List(n) { -1f } }
            } ?: emptyList(),
            clFreq = o.optJSONArray("clFreq")?.let { a ->
                List(a.length()) { k -> a.optJSONArray(k)?.let { b -> fit(List(b.length()) { b.optDouble(it, -1.0).toFloat() }, n, -1f) } ?: List(n) { -1f } }
            } ?: emptyList(),
            gpuMhz = opt(o, "gpuMhz", n), ddrMhz = opt(o, "ddrMhz", n), batLvl = opt(o, "batLvl", n)
        )
    }

    fun save(c: Context, s: Session) {
        val f = File(dir(c), "${s.id}.json"); val tmp = File(dir(c), "${s.id}.tmp")
        tmp.writeText(toJson(s).toString())
        if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
    }

    fun saveDesc(c: Context, s: Session, text: String) { s.desc = text; runCatching { save(c, s) } }
    fun load(c: Context, id: Long): Session? = runCatching { parse(File(dir(c), "$id.json").readText()) }.getOrNull()

    fun list(c: Context): List<Session> =
        dir(c).listFiles { f -> f.extension == "json" }?.mapNotNull { f -> runCatching { parse(f.readText()) }.getOrNull() }
            ?.sortedByDescending { it.id } ?: emptyList()

    fun delete(c: Context, id: Long) { File(dir(c), "$id.json").delete(); version += 1 }

    fun csv(s: Session): String {
        val sb = StringBuilder("time_s,fps,frametime_ms,cpu_pct,gpu_pct,ram_pct,temp_cpu,temp_gpu,temp_bat,temp_hp,power_w" +
            s.clusters.joinToString("") { ",cpu_cluster$it" } +
            (if (s.clFreq.isNotEmpty()) s.clusters.joinToString("") { ",freq_cluster${it}_mhz" } else "") +
            csvExtra(s).joinToString("") { "," + it.first } + "\n")
        val pt = s.phoneTemp
        fun at(l: List<Float>, i: Int) = l.getOrElse(i) { -1f }
        for (i in 0 until s.n) {
            val f = s.fps[i]
            sb.append("%.1f,%.1f,%.1f,%.0f,%.0f,%.0f,%.1f,%.1f,%.1f,%.1f,%.2f".format(
                Locale.US, s.t[i], f, if (f > 0f) 1000f / f else 0f, at(s.cpu, i), at(s.gpu, i), at(s.ram, i),
                at(s.tCpu, i), at(s.tGpu, i), at(s.tBat, i), pt[i], at(s.watt, i)))
            s.clCpu.forEach { sb.append(",%.0f".format(Locale.US, it.getOrElse(i) { -1f })) }
            s.clFreq.forEach { sb.append(",%.0f".format(Locale.US, it.getOrElse(i) { -1f })) }
            csvExtra(s).forEach { sb.append(",%.0f".format(Locale.US, it.second.getOrElse(i) { -1f })) }
            sb.append('\n')
        }
        return sb.toString()
    }

    private fun csvExtra(s: Session) = listOf("gpu_mhz" to s.gpuMhz, "ddr_mhz" to s.ddrMhz, "battery_pct" to s.batLvl,
        "frame_count" to s.fN, "frame_max_ms" to s.fMax, "jank" to s.jank, "big_jank" to s.bigJank)
        .filter { it.second.isNotEmpty() }

    /** Simpan CSV ke folder Download (MediaStore, tanpa izin storage). */
    fun exportCsv(c: Context, s: Session): Boolean = runCatching {
        val safe = s.label.replace(Regex("[^A-Za-z0-9]+"), "_")
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(s.id))
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "NexnonEngine_${safe}_$stamp.csv")
            put(MediaStore.Downloads.MIME_TYPE, "text/csv")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
        c.contentResolver.openOutputStream(uri)!!.use { it.write(csv(s).toByteArray()) }
    }.isSuccess

    fun summary(s: Session): String {
        val st = s.stats()
        return buildString {
            append("Nexnon Engine - ${s.label}\n${fmtDate(s.id)}  (${fmtDur(s.dur)})\n")
            if (s.desc.isNotBlank()) append("${s.desc}\n")
            append("FPS rata-rata ${f1(st.avg)}\n")
            append("Min ${"%.0f".format(st.min)}, Maks ${"%.0f".format(st.max)}, 5% low ${f1(st.low5)} FPS, kehalusan ${f1(st.smooth)}%\n")
            if (st.frameBased) append("1% low ${f1(st.low1)} FPS, frame terburuk ${f1(st.ftMax)} ms, Jank ${st.jank}, BigJank ${st.bigJank}\n")
            if (st.maxTemp >= 0f) append("Suhu HP ${"%.0f".format(st.maxTemp)}°C\n")
            if (st.avgWatt >= 0f) append("Daya rata-rata ${f1(st.avgWatt)} W\n")
        }
    }
}
