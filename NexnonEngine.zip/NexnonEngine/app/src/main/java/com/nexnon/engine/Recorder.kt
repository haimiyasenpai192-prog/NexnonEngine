package com.nexnon.engine

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sqrt

/** Satu sesi rekaman. Semua list sama panjang: satu nilai per sampel (kira-kira per detik). */
class Session(
    val id: Long, val pkg: String, val label: String, val res: String, var desc: String,
    val t: List<Float>, val fps: List<Float>,
    // Dari timestamp frame asli (--latency); kosong bila tidak terbaca
    val fN: List<Float> = emptyList(),       // jumlah frame per sampel
    val fMax: List<Float> = emptyList(),     // frametime terburuk per sampel (ms)
    val jank: List<Float> = emptyList(),
    val bigJank: List<Float> = emptyList(),
    val fTop: List<List<Float>> = emptyList()   // frametime terburuk (ms, maks 12) per sampel
) {
    val n: Int get() = fps.size
    val dur: Int get() = Math.round(t.lastOrNull() ?: 0f)
}

class Stats(
    val max: Float, val min: Float, val avg: Float, val sd: Float, val smooth: Float, val low5: Float,
    val low1: Float = 0f, val ftAvg: Float = 0f, val ftMax: Float = 0f, val drops: Int = 0,
    val jank: Int = 0, val bigJank: Int = 0, val frameBased: Boolean = false   // frameBased: low5 / low1 / ftMax dari frame asli
)

class FrameLows(val low5: Float, val low1: Float, val maxMs: Float, val jank: Int, val bigJank: Int, val frames: Int)

/**
 * 5% / 1% low = 1000 / rata-rata frametime dari 5% / 1% frame TERBURUK di seluruh rekaman (definisi PerfDog).
 * Dipakai hanya bila frame terbaca >= 70% dari yang diharapkan dari FPS rekaman; kalau tidak, pakai hitungan dari FPS per detik.
 */
fun Session.frameLows(): FrameLows? {
    val total = fN.filter { it > 0f }.sum().toInt()
    val expected = fps.filter { it > 0f }.sum()
    if (total < 60 || total < expected * 0.7f) return null
    val top = fTop.flatten().sortedDescending()
    if (top.isEmpty()) return null
    fun low(pct: Int): Float {
        val k = maxOf(1, total * pct / 100).coerceAtMost(top.size)
        val ms = top.take(k).average().toFloat()
        return if (ms > 0f) 1000f / ms else 0f
    }
    return FrameLows(low(5), low(1), top.first(), jank.filter { it > 0f }.sum().toInt(), bigJank.filter { it > 0f }.sum().toInt(), total)
}

fun Session.stats(): Stats {
    // despike(): lonjakan satu sampel (glitch baca) tidak boleh jadi MAKS 100 / MIN 0,8. Penurunan >= 2 sampel tetap terhitung lag.
    val f = capFps(fps).despike().filter { it > 0f }
    if (f.isEmpty()) return Stats(0f, 0f, 0f, 0f, 0f, 0f)
    val avg = f.average().toFloat()
    val sd = sqrt(f.map { (it - avg) * (it - avg) }.average()).toFloat()
    val sorted = f.sorted(); val k = maxOf(1, sorted.size * 5 / 100)
    val low = sorted.take(k).average().toFloat()
    val smooth = if (avg > 0f) (100f * (1f - sd / avg)).coerceIn(0f, 100f) else 0f
    val low1 = sorted.take(maxOf(1, sorted.size / 100)).average().toFloat()
    val fts = f.map { 1000f / it }
    val fl = frameLows()
    return Stats(f.maxOrNull() ?: 0f, f.minOrNull() ?: 0f, avg, sd, smooth, fl?.low5 ?: low,
        low1 = fl?.low1 ?: low1, ftAvg = fts.average().toFloat(), ftMax = fl?.maxMs ?: (fts.maxOrNull() ?: 0f),
        drops = f.count { it < avg * 0.7f }, jank = fl?.jank ?: 0, bigJank = fl?.bigJank ?: 0, frameBased = fl != null)
}

/** Batas atas FPS dari rekaman itu sendiri: persentil 90 x 1,05 (game 60 -> ~63). Hanya memotong yang melewati batas. */
fun capFps(v: List<Float>): List<Float> {
    val ok = v.filter { it > 0f }.sorted()
    if (ok.size < 10) return v
    val cap = ok[((ok.size - 1) * 0.9f).toInt()] * 1.05f
    return v.map { if (it > cap) cap else it }
}

/** Buang lonjakan satu sampel: tiap titik diganti median tiga titik di sekitarnya. */
fun List<Float>.despike(): List<Float> = when {
    size < 3 -> this
    else -> List(size) { i ->
        when (i) {
            0 -> minOf(this[0], this[1]).let { if (this[1] < 0f) this[0] else it }
            size - 1 -> minOf(this[i], this[i - 1]).let { if (this[i - 1] < 0f) this[i] else it }
            else -> listOf(this[i - 1], this[i], this[i + 1]).sorted()[1]
        }
    }
}

fun fmtDur(sec: Int) = "%d:%02d".format(sec / 60, sec % 60)
fun fmtDate(ms: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(ms))
fun f1(x: Float) = "%.1f".format(x).replace('.', ',')

/** Merekam Snap dari Sampler. Disimpan sebagai JSON di filesDir/records. */
object Recorder {
    var active by mutableStateOf(false); private set
    var count by mutableIntStateOf(0); private set       // jumlah sampel yang sudah terekam
    var version by mutableIntStateOf(0); private set     // naik tiap ada rekaman baru / dihapus, supaya daftar dimuat ulang
    var lastFps by mutableIntStateOf(0); private set      // FPS sampel terakhir (untuk teks "xx FPS saat ini")
    private val buf = ArrayList<Snap>()
    private val ts = ArrayList<Long>()
    private var stopping = false
    /** Alasan stop() terakhir mengembalikan null; ditampilkan di toast supaya mudah didiagnosis. */
    @Volatile var lastFail = ""

    @Synchronized fun start() {
        if (active) return
        buf.clear(); ts.clear(); count = 0; lastFps = 0; stopping = false; active = true
    }

    /** Dipanggil Sampler tiap tick. */
    @Synchronized fun onSample(s: Snap) {
        if (!active || stopping) return
        buf.add(s); ts.add(System.currentTimeMillis()); count = buf.size; lastFps = Math.round(s.fps)
    }

    /** Hentikan dan simpan. Null bila tidak ada data FPS. Panggil dari thread latar (menulis file). */
    fun stop(ctx: Context): Session? {
        var data: List<Snap> = emptyList(); var times: List<Long> = emptyList()
        synchronized(this) {
            if (!active || stopping) { lastFail = "rekaman tidak aktif / sedang berhenti"; return null }
            stopping = true; data = ArrayList(buf); times = ArrayList(ts)
        }
        try {
            val first = data.indexOfFirst { it.fps > 0f }; val last = data.indexOfLast { it.fps > 0f }
            if (first < 0) { lastFail = "${data.size} sampel, tidak ada FPS terbaca | ${Sampler.fpsDiag()}"; return null }
            val d = data.subList(first, last + 1); val tt = times.subList(first, last + 1)
            val own = ctx.packageName
            fun top(l: List<Snap>) = l.filter { !Sampler.isIgnoredPkg(it.pkg, own) }
                .groupingBy { it.pkg }.eachCount().maxByOrNull { it.value }?.key
            // Nama game: paket terbanyak di sampel ber-FPS; bila kosong seluruh sampel; bila masih kosong app terakhir di depan
            val pkg = top(d.filter { it.fps > 0f }) ?: top(data)
                ?: Sampler.lastGamePkg().takeIf { !Sampler.isIgnoredPkg(it, own) } ?: ""
            val label = if (pkg.isEmpty()) "Rekaman" else runCatching {
                val pm = ctx.packageManager; pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            }.getOrDefault(pkg)
            val s = Session(
                id = System.currentTimeMillis(), pkg = pkg, label = label, res = "", desc = "",
                t = tt.map { (it - tt[0]) / 1000f }, fps = d.map { it.fps },
                fN = d.map { it.ftN.toFloat() }, fMax = d.map { it.ftMaxMs }, jank = d.map { it.jank.toFloat() },
                bigJank = d.map { it.bigJank.toFloat() }, fTop = d.map { it.ftTop }
            )
            save(ctx, s)
            AppLog.i("Rekam", "${s.label} ${s.dur}s, ${s.n} sampel, rata-rata ${f1(s.stats().avg)} FPS")
            return s
        } finally {
            synchronized(this) { stopping = false; active = false; buf.clear(); ts.clear(); count = 0 }
            version += 1
        }
    }

    private fun dir(c: Context) = File(c.filesDir, "records").also { it.mkdirs() }
    private fun arr(l: List<Float>) = JSONArray().also { a -> l.forEach { a.put(Math.round(it * 10f) / 10.0) } }

    private fun toJson(s: Session) = JSONObject().apply {
        put("id", s.id); put("pkg", s.pkg); put("label", s.label); put("res", s.res); put("desc", s.desc)
        put("t", arr(s.t)); put("fps", arr(s.fps))
        put("fN", arr(s.fN)); put("fMax", arr(s.fMax)); put("jank", arr(s.jank)); put("bigJank", arr(s.bigJank))
        put("fTop", JSONArray().also { a -> s.fTop.forEach { a.put(arr(it)) } })
    }

    private fun floats(o: JSONObject, k: String): List<Float> {
        val a = o.optJSONArray(k) ?: return emptyList()
        return List(a.length()) { a.optDouble(it, -1.0).toFloat() }
    }

    private fun fit(l: List<Float>, n: Int, fill: Float) = if (l.size >= n) l.take(n) else l + List(n - l.size) { fill }
    private fun opt(o: JSONObject, k: String, n: Int): List<Float> = floats(o, k).let { if (it.isEmpty()) it else fit(it, n, -1f) }

    private fun parse(txt: String): Session {
        val o = JSONObject(txt)
        val fps = floats(o, "fps"); val n = fps.size
        val t = floats(o, "t").let { if (it.size >= n) it.take(n) else it + List(n - it.size) { i -> (it.size + i).toFloat() } }
        return Session(
            o.getLong("id"), o.optString("pkg"), o.optString("label"), o.optString("res"), o.optString("desc"), t, fps,
            fN = opt(o, "fN", n), fMax = opt(o, "fMax", n), jank = opt(o, "jank", n), bigJank = opt(o, "bigJank", n),
            fTop = o.optJSONArray("fTop")?.let { a ->
                List(a.length()) { k -> a.optJSONArray(k)?.let { b -> List(b.length()) { b.optDouble(it, 0.0).toFloat() } } ?: emptyList() }
            } ?: emptyList()
        )
    }

    fun save(c: Context, s: Session) {
        val f = File(dir(c), "${s.id}.json"); val tmp = File(dir(c), "${s.id}.tmp")
        tmp.writeText(toJson(s).toString())
        if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
    }

    fun saveDesc(c: Context, s: Session, text: String) { s.desc = text; runCatching { save(c, s) } }
    fun load(c: Context, id: Long): Session? = runCatching { parse(File(dir(c), "$id.json").readText()) }.getOrNull()

    fun list(c: Context): List<Session> =
        dir(c).listFiles { f -> f.extension == "json" }?.mapNotNull { f -> runCatching { parse(f.readText()) }.getOrNull() }
            ?.sortedByDescending { it.id } ?: emptyList()

    fun delete(c: Context, id: Long) { File(dir(c), "$id.json").delete(); version += 1 }

    fun csv(s: Session): String {
        val extra = listOf("frame_count" to s.fN, "frame_max_ms" to s.fMax, "jank" to s.jank, "big_jank" to s.bigJank).filter { it.second.isNotEmpty() }
        val sb = StringBuilder("time_s,fps,frametime_ms" + extra.joinToString("") { "," + it.first } + "\n")
        for (i in 0 until s.n) {
            val f = s.fps[i]
            sb.append("%.1f,%.1f,%.1f".format(Locale.US, s.t[i], f, if (f > 0f) 1000f / f else 0f))
            extra.forEach { sb.append(",%.1f".format(Locale.US, it.second.getOrElse(i) { -1f })) }
            sb.append('\n')
        }
        return sb.toString()
    }

    /** Simpan CSV ke folder Download (MediaStore, tanpa izin storage). */
    fun exportCsv(c: Context, s: Session): Boolean = runCatching {
        val safe = s.label.replace(Regex("[^A-Za-z0-9]+"), "_")
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(s.id))
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "NexnonEngine_${safe}_$stamp.csv")
            put(MediaStore.Downloads.MIME_TYPE, "text/csv")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
        c.contentResolver.openOutputStream(uri)!!.use { it.write(csv(s).toByteArray()) }
    }.isSuccess

    fun summary(s: Session): String {
        val st = s.stats()
        return buildString {
            append("Nexnon Engine - ${s.label}\n${fmtDate(s.id)}  (${fmtDur(s.dur)})\n")
            if (s.desc.isNotBlank()) append("${s.desc}\n")
            append("FPS rata-rata ${f1(st.avg)}\n")
            append("Min ${"%.0f".format(st.min)}, Maks ${"%.0f".format(st.max)}, 5% low ${f1(st.low5)} FPS, kehalusan ${f1(st.smooth)}%\n")
            if (st.frameBased) append("1% low ${f1(st.low1)} FPS, frame terburuk ${f1(st.ftMax)} ms, Jank ${st.jank}, BigJank ${st.bigJank}\n")
        }
    }
}
