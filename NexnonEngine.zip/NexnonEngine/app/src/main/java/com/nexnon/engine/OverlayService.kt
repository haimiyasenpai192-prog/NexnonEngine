package com.nexnon.engine

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.*
import kotlin.math.abs

/**
 * Overlay FPS di atas aplikasi lain, tiga gaya seperti PulseMonitor:
 *  0 Simple  : satu baris teks (FPS, CPU, GPU, RAM, BAT)
 *  1 Normal  : FPS besar + cincin CPU / GPU + baris RAM / BAT (NormalOverlayView)
 *  2 Compact : bilah per baris FPS / CPU / GPU + baris BAT / TMP (BarOverlayView)
 *  3 Kotak   : deretan kotak angka FPS / CPU / GPU / BAT / TCH (TileOverlayView)
 * Geser = pindah posisi, ketuk = pilih gaya, tahan 1 detik = mulai / berhenti rekam.
 * Data dari Sampler.live (butuh Shizuku atau Root, sama seperti perekam).
 */
class OverlayService : Service() {
    companion object {
        @Volatile var running = false
        private const val CH = "overlay"
        private const val NID = 2

        /** Nyalakan atau matikan layanan sesuai OverlayPrefs.on dan izin "Tampil di atas aplikasi lain". */
        fun sync(ctx: Context) {
            val app = ctx.applicationContext
            OverlayPrefs.load(app)
            val i = Intent(app, OverlayService::class.java)
            if (OverlayPrefs.on && Settings.canDrawOverlays(app)) runCatching { app.startForegroundService(i) }
            else app.stopService(i)
        }

        fun openPermission(ctx: Context) {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:" + ctx.packageName))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        private val BLUE = 0xFF5E9BF5.toInt(); private val PURPLE = 0xFF9A86E8.toInt(); private val PINK = 0xFFEE8FBE.toInt()
        private val YEL = 0xFFFFD866.toInt()
        private fun lerp(a: Int, b: Int, t: Float): Int {
            fun ch(s: Int) = ((a shr s and 0xFF) + ((b shr s and 0xFF) - (a shr s and 0xFF)) * t).toInt()
            return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
        }
        /** Gradasi label: biru -> ungu -> pink menurut posisi huruf. */
        private fun grad(i: Int, n: Int): Int {
            if (n <= 1) return BLUE
            val t = i / (n - 1f)
            return if (t <= 0.5f) lerp(BLUE, PURPLE, t * 2f) else lerp(PURPLE, PINK, (t - 0.5f) * 2f)
        }
        private fun heat(t: Float) = when {
            t < 45f -> 0xFF7CFFB2.toInt(); t < 55f -> YEL; t < 65f -> 0xFFFF9F43.toInt(); else -> 0xFFFF5C5C.toInt()
        }
    }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var host: FrameLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private var picker: View? = null
    private var pickerClosedAt = 0L
    private var job: Job? = null
    private var shapeKey = ""

    private lateinit var simpleV: TextView
    private lateinit var normalV: NormalOverlayView
    private lateinit var barV: BarOverlayView
    private lateinit var tileV: TileOverlayView
    private lateinit var bgShape: GradientDrawable

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    private fun fg(n: Notification) {
        if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(NID, n)
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        runCatching { getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CH, "Overlay FPS", NotificationManager.IMPORTANCE_LOW)) }
        runCatching {
            fg(Notification.Builder(this, CH).setSmallIcon(R.drawable.ic_stat_nexnon).setContentTitle("Nexnon Engine")
                .setContentText("Overlay FPS aktif").setOngoing(true).setShowWhen(false).build())
        }.onFailure { AppLog.w("Overlay", "startForeground gagal: ${it.javaClass.simpleName} ${it.message}") }
        OverlayPrefs.load(this)
        // Izin overlay bisa dicabut kapan saja; addView akan crash tanpa pengecekan ini
        if (!OverlayPrefs.on || !Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        Access.init(this); BatteryStats.init(this)
        if (host == null && !show()) { stopSelf(); return START_NOT_STICKY }
        running = true
        Sampler.overlayWanted = true
        Sampler.start(this)
        TouchHz.start()
        if (Shell.mode() == "-") Toast.makeText(this, "Overlay butuh Shizuku atau Root untuk membaca FPS", Toast.LENGTH_LONG).show()
        return START_STICKY
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun show(): Boolean {
        val wm = getSystemService(WindowManager::class.java)
        val prefs = getSharedPreferences("overlay_pos", MODE_PRIVATE)
        bgShape = GradientDrawable().apply { cornerRadius = dp(40).toFloat() }
        simpleV = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 12f; setSingleLine(false); maxLines = 3; background = bgShape }
        normalV = NormalOverlayView(this).apply { visibility = View.GONE }
        barV = BarOverlayView(this).apply { visibility = View.GONE }
        tileV = TileOverlayView(this).apply { visibility = View.GONE }
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val box = FrameLayout(this).apply {
            addView(simpleV, FrameLayout.LayoutParams(wrap, wrap))
            addView(normalV, FrameLayout.LayoutParams(wrap, wrap))
            addView(barV, FrameLayout.LayoutParams(wrap, wrap))
            addView(tileV, FrameLayout.LayoutParams(wrap, wrap))
        }
        val p = WindowManager.LayoutParams(wrap, wrap, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = prefs.getInt("x", dp(12)); y = prefs.getInt("y", dp(40)) }
        lp = p

        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false; var longFired = false
        val longPress = Runnable { longFired = true; RecCtl.toggle(this); box.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS) }
        box.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false; longFired = false; view.postDelayed(longPress, 1000) }
                MotionEvent.ACTION_CANCEL -> view.removeCallbacks(longPress)
                MotionEvent.ACTION_MOVE -> {
                    if (!moved && (abs(e.rawX - tx) > dp(8) || abs(e.rawY - ty) > dp(8))) { moved = true; view.removeCallbacks(longPress) }
                    if (moved) {
                        val dm = resources.displayMetrics
                        p.x = (sx + (e.rawX - tx).toInt()).coerceIn(0, maxOf(0, dm.widthPixels - view.width))
                        p.y = (sy + (e.rawY - ty).toInt()).coerceIn(0, maxOf(0, dm.heightPixels - view.height))
                        runCatching { wm.updateViewLayout(view, p) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    view.removeCallbacks(longPress)
                    if (moved) prefs.edit().putInt("x", p.x).putInt("y", p.y).apply()
                    // Kartu yang baru saja tertutup oleh ketukan di luar jangan langsung dibuka lagi
                    else if (!longFired && android.os.SystemClock.elapsedRealtime() - pickerClosedAt > 350) togglePicker()
                }
            }
            true
        }
        if (!runCatching { wm.addView(box, p) }.onFailure { AppLog.w("Overlay", "addView gagal: ${it.message}") }.isSuccess) return false
        host = box
        // Sampler memperbarui tiap ~1 detik; membaca ulang tiap 0,5 detik membuat perubahan warna / gaya dari Settings cepat terlihat
        job = scope.launch {
            while (isActive) {
                runCatching { render(Sampler.live.value ?: OvSnap()) }.onFailure { AppLog.w("Overlay", "render gagal: ${it.message}") }
                delay(500L)
            }
        }
        return true
    }

    private fun render(s: OvSnap) {
        val style = OverlayPrefs.style; val k = OverlayPrefs.size / 100f
        val bgc = withAlpha(OverlayPrefs.bg, OverlayPrefs.alpha); val tx = OverlayPrefs.text
        val rec = Recorder.active
        tileV.visibility = if (style == 3) View.VISIBLE else View.GONE
        when (style) {
            3 -> {
                simpleV.visibility = View.GONE; normalV.visibility = View.GONE; barV.visibility = View.GONE
                tileV.snap = s; tileV.rec = rec; tileV.touch = TouchHz.value(); tileV.scale = k; tileV.bgColor = bgc
                tileV.strokeColor = withAlpha(tx, 14); tileV.textColor = tx
                tileV.requestLayout(); tileV.invalidate()
            }
            2 -> {
                simpleV.visibility = View.GONE; normalV.visibility = View.GONE; barV.visibility = View.VISIBLE
                barV.snap = s; barV.rec = rec; barV.extra = TouchHz.label(); barV.scale = k; barV.bgColor = bgc
                barV.strokeColor = withAlpha(tx, 14); barV.textColor = tx
                barV.requestLayout(); barV.invalidate()
            }
            1 -> {
                simpleV.visibility = View.GONE; barV.visibility = View.GONE; normalV.visibility = View.VISIBLE
                normalV.snap = s; normalV.rec = rec; normalV.scale = k; normalV.bgColor = bgc
                normalV.strokeColor = withAlpha(tx, 14); normalV.textColor = tx
                normalV.requestLayout(); normalV.invalidate()
            }
            else -> {
                normalV.visibility = View.GONE; barV.visibility = View.GONE; simpleV.visibility = View.VISIBLE
                val key = "$k"
                if (key != shapeKey) {   // ukuran berubah: sesuaikan huruf, bantalan, dan lengkung
                    shapeKey = key
                    fun sp(v: Float) = (v * resources.displayMetrics.density * k).toInt()
                    simpleV.textSize = 12f * k; simpleV.setPadding(sp(12f), sp(5f), sp(12f), sp(5f)); bgShape.cornerRadius = sp(40f).toFloat()
                }
                bgShape.setColor(bgc); bgShape.setStroke(dp(1), withAlpha(tx, 14))
                simpleV.setTextColor(tx)
                simpleV.text = simple(s, rec)
            }
        }
    }

    /** Simple: satu baris, label gradasi + nilai. FPS 60  CPU 35% 42°  GPU 45% 41°  RAM 62%  BAT 85% 36° */
    private fun simple(s: OvSnap, rec: Boolean): CharSequence {
        val sb = SpannableStringBuilder(); val tx = OverlayPrefs.text
        fun put(t: String, c: Int = tx, bold: Boolean = false) {
            val st = sb.length; sb.append(t)
            sb.setSpan(ForegroundColorSpan(c), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (bold) sb.setSpan(StyleSpan(Typeface.BOLD), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        fun lab(t: String) = t.forEachIndexed { i, ch -> put(ch.toString(), grad(i, t.length)) }
        fun temp(t: Float) { if (t >= 0f) put(deg(t), heat(t)) }
        lab("FPS"); put(" "); put("${s.fps}", bold = true)
        if (rec) put(" ●", 0xFFFF5C5C.toInt())
        put("  "); lab("CPU"); put(" " + ovPct(s.cpu) + " "); temp(s.tCpu)
        put("  "); lab("GPU"); put(" " + ovPct(s.gpu) + " "); temp(s.tGpu)
        put("  "); lab("RAM"); put(" " + ovPct(s.ramPct))
        put("  "); lab("BAT"); put(" " + ovPct(s.batPct) + " "); temp(s.tBat)
        return sb
    }

    /** Kartu kecil di bawah overlay (atau di atasnya bila mepet bawah layar): pilih gaya dengan satu ketukan. */
    private fun togglePicker() {
        if (picker != null) { closePicker(); return }
        val h = host ?: return; val p = lp ?: return
        val wm = getSystemService(WindowManager::class.java)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply { setColor(0xF2101014.toInt()); cornerRadius = dp(16).toFloat(); setStroke(dp(1), 0x33FFFFFF) }
        }
        card.addView(TextView(this).apply { text = "Gaya overlay"; textSize = 12f; setTextColor(0xFF3DF0FF.toInt()); typeface = Typeface.DEFAULT_BOLD })
        OverlayPrefs.STYLES.forEachIndexed { idx, name ->
            val sel = OverlayPrefs.style == idx
            card.addView(TextView(this).apply {
                text = (if (sel) "✓  " else "    ") + name; textSize = 14f; typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                setTextColor(if (sel) 0xFF3DF0FF.toInt() else 0xFFFFFFFF.toInt()); setPadding(0, dp(9), dp(24), dp(3))
                setOnClickListener { OverlayPrefs.style = idx; OverlayPrefs.save(this@OverlayService); closePicker() }
            })
        }
        val dm = resources.displayMetrics
        val below = p.y + h.height + dp(175) < dm.heightPixels
        val pl = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START; x = p.x.coerceAtMost(maxOf(0, dm.widthPixels - dp(340)))
            y = if (below) p.y + h.height + dp(6) else maxOf(0, p.y - dp(165))
        }
        card.setOnTouchListener { _, e -> if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) { closePicker(); true } else false }
        if (runCatching { wm.addView(card, pl) }.isSuccess) picker = card
    }

    private fun closePicker() {
        picker?.let { v -> runCatching { getSystemService(WindowManager::class.java).removeView(v) } }
        picker = null; pickerClosedAt = android.os.SystemClock.elapsedRealtime()
    }

    override fun onDestroy() {
        running = false
        Sampler.overlayWanted = false
        job?.cancel(); job = null
        TouchHz.stop()
        closePicker()
        host?.let { v -> runCatching { getSystemService(WindowManager::class.java).removeView(v) } }; host = null
        scope.cancel()
        if (!Recorder.active) Sampler.stop()
        super.onDestroy()
    }
}
