package com.nexnon.engine

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.*
import rikka.shizuku.Shizuku

/** Pilihan metode akses: Shizuku atau Root (diambil dari Pulse Monitor, tanpa Notifier/Sampler). */
object Access {
    const val REQ = 4711
    const val AUTO = -1
    const val SHIZUKU = 0
    const val ROOT = 1

    var choice by mutableIntStateOf(AUTO); private set
    /** 0 = tidak berjalan / tidak tersedia, 1 = belum diizinkan, 2 = terhubung. */
    var status by mutableIntStateOf(0); private set
    /** Hasil cek su: 0 = tidak ada su, 1 = ditolak / belum dicek, 2 = root aktif. */
    @Volatile var rootState = 1; private set
    var busy by mutableIntStateOf(0); private set
    /** Pesan hasil untuk ditampilkan di UI (pengganti Notifier). */
    var message by mutableStateOf(""); private set

    private var prefs: SharedPreferences? = null
    private var appCtx: Context? = null
    private var pendingRoot = false
    private var awaitingShizuku = false
    private val main = Handler(Looper.getMainLooper())

    fun init(ctx: Context) {
        if (appCtx != null) return
        val app = ctx.applicationContext
        appCtx = app
        prefs = app.getSharedPreferences("access", Context.MODE_PRIVATE)
        choice = prefs?.getInt("mode", AUTO) ?: AUTO
        if (choice == ROOT) probeRootAsync()
        refresh()
    }

    fun refresh() { status = if (choice == ROOT) rootState else shizukuStatus() }

    private fun shizukuStatus(): Int = try {
        when {
            !Shizuku.pingBinder() -> 0
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> 2
            else -> 1
        }
    } catch (_: Throwable) { 0 }

    /** Jalankan su di thread terpisah; Magisk/KernelSU/APatch menampilkan dialog izin bila belum pernah diizinkan. */
    private fun probeRootAsync() {
        busy++
        Thread {
            val s = try {
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
                val out = p.inputStream.bufferedReader().readText()
                if (p.waitFor() == 0 && out.contains("uid=0")) 2 else 1
            } catch (_: java.io.IOException) { 0 } catch (_: Throwable) { 1 }
            rootState = s
            main.post {
                busy = (busy - 1).coerceAtLeast(0)
                refresh()
                if (pendingRoot) {
                    pendingRoot = false
                    message = when (s) {
                        2 -> "Root terhubung."
                        0 -> "Root tidak tersedia di perangkat ini."
                        else -> "Izin root ditolak."
                    }
                }
            }
        }.start()
    }

    /** Dipanggil saat pengguna memilih metode di dialog Izinkan Akses. */
    fun select(m: Int) {
        awaitingShizuku = false
        choice = m
        prefs?.edit()?.putInt("mode", m)?.apply()
        if (m == ROOT) { pendingRoot = true; rootState = 1; refresh(); probeRootAsync(); return }
        pendingRoot = false
        refresh()
        when (status) {
            2 -> message = "Shizuku terhubung."
            1 -> {
                val blocked = try { Shizuku.shouldShowRequestPermissionRationale() } catch (_: Throwable) { false }
                if (blocked) message = "Izin Shizuku ditolak. Aktifkan lewat aplikasi Shizuku."
                else { awaitingShizuku = true; requestPermission() }
            }
            else -> message = "Shizuku belum berjalan. Nyalakan dulu Shizuku."
        }
    }

    fun requestPermission() {
        if (choice == ROOT) { probeRootAsync(); return }
        try { if (Shizuku.pingBinder() && !Shizuku.shouldShowRequestPermissionRationale()) Shizuku.requestPermission(REQ) } catch (_: Throwable) {}
    }

    fun onPermissionResult(granted: Boolean) {
        refresh()
        if (!awaitingShizuku) return
        awaitingShizuku = false
        message = if (granted) "Shizuku terhubung." else "Izin Shizuku ditolak."
    }
}
