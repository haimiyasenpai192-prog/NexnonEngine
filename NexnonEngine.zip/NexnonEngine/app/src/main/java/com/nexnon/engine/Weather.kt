package com.nexnon.engine

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Suhu cuaca saat ini. Lokasi diperkirakan dari alamat IP (tingkat kota, tanpa izin lokasi),
 * cuaca dari Open-Meteo (gratis, tanpa kunci API).
 */
object Weather {
    var temp by mutableStateOf<Int?>(null)
    var desc by mutableStateOf("")
    var city by mutableStateOf("")
    var failed by mutableStateOf(false)
    private var lastOk = 0L

    private fun get(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        return try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }

    fun text(code: Int) = when (code) {
        0 -> "Cerah"; 1, 2 -> "Cerah berawan"; 3 -> "Berawan"; 45, 48 -> "Berkabut"
        in 51..57 -> "Gerimis"; in 61..67 -> "Hujan"; in 71..77 -> "Salju"
        in 80..82 -> "Hujan deras"; in 95..99 -> "Badai petir"; else -> "-"
    }

    /** Dipanggil berkala; lewati bila data masih baru (< 15 menit). */
    suspend fun refresh(force: Boolean = false) {
        if (!force && temp != null && System.currentTimeMillis() - lastOk < 15 * 60_000L) return
        withContext(Dispatchers.IO) {
            runCatching {
                val loc = JSONObject(get("https://ipwho.is/"))
                require(loc.optBoolean("success", true))
                val lat = loc.getDouble("latitude"); val lon = loc.getDouble("longitude")
                val w = JSONObject(get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code"))
                val cur = w.getJSONObject("current")
                val t = Math.round(cur.getDouble("temperature_2m")).toInt()
                val d = text(cur.getInt("weather_code"))
                val ct = loc.optString("city", "")
                withContext(Dispatchers.Main) { temp = t; desc = d; city = ct; failed = false; lastOk = System.currentTimeMillis() }
            }.onFailure { e ->
                AppLog.w("Cuaca", "gagal: ${e.javaClass.simpleName} ${e.message}")
                withContext(Dispatchers.Main) { if (temp == null) failed = true }
            }
        }
    }
}
