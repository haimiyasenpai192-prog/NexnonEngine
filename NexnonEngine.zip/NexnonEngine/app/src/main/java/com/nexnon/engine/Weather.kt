package com.nexnon.engine

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.util.Locale
import kotlin.coroutines.resume
import java.net.HttpURLConnection
import java.net.URL

/**
 * Suhu cuaca saat ini dari Open-Meteo (gratis, tanpa kunci API).
 * Lokasi: bila pengguna mengetuk kartu cuaca dan memberi izin lokasi (perkiraan), memakai lokasi HP;
 * selain itu diperkirakan dari alamat IP (sering meleset ke kota pusat operator, mis. Jakarta).
 */
object Weather {
    var temp by mutableStateOf<Int?>(null)
    var desc by mutableStateOf("")
    var city by mutableStateOf("")
    var failed by mutableStateOf(false)
    var err by mutableStateOf("")
    var useGps by mutableStateOf(false)
    private var lastOk = 0L
    private var appCtx: Context? = null
    private var lastLat = 0.0; private var lastLon = 0.0; private var lastCity = ""

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences("weather", Context.MODE_PRIVATE)

    /** Muat pilihan tersimpan: apakah memakai lokasi HP, beserta koordinat dan nama kota terakhir. */
    fun init(c: Context) {
        if (appCtx != null) return
        appCtx = c.applicationContext
        val p = prefs(c)
        useGps = p.getBoolean("gps", false); lastLat = p.getFloat("lat", 0f).toDouble(); lastLon = p.getFloat("lon", 0f).toDouble(); lastCity = p.getString("city", "") ?: ""
        if (useGps && lastCity.isNotEmpty()) city = lastCity
    }

    fun hasPermission(c: Context) = c.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    /** Dipanggil setelah izin lokasi diberikan: pakai lokasi HP dan segarkan cuaca sekarang. */
    suspend fun useMyLocation(c: Context) {
        init(c)
        useGps = true; prefs(c).edit().putBoolean("gps", true).apply()
        refresh(force = true)
    }

    @SuppressLint("MissingPermission")
    private suspend fun locate(c: Context): Location? {
        val lm = c.getSystemService(LocationManager::class.java) ?: return null
        val last = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.time }
        if (last != null && System.currentTimeMillis() - last.time < 30 * 60_000L) return last
        val prov = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
            .firstOrNull { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) } ?: return last
        val fresh = withTimeoutOrNull(12_000L) {
            suspendCancellableCoroutine<Location?> { cont ->
                if (Build.VERSION.SDK_INT >= 30) {
                    val cs = android.os.CancellationSignal(); cont.invokeOnCancellation { cs.cancel() }
                    lm.getCurrentLocation(prov, cs, c.mainExecutor) { if (cont.isActive) cont.resume(it) }
                } else {
                    val l = object : LocationListener {
                        override fun onLocationChanged(x: Location) { if (cont.isActive) cont.resume(x) }
                        @Deprecated("Deprecated in Java") override fun onStatusChanged(p: String?, st: Int, e: Bundle?) {}
                        override fun onProviderEnabled(p: String) {}
                        override fun onProviderDisabled(p: String) {}
                    }
                    lm.requestSingleUpdate(prov, l, Looper.getMainLooper()); cont.invokeOnCancellation { lm.removeUpdates(l) }
                }
            }
        }
        return fresh ?: last
    }

    /** Nama kota dari koordinat: Geocoder bawaan dulu, lalu layanan gratis sebagai cadangan. */
    private fun cityOf(c: Context, lat: Double, lon: Double): String {
        runCatching {
            if (Geocoder.isPresent()) {
                @Suppress("DEPRECATION") val a = Geocoder(c, Locale("id", "ID")).getFromLocation(lat, lon, 1)?.firstOrNull()
                val n = a?.subAdminArea ?: a?.locality ?: a?.subLocality
                if (!n.isNullOrBlank()) return n
            }
        }
        runCatching {
            val j = JSONObject(get("https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=$lat&longitude=$lon&localityLanguage=id"))
            val n = j.optString("city").ifBlank { j.optString("locality") }
            if (n.isNotBlank()) return n
        }
        return "Lokasi saya"
    }

    private fun get(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 10000
        // Beberapa layanan menolak permintaan tanpa User-Agent / Accept
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) NexnonEngine/1.0")
        c.setRequestProperty("Accept", "application/json")
        if (c.responseCode !in 200..299) throw java.io.IOException("HTTP ${c.responseCode}")
        return try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }

    fun text(code: Int) = when (code) {
        0 -> "Cerah"; 1, 2 -> "Cerah berawan"; 3 -> "Berawan"; 45, 48 -> "Berkabut"
        in 51..57 -> "Gerimis"; in 61..67 -> "Hujan"; in 71..77 -> "Salju"
        in 80..82 -> "Hujan deras"; in 95..99 -> "Badai petir"; else -> "-"
    }

    /** Dipanggil berkala; lewati bila data masih baru (< 15 menit). */
    suspend fun refresh(force: Boolean = false) {
        if (!force && temp != null && System.currentTimeMillis() - lastOk < 15 * 60_000L) return
        withContext(Dispatchers.IO) {
            runCatching {
                // Lokasi dari IP; coba beberapa layanan berurutan sampai ada yang berhasil
                var lat = 0.0; var lon = 0.0; var ct = ""
                var ok = false
                val errs = ArrayList<String>()
                val c = appCtx
                if (useGps && c != null && hasPermission(c)) {
                    val loc = runCatching { locate(c) }.getOrNull()
                    if (loc != null) {
                        lat = loc.latitude; lon = loc.longitude
                        // Nama kota hanya dicari ulang bila pindah > ~5 km dari lokasi sebelumnya
                        ct = if (lastCity.isNotEmpty() && Math.abs(lat - lastLat) < 0.05 && Math.abs(lon - lastLon) < 0.05) lastCity else cityOf(c, lat, lon)
                        lastLat = lat; lastLon = lon; lastCity = ct
                        prefs(c).edit().putFloat("lat", lat.toFloat()).putFloat("lon", lon.toFloat()).putString("city", ct).apply()
                        ok = true
                    } else if (lastCity.isNotEmpty()) { lat = lastLat; lon = lastLon; ct = lastCity; ok = true }
                    else errs.add("lokasi HP tidak tersedia (aktifkan lokasi)")
                }
                val sources = listOf<() -> Triple<Double, Double, String>>(
                    { val j = JSONObject(get("https://ipwho.is/")); require(j.optBoolean("success", true))
                      Triple(j.getDouble("latitude"), j.getDouble("longitude"), j.optString("city", "")) },
                    { val j = JSONObject(get("https://get.geojs.io/v1/ip/geo.json"))
                      Triple(j.getString("latitude").toDouble(), j.getString("longitude").toDouble(), j.optString("city", "")) },
                    { val j = JSONObject(get("https://ipapi.co/json/"))
                      Triple(j.getDouble("latitude"), j.getDouble("longitude"), j.optString("city", "")) },
                    { val j = JSONObject(get("https://ipinfo.io/json"))
                      val ll = j.getString("loc").split(",")
                      Triple(ll[0].toDouble(), ll[1].toDouble(), j.optString("city", "")) },
                    { val j = JSONObject(get("https://api.ip.sb/geoip"))
                      Triple(j.getDouble("latitude"), j.getDouble("longitude"), j.optString("city", "")) },
                )
                if (!ok) for (src in sources) {
                    try { val r = src(); lat = r.first; lon = r.second; ct = r.third; ok = true; break }
                    catch (e: Exception) { errs.add("${e.javaClass.simpleName} ${e.message}") }
                }
                if (!ok) throw java.io.IOException("lokasi gagal: " + errs.joinToString(" | "))
                val w = JSONObject(get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code"))
                val cur = w.getJSONObject("current")
                val t = Math.round(cur.getDouble("temperature_2m")).toInt()
                val d = text(cur.getInt("weather_code"))
                withContext(Dispatchers.Main) { temp = t; desc = d; city = ct; failed = false; err = ""; lastOk = System.currentTimeMillis() }
            }.onFailure { e ->
                AppLog.w("Cuaca", "gagal: ${e.javaClass.simpleName} ${e.message}")
                val m = when (e) {
                    is java.net.UnknownHostException, is java.net.ConnectException -> "Tidak ada internet"
                    is java.net.SocketTimeoutException -> "Koneksi lambat, coba lagi"
                    else -> "Layanan cuaca gagal"
                }
                withContext(Dispatchers.Main) { if (temp == null) { failed = true; err = m } }
            }
        }
    }
}
