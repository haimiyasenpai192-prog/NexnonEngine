package com.nexnon.engine

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Suhu cuaca saat ini. Lokasi diperkirakan dari alamat IP (tingkat kota, tanpa izin lokasi),
 * cuaca dari Open-Meteo (gratis, tanpa kunci API).
 */
object Weather {
    var temp by mutableStateOf<Int?>(null)
    var desc by mutableStateOf("")
    var city by mutableStateOf("")
    var failed by mutableStateOf(false)
    var err by mutableStateOf("")
    private var lastOk = 0L

    private fun get(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 10000
        // Beberapa layanan menolak permintaan tanpa User-Agent / Accept
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) NexnonEngine/1.0")
        c.setRequestProperty("Accept", "application/json")
        if (c.responseCode !in 200..299) throw java.io.IOException("HTTP ${c.responseCode}")
        return try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }

    fun text(code: Int) = when (code) {
        0 -> "Cerah"; 1, 2 -> "Cerah berawan"; 3 -> "Berawan"; 45, 48 -> "Berkabut"
        in 51..57 -> "Gerimis"; in 61..67 -> "Hujan"; in 71..77 -> "Salju"
        in 80..82 -> "Hujan deras"; in 95..99 -> "Badai petir"; else -> "-"
    }

    /** Dipanggil berkala; lewati bila data masih baru (< 15 menit). */
    suspend fun refresh(force: Boolean = false) {
        if (!force && temp != null && System.currentTimeMillis() - lastOk < 15 * 60_000L) return
        withContext(Dispatchers.IO) {
            runCatching {
                // Lokasi dari IP; coba beberapa layanan berurutan sampai ada yang berhasil
                var lat = 0.0; var lon = 0.0; var ct = ""
                var ok = false
                val errs = ArrayList<String>()
                val sources = listOf<() -> Triple<Double, Double, String>>(
                    { val j = JSONObject(get("https://ipwho.is/")); require(j.optBoolean("success", true))
                      Triple(j.getDouble("latitude"), j.getDouble("longitude"), j.optString("city", "")) },
                    { val j = JSONObject(get("https://get.geojs.io/v1/ip/geo.json"))
                      Triple(j.getString("latitude").toDouble(), j.getString("longitude").toDouble(), j.optString("city", "")) },
                    { val j = JSONObject(get("https://ipapi.co/json/"))
                      Triple(j.getDouble("latitude"), j.getDouble("longitude"), j.optString("city", "")) },
                    { val j = JSONObject(get("https://ipinfo.io/json"))
                      val ll = j.getString("loc").split(",")
                      Triple(ll[0].toDouble(), ll[1].toDouble(), j.optString("city", "")) },
                    { val j = JSONObject(get("https://api.ip.sb/geoip"))
                      Triple(j.getDouble("latitude"), j.getDouble("longitude"), j.optString("city", "")) },
                )
                for (src in sources) {
                    try { val r = src(); lat = r.first; lon = r.second; ct = r.third; ok = true; break }
                    catch (e: Exception) { errs.add("${e.javaClass.simpleName} ${e.message}") }
                }
                if (!ok) throw java.io.IOException("lokasi gagal: " + errs.joinToString(" | "))
                val w = JSONObject(get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code"))
                val cur = w.getJSONObject("current")
                val t = Math.round(cur.getDouble("temperature_2m")).toInt()
                val d = text(cur.getInt("weather_code"))
                withContext(Dispatchers.Main) { temp = t; desc = d; city = ct; failed = false; err = ""; lastOk = System.currentTimeMillis() }
            }.onFailure { e ->
                AppLog.w("Cuaca", "gagal: ${e.javaClass.simpleName} ${e.message}")
                val m = when (e) {
                    is java.net.UnknownHostException, is java.net.ConnectException -> "Tidak ada internet"
                    is java.net.SocketTimeoutException -> "Koneksi lambat, coba lagi"
                    else -> "Layanan cuaca gagal"
                }
                withContext(Dispatchers.Main) { if (temp == null) { failed = true; err = m } }
            }
        }
    }
}
