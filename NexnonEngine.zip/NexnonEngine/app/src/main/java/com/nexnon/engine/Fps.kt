package com.nexnon.engine

import android.view.Choreographer
import androidx.compose.runtime.*
import kotlin.math.roundToInt

class Rec(val sec: Int, val avg: Int, val low: Int)

/** Mengembalikan (AVG fps, 1% LOW fps) dari daftar frametime (ms). */
fun calc(ds: List<Float>): Pair<Int, Int> {
    if (ds.isEmpty()) return 0 to 0
    val s = ds.sortedDescending()
    val k = maxOf(1, (ds.size * 0.01f).toInt())
    val w = s.take(k).average().toFloat()
    return (ds.size / (ds.sum() / 1000f)).roundToInt() to (1000f / w).roundToInt()
}

/** Ukur FPS layar app ini lewat Choreographer (FPS game asli butuh Sampler Shizuku/Root seperti di Pulse Monitor). */
object FpsMeter : Choreographer.FrameCallback {
    var fps by mutableIntStateOf(0); private set
    var frameMs by mutableFloatStateOf(0f); private set
    var avg by mutableIntStateOf(0); private set
    var low by mutableIntStateOf(0); private set
    val history = mutableStateListOf<Int>()
    val recs = mutableStateListOf<Rec>()
    var recording by mutableStateOf(false); private set
    var recSec by mutableIntStateOf(0); private set
    var overlay by mutableStateOf(false)

    private val frames = ArrayDeque<Pair<Long, Float>>()
    private val rec = ArrayList<Float>()
    private var last = 0L; private var lastUi = 0L; private var recStart = 0L; private var running = false

    fun start() { if (running) return; running = true; last = 0L; Choreographer.getInstance().postFrameCallback(this) }
    fun stop() { running = false; Choreographer.getInstance().removeFrameCallback(this) }

    override fun doFrame(ns: Long) {
        if (!running) return
        if (last > 0) {
            val ms = (ns - last) / 1_000_000f
            if (ms in 0.5f..1000f) { frames.addLast(ns to ms); if (recording) rec.add(ms) }
        }
        last = ns
        while (frames.isNotEmpty() && frames.first().first < ns - 30_000_000_000L) frames.removeFirst()
        if (ns - lastUi >= 500_000_000L && frames.size >= 10) {
            lastUi = ns
            fps = frames.count { it.first > ns - 1_000_000_000L }
            frameMs = frames.toList().takeLast(10).map { it.second }.average().toFloat()
            val (a, l) = calc(frames.map { it.second }); avg = a; low = l
            history.add(fps); while (history.size > 60) history.removeAt(0)
            if (recording) recSec = ((System.nanoTime() - recStart) / 1_000_000_000L).toInt()
        }
        Choreographer.getInstance().postFrameCallback(this)
    }

    fun toggleRec() {
        if (!recording) { rec.clear(); recStart = System.nanoTime(); recSec = 0; recording = true; return }
        recording = false
        val sec = ((System.nanoTime() - recStart) / 1_000_000_000L).toInt()
        if (rec.size > 5) { val (a, l) = calc(rec); recs.add(Rec(sec, a, l)) }
    }
}
