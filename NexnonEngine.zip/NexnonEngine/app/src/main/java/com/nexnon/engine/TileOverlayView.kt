package com.nexnon.engine

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import kotlin.math.ceil

/**
 * Overlay gaya "Kotak": deretan kotak, tiap kotak dari atas ke bawah = ikon, nilai besar, label.
 * (speedometer = FPS, chip = CPU, kartu grafis = GPU, baterai = BAT, riak sentuhan = TCH).
 *
 *   gauge   chip    kartu   baterai  riak
 *   60      61%     1%      95%      240Hz
 *   FPS     CPU     GPU     BAT      TCH
 */
class TileOverlayView(ctx: Context) : View(ctx) {
    var snap = OvSnap()
    var rec = false
    var touch = "-"                 // nilai sentuhan (Hz) tanpa satuan, "-" bila belum terbaca
    var scale = 1f
    var bgColor = 0xEE101014.toInt()
    var strokeColor = 0x22FFFFFF
    var textColor = 0xFFFFFFFF.toInt()

    private val d = ctx.resources.displayMetrics.density
    private fun u(v: Float) = v * d * scale
    private val YEL = 0xFFFFD866.toInt()
    private val RED = 0xFFFF5C5C.toInt()
    private val GRN = 0xFF7CFFB2.toInt()

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val valP = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
    private val ip = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labP = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
    private val rect = RectF()

    private class Tile(val value: String, val label: String, val color: Int, val frac: Float = 0f)

    private fun batColor(b: Int) = when { b <= 15 -> RED; b <= 30 -> 0xFFFF9F43.toInt(); else -> GRN }

    private fun tiles(): List<Tile> {
        val s = snap
        return listOf(
            Tile("${s.fps}", "FPS", YEL),
            Tile(ovPct(s.cpu), "CPU", if (s.cpu >= 0) loadCol(s.cpu) else withAlpha(textColor, 30)),
            Tile(ovPct(s.gpu), "GPU", if (s.gpu >= 0) loadCol(s.gpu) else withAlpha(textColor, 30)),
            Tile(ovPct(s.batPct), "BAT", if (s.batPct >= 0) batColor(s.batPct) else withAlpha(textColor, 30), s.batPct.coerceIn(0, 100) / 100f),
            Tile(if (touch == "-") "-" else touch + "Hz", "TCH", YEL)
        )
    }

    private fun padX() = u(10f)
    private fun padY() = u(8f)
    private fun tileW() = u(56f)
    private fun gap() = u(2f)
    private fun valH() = u(22f)
    private fun icoH() = u(17f)
    private fun labH() = u(14f)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val n = 5
        val w = padX() * 2 + tileW() * n + gap() * (n - 1)
        val h = padY() * 2 + icoH() + valH() + labH()
        setMeasuredDimension(ceil(w).toInt(), ceil(h).toInt())
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val rad = u(14f)
        p.style = Paint.Style.FILL; p.color = bgColor
        rect.set(0f, 0f, w, h); c.drawRoundRect(rect, rad, rad, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = strokeColor
        rect.set(d / 2, d / 2, w - d / 2, h - d / 2); c.drawRoundRect(rect, rad, rad, p)

        val iy = padY() + icoH() / 2f
        val vy = padY() + icoH() + valH() / 2f
        val ly = padY() + icoH() + valH() + labH() / 2f
        labP.textSize = u(10.5f)
        tiles().forEachIndexed { i, t ->
            val cx = padX() + tileW() * i + gap() * i + tileW() / 2f
            icon(c, i, cx, iy, t)
            valP.textSize = u(17f)
            val maxW = tileW() - u(4f)
            val mw = valP.measureText(t.value)
            if (mw > maxW) valP.textSize = u(17f) * maxW / mw
            valP.color = t.color
            c.drawText(t.value, cx, vy - (valP.ascent() + valP.descent()) / 2f, valP)
            labP.color = textColor
            c.drawText(t.label, cx, ly - (labP.ascent() + labP.descent()) / 2f, labP)
        }
        if (rec) { p.style = Paint.Style.FILL; p.color = RED; c.drawCircle(padX() + u(4f), padY() + u(4f), u(3f), p) }
    }

    /** Ikon digambar langsung (tanpa berkas gambar): garis tipis warna teks; isi baterai berwarna. */
    private fun icon(c: Canvas, kind: Int, cx: Float, cy: Float, t: Tile) {
        val half = u(7f)
        ip.style = Paint.Style.STROKE; ip.strokeWidth = u(1.4f)
        ip.strokeCap = Paint.Cap.ROUND; ip.strokeJoin = Paint.Join.ROUND
        ip.color = textColor
        when (kind) {
            0 -> {   // speedometer: busur terbuka di bawah + jarum
                rect.set(cx - half, cy - half, cx + half, cy + half)
                c.drawArc(rect, 150f, 240f, false, ip)
                c.drawLine(cx, cy, cx + half * 0.55f, cy - half * 0.5f, ip)
                ip.style = Paint.Style.FILL; c.drawCircle(cx, cy, u(1.3f), ip)
            }
            1 -> {   // chip: kotak dengan kaki di empat sisi
                val r = half * 0.55f
                rect.set(cx - r, cy - r, cx + r, cy + r); c.drawRoundRect(rect, u(1.5f), u(1.5f), ip)
                for (k in intArrayOf(-1, 1)) {
                    val x = cx + k * r * 0.5f; val y = cy + k * r * 0.5f
                    c.drawLine(x, cy - r, x, cy - half, ip); c.drawLine(x, cy + r, x, cy + half, ip)
                    c.drawLine(cx - r, y, cx - half, y, ip); c.drawLine(cx + r, y, cx + half, y, ip)
                }
                ip.style = Paint.Style.FILL
                rect.set(cx - r * 0.4f, cy - r * 0.4f, cx + r * 0.4f, cy + r * 0.4f); c.drawRect(rect, ip)
            }
            2 -> {   // kartu grafis: badan, kipas, ventilasi, braket
                rect.set(cx - half, cy - half * 0.6f, cx + half, cy + half * 0.5f); c.drawRoundRect(rect, u(1.5f), u(1.5f), ip)
                c.drawCircle(cx - half * 0.3f, cy - half * 0.05f, half * 0.32f, ip)
                c.drawLine(cx + half * 0.35f, cy - half * 0.22f, cx + half * 0.72f, cy - half * 0.22f, ip)
                c.drawLine(cx + half * 0.35f, cy + half * 0.12f, cx + half * 0.72f, cy + half * 0.12f, ip)
                c.drawLine(cx - half * 0.85f, cy + half * 0.82f, cx - half * 0.1f, cy + half * 0.82f, ip)
            }
            3 -> {   // baterai: badan, kepala, isi sesuai persen
                val right = cx + half * 0.8f
                rect.set(cx - half, cy - half * 0.5f, right, cy + half * 0.5f); c.drawRoundRect(rect, u(2f), u(2f), ip)
                ip.style = Paint.Style.FILL
                rect.set(right + u(0.9f), cy - half * 0.2f, right + u(2.4f), cy + half * 0.2f); c.drawRoundRect(rect, u(0.6f), u(0.6f), ip)
                val inL = cx - half + u(2f); val inR = right - u(2f)
                val fw = (inR - inL) * t.frac
                if (fw > 0f) { ip.color = t.color; rect.set(inL, cy - half * 0.5f + u(2f), inL + fw, cy + half * 0.5f - u(2f)); c.drawRoundRect(rect, u(0.8f), u(0.8f), ip) }
            }
            else -> {   // riak sentuhan: titik + dua lingkaran
                ip.style = Paint.Style.FILL; c.drawCircle(cx, cy, u(1.7f), ip)
                ip.style = Paint.Style.STROKE
                ip.color = withAlpha(textColor, 90); c.drawCircle(cx, cy, half * 0.55f, ip)
                ip.color = withAlpha(textColor, 55); c.drawCircle(cx, cy, half, ip)
            }
        }
    }
}
