package com.nexnon.engine

import androidx.compose.runtime.*

val PROFILES = listOf("Performa", "Seimbang", "Kualitas")
/** Target FPS per profil (indeks 0 = Performa/Medium, 1 = Seimbang/High, 2 = Kualitas/Ultra). */
val FPS = listOf(120, 90, 60)

object Store {
    var game by mutableStateOf<String?>(null)          // null = daftar game, selain itu = halaman detail
    var profile by mutableIntStateOf(0)
    val configured = mutableStateMapOf<String, String>()
    val paths = mutableStateMapOf<String, String>()
    var customText by mutableStateOf("; Tulis config kamu di sini\n")
    var installs by mutableIntStateOf(0)
    var last by mutableStateOf("-")
    var wuVersion by mutableStateOf("")
    var wuMode by mutableStateOf("")
    var wuTier by mutableIntStateOf(0)
    var health by mutableStateOf(false)               // layar Kesehatan & log
    var reportId by mutableStateOf<Long?>(null)       // laporan rekaman FPS yang sedang dibuka
    var monitorDlg by mutableStateOf(false)           // dialog pengaturan notifikasi pantauan
}
