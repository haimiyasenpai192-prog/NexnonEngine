package com.nexnon.engine

import android.content.ComponentName
import android.os.Binder
import android.os.IBinder
import android.os.Parcel
import android.os.SystemClock
import java.lang.reflect.InvocationHandler
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Method
import java.lang.reflect.Proxy

/**
 * Daemon FPS per-task (Android 14+). BUKAN bagian dari proses aplikasi: dijalankan TaskFps lewat
 * `app_process` dengan hak shell (Shizuku) atau root, dari APK Nexnon Engine sendiri.
 *
 * Cara kerja: mendaftar ITaskFpsCallback ke IWindowManager.registerTaskFpsCallback(taskId, cb) (API tersembunyi,
 * butuh ACCESS_FPS_COUNTER, dimiliki shell/root). Sistem (SurfaceFlinger/WindowManager) yang menghitung FPS frame
 * yang benar-benar tampil untuk task itu, lalu memanggil onFpsReported(float). Jadi tidak ada dumpsys berkala,
 * tidak ada selisih counter, tidak ada tabel timestats yang bisa penuh.
 *
 * Protokol (stdin <- aplikasi):  "PKG <paket>" (kosong = task fokus) | "STOP"
 * Protokol (stdout -> aplikasi): "FPS <fps> <umurMs> <taskId> <paket> <jumlahCallback>" tiap 500 ms,
 *                                "LOG <teks>", "UNSUPPORTED <alasan>", "EXIT"
 * Daemon berhenti sendiri bila stdin tertutup (aplikasi mati) atau stdout putus.
 */
object TaskFpsDaemon {
    private const val CB_DESC = "android.window.ITaskFpsCallback"

    @Volatile private var wantPkg = ""
    @Volatile private var fps = -1f
    @Volatile private var fpsAt = 0L
    @Volatile private var cbCount = 0L
    @Volatile private var curGen = 0
    @Volatile private var alive = true

    private var wm: Any? = null
    private var atm: Any? = null
    private var cbIface: Class<*>? = null
    private var mReg: Method? = null
    private var mUnreg: Method? = null
    private var mFocused: Method? = null
    private var mAll: Method? = null

    private var regTask = -1
    private var regPkg = "-"
    private var regProxy: Any? = null

    private val out = java.io.PrintStream(java.io.FileOutputStream(java.io.FileDescriptor.out), true)
    private fun emit(s: String): Boolean { out.println(s.replace('\n', ' ')); return !out.checkError() }

    /** Sisi penerima: system_server memanggil transaksi 1 = onFpsReported(float). Callback dari registrasi lama diabaikan. */
    private class FpsBinder(val gen: Int) : Binder() {
        init { attachInterface(null, CB_DESC) }
        override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
            if (code == IBinder.FIRST_CALL_TRANSACTION) {
                data.enforceInterface(CB_DESC)
                val f = data.readFloat()
                if (gen == curGen) { fps = f; fpsAt = SystemClock.elapsedRealtime(); cbCount++ }
                return true
            }
            return super.onTransact(code, data, reply, flags)
        }
    }

    @JvmStatic
    fun main(args: Array<String>) {
        try { loop() } catch (t: Throwable) { emit("UNSUPPORTED ${desc(t)}") }
        runCatching { unregister() }
        emit("EXIT")
        Runtime.getRuntime().halt(0)
    }

    private fun loop() {
        if (!init()) return
        startStdin()
        var failStreak = 0
        while (alive) {
            val sel = runCatching { pickTask() }.getOrNull()
            if (sel == null) {
                if (regTask != -1) unregister()
            } else if (sel.first != regTask) {
                unregister()
                val err = register(sel.first)
                if (err != null) {
                    emit("LOG register task ${sel.first} gagal: $err")
                    if (++failStreak >= 6) { emit("UNSUPPORTED register gagal: $err"); return }
                } else { failStreak = 0; regPkg = sel.second }
            }
            val age = if (fpsAt == 0L) -1L else SystemClock.elapsedRealtime() - fpsAt
            val pk = if (regTask == -1) "-" else regPkg
            if (!emit("FPS $fps $age $regTask $pk $cbCount")) return
            try { Thread.sleep(500) } catch (_: InterruptedException) {}
        }
    }

    private fun init(): Boolean {
        try {
            val sm = Class.forName("android.os.ServiceManager").getMethod("getService", String::class.java)
            val wb = sm.invoke(null, "window") as? IBinder
            val ab = sm.invoke(null, "activity_task") as? IBinder
            if (wb == null || ab == null) { emit("UNSUPPORTED service window/activity_task tidak ada"); return false }
            val wmI = Class.forName("android.view.IWindowManager")
            wm = Class.forName("android.view.IWindowManager\$Stub").getMethod("asInterface", IBinder::class.java).invoke(null, wb)
            val cb = Class.forName(CB_DESC)
            cbIface = cb
            mReg = wmI.getMethod("registerTaskFpsCallback", Int::class.javaPrimitiveType, cb)
            mUnreg = wmI.getMethod("unregisterTaskFpsCallback", cb)
            val atmI = Class.forName("android.app.IActivityTaskManager")
            atm = Class.forName("android.app.IActivityTaskManager\$Stub").getMethod("asInterface", IBinder::class.java).invoke(null, ab)
            mFocused = runCatching { atmI.getMethod("getFocusedRootTaskInfo") }.getOrNull()
            mAll = runCatching { atmI.getMethod("getAllRootTaskInfos") }.getOrNull()
            if (mFocused == null && mAll == null) { emit("UNSUPPORTED IActivityTaskManager tanpa getFocusedRootTaskInfo/getAllRootTaskInfos"); return false }
            return true
        } catch (t: Throwable) { emit("UNSUPPORTED ${desc(t)}"); return false }
    }

    /** Task yang diukur: task milik [wantPkg] bila ada (yang terlihat didahulukan), kalau tidak task fokus. */
    private fun pickTask(): Pair<Int, String>? {
        val want = wantPkg
        val all = mAll
        if (want.isNotEmpty() && all != null) {
            val list = all.invoke(atm) as? List<*>
            var hidden: Pair<Int, String>? = null
            if (list != null) for (t in list) {
                if (t == null) continue
                val pkg = (field(t, "topActivity") as? ComponentName)?.packageName ?: continue
                if (pkg != want) continue
                val id = field(t, "taskId") as? Int ?: continue
                if ((field(t, "visible") as? Boolean) != false) return id to pkg
                if (hidden == null) hidden = id to pkg
            }
            if (hidden != null) return hidden
        }
        val f = mFocused ?: return null
        val t = f.invoke(atm) ?: return null
        val id = field(t, "taskId") as? Int ?: return null
        val pkg = (field(t, "topActivity") as? ComponentName)?.packageName ?: "-"
        return id to pkg
    }

    private fun register(id: Int): String? {
        return try {
            val gen = ++curGen
            fps = -1f; fpsAt = 0L
            val binder = FpsBinder(gen)
            val proxy = Proxy.newProxyInstance(
                TaskFpsDaemon::class.java.classLoader, arrayOf<Class<*>>(cbIface!!),
                InvocationHandler { p, m, a ->
                    when (m.name) {
                        "asBinder" -> binder          // writeStrongInterface() memakai ini untuk mengirim binder ke system_server
                        "hashCode" -> System.identityHashCode(p)
                        "equals" -> a != null && a.isNotEmpty() && p === a[0]
                        "toString" -> "TaskFpsCb"
                        else -> null
                    }
                }
            )
            mReg!!.invoke(wm, id, proxy)
            regProxy = proxy; regTask = id
            null
        } catch (t: Throwable) { desc(t) }
    }

    private fun unregister() {
        val p = regProxy
        if (p != null) runCatching { mUnreg?.invoke(wm, p) }
        regProxy = null; regTask = -1; regPkg = "-"; fps = -1f; fpsAt = 0L; curGen++
    }

    private fun startStdin() {
        Thread({
            try {
                val r = java.io.BufferedReader(java.io.InputStreamReader(System.`in`))
                while (true) {
                    val l = r.readLine() ?: break
                    if (l.startsWith("PKG")) wantPkg = l.substring(3).trim()
                    else if (l == "STOP") break
                }
            } catch (_: Throwable) {}
            alive = false
        }, "stdin").apply { isDaemon = true; start() }
    }

    private fun field(o: Any, name: String): Any? {
        var c: Class<*>? = o.javaClass
        while (c != null) {
            try { val f = c.getDeclaredField(name); f.isAccessible = true; return f.get(o) } catch (_: NoSuchFieldException) {}
            c = c.superclass
        }
        return null
    }

    private fun desc(t: Throwable): String {
        val c = if (t is InvocationTargetException) (t.targetException ?: t) else t
        return "${c.javaClass.simpleName}: ${c.message}".take(200)
    }
}
