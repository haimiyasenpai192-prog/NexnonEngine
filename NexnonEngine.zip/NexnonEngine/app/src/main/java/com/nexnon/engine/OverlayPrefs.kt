package com.nexnon.engine

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Pengaturan overlay (gaya, warna, transparansi, ukuran). State Compose supaya layar langsung berubah; overlay membacanya tiap detik. */
object OverlayPrefs {
    val STYLES = listOf("Simple", "Normal", "Compact")
    val TEXTS = listOf(0xFFFFFFFF.toInt(), 0xFF3DF0FF.toInt(), 0xFFFFD866.toInt(), 0xFF7CFFB2.toInt())
    val BGS = listOf(0xFF101014.toInt(), 0xFF1B1230.toInt(), 0xFF0B2A2E.toInt(), 0xFF1A2A52.toInt())
    private const val DEF_ALPHA = 92
    const val DEF_SIZE = 100

    var on by mutableStateOf(false)                 // overlay tampil di atas aplikasi lain
    var style by mutableIntStateOf(0)               // 0 Simple (satu baris), 1 Normal (FPS besar + cincin), 2 Compact (bilah per baris)
    var text by mutableIntStateOf(TEXTS[0])
    var bg by mutableIntStateOf(BGS[0])
    var alpha by mutableIntStateOf(DEF_ALPHA)       // transparansi latar, 20..100 persen
    var size by mutableIntStateOf(DEF_SIZE)         // ukuran overlay, 60..200 persen
    @Volatile private var loaded = false

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences("overlay_style", Context.MODE_PRIVATE)

    fun load(c: Context) {
        if (loaded) return
        val p = prefs(c)
        on = p.getBoolean("on", false); style = p.getInt("style", 0).coerceIn(0, STYLES.size - 1)
        text = p.getInt("text", TEXTS[0]); bg = p.getInt("bg", BGS[0])
        alpha = p.getInt("alpha", DEF_ALPHA).coerceIn(20, 100); size = p.getInt("size", DEF_SIZE).coerceIn(60, 200)
        loaded = true
    }

    fun save(c: Context) {
        prefs(c).edit().putBoolean("on", on).putInt("style", style).putInt("text", text).putInt("bg", bg)
            .putInt("alpha", alpha).putInt("size", size).apply()
    }
}

/** Warna RGB + transparansi dalam persen (0..100) jadi ARGB. */
fun withAlpha(rgb: Int, pct: Int): Int = (rgb and 0xFFFFFF) or ((pct.coerceIn(0, 100) * 255 / 100) shl 24)

/** Warna beban: hijau rendah, kuning sedang, oranye tinggi, merah sangat tinggi. */
fun loadCol(p: Int) = when {
    p < 50 -> 0xFF7CFFB2.toInt(); p < 75 -> 0xFFFFD866.toInt(); p < 90 -> 0xFFFF9F43.toInt(); else -> 0xFFFF5C5C.toInt()
}

fun ovPct(v: Int) = if (v >= 0) "$v%" else "-"

/** Satu pembacaan untuk overlay. -1 = tidak terbaca. */
data class OvSnap(
    val fps: Int = 0, val cpu: Int = -1, val gpu: Int = -1, val ramPct: Int = -1,
    val cpuMhz: Int = -1, val gpuMhz: Int = -1, val batPct: Int = -1,
    val tCpu: Float = -1f, val tGpu: Float = -1f, val tBat: Float = -1f, val watt: Float = -1f
)
