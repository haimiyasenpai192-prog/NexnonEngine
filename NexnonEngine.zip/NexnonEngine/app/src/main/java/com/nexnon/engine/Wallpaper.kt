package com.nexnon.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

/** Wallpaper latar aplikasi (sama seperti Pulse Monitor): gambar dipotong lalu disalin ke penyimpanan internal, tanpa izin galeri. */
object Wallpaper {
    private const val MAX_SIDE = 3072
    private const val PREFS = "nexnon"
    private const val KEY_DIM = "dim"

    var image by mutableStateOf<Bitmap?>(null); private set
    var dim by mutableFloatStateOf(0.6f)
    /** Wallpaper kotak atas (hero) di Beranda, terpisah dari latar aplikasi. */
    var heroImage by mutableStateOf<Bitmap?>(null); private set
    var heroCropSrc by mutableStateOf<Bitmap?>(null)
    private fun heroFile(c: Context) = File(c.applicationContext.filesDir, "hero.jpg")

    fun saveHero(c: Context, bmp: Bitmap): Boolean {
        val target = heroFile(c)
        val ok = runCatching {
            val tmp = File(c.applicationContext.filesDir, target.name + ".tmp")
            tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            check(tmp.renameTo(target) || (target.delete() && tmp.renameTo(target)))
        }.isSuccess
        if (ok) loadHero(c)
        return ok
    }

    private fun loadHero(c: Context) {
        val f = heroFile(c)
        heroImage = if (f.exists()) runCatching { BitmapFactory.decodeFile(f.path) }.getOrNull() else null
    }

    fun clearHero(c: Context) { heroFile(c).delete(); heroImage = null }

    /** Gambar yang sedang dipotong (null = layar potong tertutup). */
    var cropSrc by mutableStateOf<Bitmap?>(null)

    private fun file(c: Context) = File(c.applicationContext.filesDir, "wallpaper.jpg")

    fun init(c: Context) {
        dim = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat(KEY_DIM, 0.6f)
        Thread { load(c); loadHero(c) }.start()
    }

    private fun load(c: Context) {
        val f = file(c)
        image = if (f.exists()) runCatching {
            BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 })
        }.getOrNull() else null
    }

    /** Baca gambar pilihan, diperkecil (maks 3072 px) dan diputar sesuai EXIF. */
    fun decodePreview(c: Context, uri: Uri): Bitmap? = runCatching {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(c.contentResolver, uri)) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val longest = maxOf(info.size.width, info.size.height)
            if (longest > MAX_SIDE) {
                val k = MAX_SIDE.toFloat() / longest
                decoder.setTargetSize((info.size.width * k).toInt().coerceAtLeast(1), (info.size.height * k).toInt().coerceAtLeast(1))
            }
        }
    }.getOrNull()

    fun saveCropped(c: Context, bmp: Bitmap): Boolean {
        val target = file(c)
        val ok = runCatching {
            val tmp = File(c.applicationContext.filesDir, target.name + ".tmp")
            tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 97, it) }
            check(tmp.renameTo(target) || (target.delete() && tmp.renameTo(target)))
        }.isSuccess
        if (ok) load(c)
        return ok
    }

    fun clear(c: Context) { file(c).delete(); image = null }

    fun saveDim(c: Context) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putFloat(KEY_DIM, dim).apply()
    }
}
