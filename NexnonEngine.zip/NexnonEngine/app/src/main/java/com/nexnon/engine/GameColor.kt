package com.nexnon.engine

import android.content.Context
import android.os.SystemClock
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.roundToInt

class ColorPreset(val name: String, val sat: Int, val bright: Int, val contrast: Int, val temp: Int)

/**
 * Filter warna game. Matriks warna 4x4 dikirim ke SurfaceFlinger (`service call SurfaceFlinger 1015`, hak shell lewat Shizuku/Root),
 * jadi berlaku ke seluruh layar. Karena itu filter HANYA dipasang selama game ada di depan dan dilepas begitu pindah ke aplikasi lain.
 *  - Pengatur: saturasi, kecerahan, kontras, suhu warna (hangat / dingin), plus pilihan cepat.
 *  - Mengikuti perubahan: tiap putaran RecService membaca nilai terbaru dan memasang ulang bila berubah (atau tiap 5 detik,
 *    karena Night Light / mode warna sistem bisa menimpa matriks). Dari overlay game, pilihan cepat langsung diterapkan.
 *  - Status "terpasang" disimpan, supaya layar tidak tertinggal berwarna bila proses app dimatikan sistem.
 */
object GameColor {
    val PRESETS = listOf(
        ColorPreset("Normal", 100, 100, 100, 0),
        ColorPreset("Vivid", 140, 100, 108, 0),
        ColorPreset("Hangat", 110, 100, 100, 30),
        ColorPreset("Dingin", 105, 100, 100, -30),
        ColorPreset("Cinema", 85, 96, 115, 10)
    )

    var enabled by mutableStateOf(false)
    var sat by mutableIntStateOf(100)         // 0..200 persen (0 = hitam putih)
    var bright by mutableIntStateOf(100)      // 70..130 persen
    var contrast by mutableIntStateOf(100)    // 70..140 persen
    var temp by mutableIntStateOf(0)          // -50 (dingin) .. 50 (hangat)
    var status by mutableStateOf("")
        private set
    /** Naik tiap aplikasi dibuka lagi; dialog memakainya untuk memasang ulang pratinjau. */
    var resumeTick by mutableIntStateOf(0)
        private set

    @Volatile private var loaded = false
    @Volatile private var applied = false
    @Volatile private var previewOn = false
    @Volatile var previewing = false
        private set
    private var appliedSig = ""
    private var appliedAt = 0L
    private var nextTry = 0L

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences("game_color", Context.MODE_PRIVATE)

    fun load(c: Context) {
        if (loaded) return
        val p = prefs(c)
        enabled = p.getBoolean("on", false)
        sat = p.getInt("sat", 100).coerceIn(0, 200)
        bright = p.getInt("bright", 100).coerceIn(70, 130)
        contrast = p.getInt("contrast", 100).coerceIn(70, 140)
        temp = p.getInt("temp", 0).coerceIn(-50, 50)
        applied = p.getBoolean("applied", false)
        loaded = true
    }

    fun save(c: Context) {
        prefs(c).edit().putBoolean("on", enabled).putInt("sat", sat).putInt("bright", bright)
            .putInt("contrast", contrast).putInt("temp", temp).apply()
    }

    fun isApplied() = applied
    fun isIdentity() = sat == 100 && bright == 100 && contrast == 100 && temp == 0
    fun presetIndex() = PRESETS.indexOfFirst { it.sat == sat && it.bright == bright && it.contrast == contrast && it.temp == temp }
    private fun signature() = "$sat|$bright|$contrast|$temp"

    /** Matriks warna kolom-utama 4x4: saturasi -> kontras (di sekitar abu-abu tengah) -> penguatan per kanal (suhu x kecerahan). */
    private fun matrix(): FloatArray {
        val s = sat / 100f; val b = bright / 100f; val c = contrast / 100f; val w = temp / 50f
        val lr = 0.213f; val lg = 0.715f; val lb = 0.072f
        val sm = arrayOf(
            floatArrayOf(lr * (1f - s) + s, lg * (1f - s), lb * (1f - s)),
            floatArrayOf(lr * (1f - s), lg * (1f - s) + s, lb * (1f - s)),
            floatArrayOf(lr * (1f - s), lg * (1f - s), lb * (1f - s) + s)
        )
        val gain = floatArrayOf((1f + 0.2f * w) * b, b, (1f - 0.2f * w) * b)
        val m = FloatArray(16)
        for (i in 0..2) {
            val g = gain[i].coerceIn(0.4f, 1.6f)
            for (j in 0..2) m[j * 4 + i] = g * c * sm[i][j]
            m[12 + i] = g * 0.5f * (1f - c)
        }
        m[15] = 1f
        return m
    }

    /** null = berhasil, selain itu pesan error. m == null mematikan matriks (layar normal). */
    private fun sendMatrix(m: FloatArray?): String? {
        val cmd = if (m == null) "service call SurfaceFlinger 1015 i32 0"
        else "service call SurfaceFlinger 1015 i32 1 " + m.joinToString(" ") { "f " + String.format(Locale.US, "%.4f", it) }
        val (code, out) = Shell.run(cmd)
        val ok = code == 0 && out.contains("Parcel") && !out.contains("Error", ignoreCase = true) && !out.contains("not exist", ignoreCase = true)
        if (!ok) AppLog.w("FilterWarna", "gagal ($code): ${out.take(120)}")
        return if (ok) null else (out.lines().lastOrNull { it.isNotBlank() }?.trim()?.take(100) ?: "kode $code")
    }

    private fun push(c: Context, sig: String) {
        val err = sendMatrix(matrix())
        val now = SystemClock.elapsedRealtime()
        if (err == null) {
            val was = applied
            applied = true; appliedSig = sig; appliedAt = now; nextTry = 0L; status = ""
            if (!was) { prefs(c).edit().putBoolean("applied", true).apply(); AppLog.i("FilterWarna", "dipasang ($sig)") }
        } else { status = "Gagal menerapkan filter: $err"; nextTry = now + 5000L }
    }

    private fun clear(c: Context) {
        val err = sendMatrix(null)
        if (err == null) {
            applied = false; appliedSig = ""; nextTry = 0L; status = ""
            prefs(c).edit().putBoolean("applied", false).apply(); AppLog.i("FilterWarna", "dilepas, layar normal")
        } else { status = "Gagal memulihkan layar: $err"; nextTry = SystemClock.elapsedRealtime() + 5000L }
    }

    /** Dipanggil RecService tiap putaran dengan paket di depan. Paket kosong = tidak diketahui, keadaan tidak diubah. */
    @Synchronized
    fun onForeground(c: Context, pkg: String) {
        load(c)
        if (previewing || pkg.isEmpty()) return
        val now = SystemClock.elapsedRealtime()
        val want = enabled && !isIdentity() && pkg in WuWa.PACKAGES
        if (want) {
            val sig = signature()
            if (now >= nextTry && (!applied || sig != appliedSig || now - appliedAt > 5000L)) push(c, sig)
        } else if (applied && now >= nextTry) clear(c)
    }

    /** Terapkan nilai sekarang juga (dari overlay game). Bila tidak aktif / normal, filter dilepas. */
    @Synchronized
    fun applyNow(c: Context) {
        load(c)
        if (previewing) return
        if (enabled && !isIdentity()) push(c, signature()) else if (applied) clear(c)
    }

    /** Pilihan cepat: isi nilai preset, aktifkan filter, dan langsung terapkan. */
    fun choose(c: Context, i: Int) {
        val p = PRESETS.getOrNull(i) ?: return
        load(c)
        sat = p.sat; bright = p.bright; contrast = p.contrast; temp = p.temp; enabled = true
        save(c)
        Thread { applyNow(c) }.start()
    }

    /** Nama pilihan sekarang untuk tombol Gamebar. */
    fun label(): String = if (!enabled) "Mati" else presetIndex().let { if (it >= 0) PRESETS[it].name else "Kustom" }

    /** Ketuk di Gamebar: Mati -> Vivid -> Hangat -> Dingin -> Cinema -> Mati. Nilai kustom / Normal mulai lagi dari Vivid. */
    fun cycle(c: Context) {
        load(c)
        val idx = if (enabled) presetIndex() else -1
        when {
            idx in 1 until PRESETS.size - 1 -> choose(c, idx + 1)
            idx == PRESETS.size - 1 -> { enabled = false; save(c); Thread { applyNow(c) }.start() }
            else -> choose(c, 1)
        }
    }

    fun resetValues(c: Context) {
        val p = PRESETS[0]
        sat = p.sat; bright = p.bright; contrast = p.contrast; temp = p.temp
        save(c)
    }

    // ---------- Pratinjau di dalam aplikasi ----------
    @Synchronized
    fun applyPreview(c: Context) {
        load(c)
        previewing = true
        if (isIdentity()) { if (previewOn || applied) clear(c); previewOn = false }
        else { push(c, signature()); previewOn = applied }
    }

    @Synchronized
    fun endPreview(c: Context) {
        previewing = false
        if (previewOn) { previewOn = false; clear(c) }
    }

    /** Aplikasi ke latar belakang: pratinjau diakhiri supaya layar (dan game) tidak tertinggal berwarna. */
    fun onAppPaused(c: Context) { previewing = false; Thread { endPreview(c) }.start() }

    /** Aplikasi di depan = bukan game: sisa filter (mis. proses sempat dimatikan sistem) dilepas, lalu pratinjau boleh dipasang lagi. */
    fun onAppResumed(c: Context) {
        Thread { clearLeftover(c); resumeTick++ }.start()
    }

    @Synchronized
    private fun clearLeftover(c: Context) { load(c); if (applied && !previewing) clear(c) }

    /** Pulihkan layar sekarang (tombol di dialog, atau layanan berhenti). */
    @Synchronized
    fun forceReset(c: Context) { load(c); previewOn = false; clear(c) }

    fun resetIfApplied(c: Context) { Thread { if (applied) forceReset(c) }.start() }
}

// ---------- UI ----------

/** Kartu satu baris "Filter warna game" di halaman game; pengaturan lengkap muncul sebagai dialog. */
@Composable
fun GameColorCard() {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { GameColor.load(ctx) }
    var dlg by remember { mutableStateOf(false) }
    val idx = GameColor.presetIndex()
    val label = when { !GameColor.enabled -> "Mati"; idx >= 0 -> GameColor.PRESETS[idx].name; else -> "Kustom" }
    val sh = RoundedCornerShape(18.dp)
    Column(Modifier.fillMaxWidth().clip(sh).background(cardBg).border(1.dp, BD, sh)) {
        Row(Modifier.fillMaxWidth().clickable { dlg = true }.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Ico(5, Color(0xFFEE8FBE), 20.dp)
            Spacer(Modifier.width(10.dp))
            T("Filter warna game", 14, TX, true, maxLines = 1)
            Spacer(Modifier.weight(1f))
            Box(Modifier.clip(RoundedCornerShape(12.dp)).background(if (GameColor.enabled) VIOLET.copy(alpha = 0.85f) else Color(0xFF23252D)).padding(horizontal = 10.dp, vertical = 4.dp)) {
                T(label, 12, Color.White, true, maxLines = 1)
            }
            Spacer(Modifier.width(6.dp))
            T("›", 20, Color.White.copy(0.8f))
        }
        if (GameColor.status.isNotEmpty()) T(GameColor.status, 11, Color.White.copy(0.85f), false, Modifier.padding(start = 14.dp, end = 14.dp, bottom = 8.dp), 3)
    }
    if (dlg) GameColorDialog { dlg = false }
}

@Composable
private fun ColorSlider(label: String, shown: String, value: Int, range: IntRange, onChange: (Int) -> Unit, onDone: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { T(label, 13, Color.White); T(shown, 13, Color.White, true) }
    AccSlider(value.toFloat(), range.first.toFloat()..range.last.toFloat(), { onChange(it.roundToInt()) }, onDone)
}

@Composable
private fun GameColorDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    // Pratinjau: layar ikut berubah selama dialog terbuka, dilepas saat ditutup
    DisposableEffect(Unit) { onDispose { Thread { GameColor.endPreview(ctx) }.start() } }
    LaunchedEffect(GameColor.sat, GameColor.bright, GameColor.contrast, GameColor.temp, GameColor.resumeTick) {
        delay(120)
        withContext(Dispatchers.IO) { GameColor.applyPreview(ctx) }
    }
    val done = { GameColor.save(ctx) }
    TabDialog("Filter warna game", "Layar ini ikut berubah selama pengaturan terbuka", onDismiss) {
        SettingCard("Filter di game") {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("Aktifkan di game", 14, Color.White, true)
                    T("Warna di bawah dipasang otomatis saat Wuthering Waves di depan, dan dilepas saat keluar dari game.", 12, Color.White)
                }
                Toggle(GameColor.enabled) { on -> GameColor.enabled = on; GameColor.save(ctx); if (on) RecService.ensureRunning(ctx) }
            }
            if (!MonitorPrefs.notifOn) T("Butuh Notifikasi pantauan aktif (Settings) supaya filter bisa menyala sendiri saat game dibuka.", 12, Color(0xFFFFD866))
            if (Shell.mode() == "-") T("Butuh Shizuku atau Root. Buka tab Settings > Akses.", 12, Color(0xFFFFD866))
        }
        SettingCard("Pilihan cepat") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val cur = GameColor.presetIndex()
                GameColor.PRESETS.forEachIndexed { i, p ->
                    QChip(p.name, cur == i) {
                        GameColor.sat = p.sat; GameColor.bright = p.bright; GameColor.contrast = p.contrast; GameColor.temp = p.temp; GameColor.save(ctx)
                    }
                }
            }
        }
        SettingCard("Atur sendiri") {
            ColorSlider("Saturasi", "${GameColor.sat}%", GameColor.sat, 0..200, { GameColor.sat = it }, done)
            ColorSlider("Kecerahan", "${GameColor.bright}%", GameColor.bright, 70..130, { GameColor.bright = it }, done)
            ColorSlider("Kontras", "${GameColor.contrast}%", GameColor.contrast, 70..140, { GameColor.contrast = it }, done)
            ColorSlider("Suhu warna", when { GameColor.temp > 0 -> "Hangat +${GameColor.temp}"; GameColor.temp < 0 -> "Dingin ${GameColor.temp}"; else -> "Netral" },
                GameColor.temp, -50..50, { GameColor.temp = it }, done)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton("Atur ulang", filled = false) { GameColor.resetValues(ctx) }
                PillButton("Pulihkan layar", filled = false) { Thread { GameColor.forceReset(ctx) }.start() }
            }
        }
        T("Dari dalam game: ketuk overlay FPS, lalu pilih filter warna. Filter berlaku ke seluruh layar selama game di depan.", 12, Color.White)
    }
}
