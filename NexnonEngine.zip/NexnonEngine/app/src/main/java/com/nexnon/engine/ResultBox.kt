package com.nexnon.engine

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Kotak hasil: otomatis terisi saat Install / Hapus / Cek status, menunjukkan config benar-benar terpasang atau tidak. */
@Composable
fun ResultBox() {
    if (!Report.visible) return
    var logDlg by remember { mutableStateOf(false) }
    val clip = LocalClipboardManager.current
    val green = Color(0xFF5BD68E); val red = Color(0xFFE06060); val blue = Color(0xFF5B9BE0)
    val tint = when { Report.busy -> blue; Report.kind == "delete" -> red; Report.ok -> green; else -> red }
    val sh = RoundedCornerShape(18.dp)
    Column(Modifier.fillMaxWidth().clip(sh).background(CARD).border(1.dp, tint.copy(alpha = 0.35f), sh)
        .padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (Report.busy) CircularProgressIndicator(color = tint, strokeWidth = 2.5.dp, modifier = Modifier.size(22.dp))
            else Box(Modifier.size(24.dp).background(tint.copy(alpha = 0.2f), CircleShape), contentAlignment = Alignment.Center) {
                T(if (Report.kind == "delete") "−" else if (Report.ok) "✓" else "!", 14, tint, true)
            }
            Column(Modifier.weight(1f)) {
                T(Report.title, 15, TX, true)
                if (Report.sub.isNotEmpty()) T(Report.sub, 12, MUT, maxLines = 2)
            }
            if (!Report.busy && !Report.ok) Box(Modifier.size(36.dp).clip(CircleShape).clickable { logDlg = true }, contentAlignment = Alignment.Center) {
                T("Log", 12, Color(0xFFE8B84A), true)
            }
        }
        if (Report.rows.isNotEmpty()) {
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.08f)))
            Report.rows.forEach { r ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    T(when (r.state) { 1 -> "✓"; 2 -> "✕"; else -> "…" }, 14,
                        when (r.state) { 1 -> green; 2 -> red; else -> MUT }, true, Modifier.width(20.dp))
                    T(r.name, 13, TX, false, Modifier.weight(1f), 1)
                    if (r.note.isNotEmpty()) T(r.note, 12, MUT)
                }
            }
        }
    }
    if (logDlg) AlertDialog(
        onDismissRequest = { logDlg = false }, containerColor = CARD,
        title = { Text("Log", color = TX) },
        text = {
            Column(Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                if (Report.log.isEmpty()) T("Log kosong.", 13, MUT) else Report.log.forEach { T(it, 11, MUT) }
            }
        },
        confirmButton = { TextButton(onClick = { clip.setText(AnnotatedString(Report.log.joinToString("\n"))) }) { Text("Salin") } },
        dismissButton = { TextButton(onClick = { logDlg = false }) { Text("Tutup") } }
    )
}
