package com.nexnon.engine

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.SystemClock

/**
 * Sensor sistem yang direkam bersama FPS: beban CPU (total + tiap cluster), frekuensi CPU tiap inti, beban + frekuensi GPU,
 * suhu CPU / GPU / baterai / HP, daya (W), level baterai, RAM. Disalin dari Sampler PulseMonitor (jalur baca dan penguraiannya sama),
 * tanpa bagian overlay. Satu proses shell per pembacaan; hanya dipanggil saat merekam.
 */
object Sensors {
    class Data(
        val cpu: Int, val gpu: Int, val ramPct: Int, val tCpu: Float, val tGpu: Float, val tBat: Float, val tSkin: Float,
        val watt: Float, val batPct: Int, val gpuMhz: Int, val coreMhz: List<Int>, val clusterCpu: List<Pair<Int, Int>>,
        // Frekuensi maksimum + governor tiap cluster, (inti pertama cluster, nilai)
        val clMaxMhz: List<Pair<Int, Int>> = emptyList(), val govs: List<Pair<Int, String>> = emptyList(),
        // Frekuensi DDR (RAM fisik) dalam MHz, -1 = tidak terbaca
        val ddrMhz: Int = -1
    )

    // Urutan prioritas jalur beban GPU (sama seperti PulseMonitor)
    private const val GPU_PATHS = "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage " +
        "/sys/class/kgsl/kgsl-3d0/gpubusy " +
        "/sys/kernel/ged/hal/gpu_utilization " +
        "/sys/module/ged/parameters/gpu_loading " +
        "/proc/mali/utilization " +
        "/sys/class/kgsl/kgsl-3d0/devfreq/gpu_load " +
        "/sys/kernel/debug/ged/hal/gpu_utilization " +
        "/sys/kernel/gpu/gpu_busy"

    // Jalur arus / tegangan baterai (sysfs: arus uA, tegangan uV). battery dulu, lalu bms.
    private const val PWR_PATHS = "/sys/class/power_supply/battery/current_now /sys/class/power_supply/battery/voltage_now " +
        "/sys/class/power_supply/bms/current_now /sys/class/power_supply/bms/voltage_now"

    // Jalur frekuensi DDR (RAM fisik): Qualcomm (bus_dcvs), devfreq umum (ddr / dmc), MediaTek (dvfsrc). Satuan beda-beda, dinormalkan di parseDdrFreq().
    private const val DDR_PATHS = "/sys/devices/system/cpu/bus_dcvs/DDR/cur_freq " +
        "/sys/class/devfreq/*ddr*/cur_freq /sys/class/devfreq/*dmc*/cur_freq " +
        "/sys/class/devfreq/mtk-dvfsrc-devfreq/cur_freq /sys/class/devfreq/*dvfsrc*/cur_freq"

    @Volatile private var appCtx: Context? = null
    private var prevTotal = 0L; private var prevIdle = 0L; private var lastCpu = -1
    private val prevCore = HashMap<Int, LongArray>()
    private var lastReadAt = -100_000L
    @Volatile private var halCache: Hal? = null; @Volatile private var halAt = -10_000L; @Volatile private var halOkAt = -100_000L
    @Volatile private var halBusy = false
    private class Hal(val t: Temps, val n: Int)

    // Debug (diisi fungsi baca, tidak dipakai UI)
    @Volatile private var transDbg = "-"
    private var prevTrans: Map<Long, Long>? = null
    private var prevTransDir = ""
    @Volatile private var gpuFreqDbg = "-"
    private val gpuHist = HashMap<String, ArrayDeque<Int>>()
    /** Jalur frekuensi GPU yang dipilih pembacaan terakhir (dipakai jalur cepat Sampler). */
    @Volatile var gpuPickPath: String? = null; private set
    /** Jalur beban GPU yang dipilih pembacaan terakhir (dipakai jalur cepat Sampler). */
    @Volatile var gpuLoadPath: String? = null; private set
    @Volatile private var cpuFreqDbg = "-"
    @Volatile private var powerDbg = "-"
    private var powerSrc = ""

    /** Satuan sysfs bisa milli-derajat (42000), desi-derajat (420), atau derajat (42). */
    private fun norm(raw: Float) = when { raw >= 1000f -> raw / 1000f; raw > 150f -> raw / 10f; else -> raw }

    /** Suhu baterai: file sistem (segar) dulu, lalu broadcast BATTERY_CHANGED (1/10 derajat, dipotong ke bawah seperti DevCheck). */
    private fun batteryTemp(): Float {
        BatteryStats.freshTemp().takeIf { it > 0f }?.let { return it }
        val i = runCatching { appCtx?.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) }.getOrNull() ?: return -1f
        val raw = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        if (raw == Int.MIN_VALUE) return -1f
        return (raw / 10).toFloat().takeIf { it in 1f..100f } ?: -1f
    }

    /** Suhu baterai tanpa shell (file sistem / broadcast), untuk kartu suhu saat sensor lengkap belum terbaca. -1 = tidak ada. */
    fun quickBatteryTemp(ctx: Context): Float { if (appCtx == null) appCtx = ctx.applicationContext; return batteryTemp() }

    private fun batteryPct(): Int {
        val i = runCatching { appCtx?.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) }.getOrNull() ?: return -1
        val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        return if (l >= 0 && sc > 0) l * 100 / sc else -1
    }

    private val tempRe = Regex("Temperature\\{([^}]*mValue[^}]*)\\}")
    private val valRe = Regex("mValue\\s*=\\s*(-?[0-9.]+)")
    private val typeRe = Regex("mType\\s*=\\s*(-?\\d+)")
    private val nameRe = Regex("mName\\s*=\\s*([^,}]+)")
    private val halDown = Regex("(?i)hal\\s*ready:\\s*false")

    private class Temps {
        var cpu = -1f; var gpu = -1f; var bat = -1f; var skin = -1f; var soc = -1f
        fun put(kind: String, v: Float) {
            when (kind) {
                "cpu" -> cpu = maxOf(cpu, v); "gpu" -> gpu = maxOf(gpu, v); "bat" -> bat = maxOf(bat, v)
                "skin" -> skin = maxOf(skin, v); "soc" -> soc = maxOf(soc, v)
            }
        }
    }

    private fun kindOf(type: Int, name: String): String? {
        val n = name.lowercase()
        return when {
            "gpu" in n || "g3d" in n || "mali" in n || "adreno" in n -> "gpu"
            "batt" in n -> "bat"
            "cpu" in n -> "cpu"
            "skin" in n || "quiet" in n -> "skin"
            else -> when (type) { 0 -> "cpu"; 1 -> "gpu"; 2 -> "bat"; 3 -> "skin"; 13 -> "soc"; else -> null }
        }
    }

    private fun thermalHal(): Hal? {
        val out = Shell.execLimited("dumpsys thermalservice", 3000L)   // bisa lambat di MediaTek; jangan menggantung
        if (out.isBlank() || halDown.containsMatchIn(out)) return null
        val i = out.indexOf("Current temperatures from HAL")
        var sec = if (i >= 0) out.substring(i) else out
        val j = sec.indexOf("Cached temperatures"); if (j > 0) sec = sec.substring(0, j)
        val t = Temps(); var n = 0
        for (m in tempRe.findAll(sec)) {
            val body = m.groupValues[1]
            val v = valRe.find(body)?.groupValues?.get(1)?.toFloatOrNull() ?: continue
            if (v !in 1f..150f) continue          // buang sensor tidak valid (NaN/0/-ribuan)
            val ty = typeRe.find(body)?.groupValues?.get(1)?.toIntOrNull() ?: -1
            val nm = nameRe.find(body)?.groupValues?.get(1)?.trim() ?: ""
            kindOf(ty, nm)?.let { t.put(it, v); n++ }
        }
        return if (n > 0) Hal(t, n) else null
    }

    private fun parseZones(block: String): Temps {
        val zType = HashMap<String, String>(); val zTemp = HashMap<String, Float>()
        for (l in block.lines()) {
            val m = Regex("thermal_zone(\\d+)/(type|temp):(.*)").find(l) ?: continue
            val (z, k, v) = m.destructured
            if (k == "type") zType[z] = v.trim() else v.trim().toFloatOrNull()?.let { zTemp[z] = norm(it) }
        }
        val t = Temps()
        for ((z, ty) in zType) {
            val v = zTemp[z]?.takeIf { it in 5f..120f } ?: continue
            kindOf(-1, ty)?.let { t.put(it, v) }
        }
        return t
    }

    /** Suhu ringan untuk kartu suhu: hanya CPU / GPU / baterai / HP. */
    class QuickTemps(val tCpu: Float, val tGpu: Float, val tBat: Float, val tSkin: Float)

    /** Segarkan cache HAL di thread latar (tidak pernah memblokir pembacaan suhu). Hanya dipakai bila sysfs tidak punya suhu CPU/GPU. */
    private fun refreshHalAsync() {
        val now = SystemClock.elapsedRealtime()
        if (halBusy || now - halAt < 3000L) return
        halBusy = true; halAt = now
        Thread {
            try {
                val h = runCatching { thermalHal() }.getOrNull()
                val t = SystemClock.elapsedRealtime()
                if (h != null) { halCache = h; halOkAt = t } else if (t - halOkAt > 30_000L) halCache = null
            } finally { halBusy = false }
        }.apply { isDaemon = true; name = "thermal-hal"; start() }
    }

    /**
     * Suhu dari sysfs (segar tiap pembacaan, tanpa dumpsys) lebih dulu; HAL thermal hanya cadangan bila sysfs tidak punya
     * suhu CPU atau GPU. Dulu HAL jadi sumber utama dan dibaca sinkron tiap 3 detik, sehingga angka telat beberapa detik.
     */
    private fun resolveTemps(sysBlock: String, kgslRaw: String?): QuickTemps {
        val sys = parseZones(sysBlock)
        val kgsl = kgslRaw?.trim()?.toFloatOrNull()?.let { norm(it) }?.takeIf { it in 5f..120f } ?: -1f
        if (sys.cpu < 0f || (sys.gpu < 0f && kgsl < 0f)) refreshHalAsync()
        val hal = halCache
        fun pick(vararg c: Float): Float = c.firstOrNull { it >= 0f } ?: -1f
        val tCpu = pick(sys.cpu, hal?.t?.cpu ?: -1f, hal?.t?.soc ?: -1f)
        val tGpu = pick(sys.gpu, kgsl, hal?.t?.gpu ?: -1f)
        val tBat = pick(batteryTemp(), hal?.t?.bat ?: -1f, sys.bat)
        val tSkin = pick(sys.skin, hal?.t?.skin ?: -1f)
        return QuickTemps(tCpu, tGpu, tBat, tSkin)
    }

    /**
     * Baca suhu saja dengan SATU perintah shell tanpa jeda tidur (puluhan ms), terpisah dari [read] yang berat
     * (beban/frekuensi, sleep, dumpsys). Null bila tidak ada akses atau pembacaan gagal. Panggil dari thread latar.
     */
    fun readTemps(ctx: Context): QuickTemps? {
        appCtx = ctx.applicationContext
        if (Shell.mode() == "-") return null
        val out = Shell.execLimited(
            "grep -H . /sys/class/thermal/thermal_zone*/type /sys/class/thermal/thermal_zone*/temp 2>/dev/null; " +
            "echo ==; cat /sys/class/kgsl/kgsl-3d0/temp 2>/dev/null", 2500L
        )
        if (out.isBlank()) return null
        val parts = out.split("==")
        return resolveTemps(parts[0], parts.getOrNull(1))
    }

    private fun batteryWatt(): Float {
        val ctx = appCtx ?: return -1f
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager ?: return -1f
        val raw = runCatching { bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) }.getOrDefault(0)
        if (raw == 0 || raw == Int.MIN_VALUE) return -1f
        val mv = runCatching {
            ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        }.getOrNull() ?: 0
        if (mv <= 0) return -1f
        val a = Math.abs(raw.toLong())
        val amps = if (a > 20_000L) a / 1e6f else a / 1e3f
        return (amps * mv / 1000f).takeIf { it in 0f..60f } ?: -1f
    }

    private fun powerSysfs(block: String): Float? {
        if (block.isBlank()) return null
        val cur = HashMap<String, MutableList<Long>>(); val vol = HashMap<String, MutableList<Long>>()
        for (l in block.lines()) {
            val v = l.substringAfter(':', "").trim().toLongOrNull() ?: continue
            val p = l.substringBefore(':').trim(); val dir = p.substringBeforeLast('/')
            if (p.endsWith("/current_now")) cur.getOrPut(dir) { ArrayList() }.add(v)
            else if (p.endsWith("/voltage_now")) vol.getOrPut(dir) { ArrayList() }.add(v)
        }
        for (dir in listOf("/sys/class/power_supply/battery", "/sys/class/power_supply/bms")) {
            val c = cur[dir]?.filter { it != 0L && it != Long.MIN_VALUE } ?: continue
            val vv = vol[dir]?.filter { it > 0L } ?: continue
            if (c.isEmpty() || vv.isEmpty()) continue
            val a = c.map { Math.abs(it).toDouble() }.average()
            val volt = vv.average()
            val mA = if (a > 20_000.0) a / 1000.0 else a
            val mV = if (volt > 100_000.0) volt / 1000.0 else volt
            val w = (mA * mV / 1e6).toFloat()
            if (w !in 0f..60f || mV !in 2500.0..5500.0) continue
            powerDbg = "sysfs ${dir.substringAfterLast('/')}: ${c.size} sampel, %.0f mA x %.2f V = %.2f W".format(mA, mV / 1000.0, w)
            if (powerSrc != "sysfs") { powerSrc = "sysfs"; AppLog.i("Daya", "memakai sysfs $dir") }
            return w
        }
        if (powerSrc != "api") { powerSrc = "api"; AppLog.w("Daya", "sysfs arus/tegangan tidak terbaca, pakai BatteryManager") }
        return null
    }

    private fun transAvg(block: String): Int {
        var dir = ""; val cur = LinkedHashMap<Long, Long>()
        val row = Regex("^\\*?\\s*(\\d+):\\s*(.*)$")
        for (raw in block.lines()) {
            val l = raw.trim()
            if (l.startsWith("##")) { if (cur.isNotEmpty()) break; dir = l.drop(2); continue }
            val m = row.find(l) ?: continue
            val f = m.groupValues[1].toLongOrNull() ?: continue
            val t = m.groupValues[2].trim().split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }.lastOrNull() ?: continue
            cur[f] = t
        }
        if (cur.isEmpty()) { transDbg = "tidak ada"; prevTrans = null; return -1 }
        val prev = prevTrans
        prevTrans = cur; val sameDir = prevTransDir == dir; prevTransDir = dir
        if (prev == null || !sameDir) { transDbg = "${dir.substringAfter("/sys/")}: mengukur..."; return -1 }
        var tot = 0L; var sum = 0.0
        val parts = ArrayList<String>()
        val used = ArrayList<Pair<Double, Long>>()
        for ((f, t) in cur) {
            val d = t - (prev[f] ?: t)
            if (d <= 0) continue
            val mhz = when { f >= 10_000_000L -> f / 1e6; f >= 10_000L -> f / 1e3; else -> f.toDouble() }
            tot += d; sum += mhz * d; parts.add("%.0f:%dms".format(mhz, d)); used.add(mhz to d)
        }
        if (tot < 300L) { transDbg = "${dir.substringAfter("/sys/")}: selisih waktu kecil ($tot ms)"; return -1 }
        val avg = Math.round(sum / tot).toInt()
        // Puncak = frekuensi tertinggi yang dipakai minimal 5% dari jendela (min 40 ms), supaya lonjakan sesaat tidak dihitung
        val peak = used.filter { it.second >= maxOf(40L, tot / 20) }.maxOfOrNull { it.first }?.let { Math.round(it).toInt() } ?: avg
        transDbg = "${dir.substringAfter("/sys/")}: ${parts.joinToString(" ")} -> rata2 $avg, puncak $peak MHz"
        return if (peak in 100..3500) peak else -1
    }

    private fun parseGpuFreq(block: String): Int {
        val mhzBy = LinkedHashMap<String, MutableList<Int>>()
        val rawBy = LinkedHashMap<String, MutableList<String>>()
        for (l in block.lines()) {
            if (l.indexOf(':') <= 0) continue
            // GPUFREQV2:<baris asli> : ambil angka kHz pada baris yang menyebut cur/current/real freq
            if (l.startsWith("GPUFREQV2:")) {
                val body = l.substring(10)
                if (!Regex("(?i)(cur|real|now|actual)").containsMatchIn(body)) continue
                val kHz = Regex("\\d{5,8}").findAll(body).mapNotNull { it.value.toLongOrNull() }.firstOrNull() ?: continue
                val mhz = (if (kHz >= 10_000_000L) kHz / 1_000_000 else kHz / 1000).toInt()
                mhzBy.getOrPut("gpufreqv2") { ArrayList() }.add(mhz)
                rawBy.getOrPut("gpufreqv2") { ArrayList() }.add(body.trim().take(40))
                continue
            }
            val i = l.lastIndexOf(':')
            val path = l.substring(0, i); val raw = l.substring(i + 1).trim()
            val nums = Regex("\\d+").findAll(raw).mapNotNull { it.value.toLongOrNull() }.toList()
            if (nums.isEmpty()) continue
            // current_freqency (GED MediaTek) berformat "indeks kHz": ambil angka terbesar; lainnya angka pertama
            val v = if (path.endsWith("current_freqency")) nums.max() else nums[0]
            val mhz = when {
                path.endsWith("gpu_clock") || path.endsWith("clock_mhz") -> v
                v >= 10_000_000L -> v / 1_000_000
                v >= 10_000L -> v / 1000
                else -> v
            }.toInt()
            mhzBy.getOrPut(path) { ArrayList() }.add(mhz)
            rawBy.getOrPut(path) { ArrayList() }.add(raw)
        }
        // Nilai tiap sumber pada tick ini = sampel TERAKHIR yang valid (nilai paling baru, bukan puncak).
        val cur = LinkedHashMap<String, Int>()
        for ((path, list) in mhzBy) list.lastOrNull { it in 100..3500 }?.let { cur[path] = it }
        // Deteksi sumber macet: simpan 8 tick terakhir per sumber.
        for ((path, v) in cur) { val h = gpuHist.getOrPut(path) { ArrayDeque() }; h.addLast(v); while (h.size > 8) h.removeFirst() }
        fun stuck(path: String) = gpuHist[path]?.let { it.size >= 8 && it.distinct().size == 1 } ?: false
        fun moving(path: String) = gpuHist[path]?.let { it.size >= 8 && it.distinct().size > 1 } ?: false
        // Prioritas biasa; bila sumber teratas macet padahal ada sumber lain yang bergerak, pakai yang bergerak.
        // MediaTek: GED current_freqency didahulukan, lalu gpufreqv2 (di Dimensity bisa 26 MHz saat GPU tidur), baru sumber lain.
        val ordered = cur.keys.sortedBy { when { it.endsWith("current_freqency") -> 0; it == "gpufreqv2" -> 2; else -> 1 } }
        var pickPath = ordered.firstOrNull()
        if (pickPath != null && stuck(pickPath)) ordered.firstOrNull { moving(it) }?.let { pickPath = it }
        gpuPickPath = pickPath
        val pick = pickPath?.let { cur[it] } ?: -1
        val seen = mhzBy.keys.map { p ->
            val flag = if (stuck(p)) " [MACET]" else if (moving(p)) " [bergerak]" else ""
            "${p.substringAfter("/sys/").take(40)}=${rawBy[p]!!.distinct().joinToString("/")}$flag"
        }
        gpuFreqDbg = if (seen.isEmpty()) "tidak ada jalur terbaca" else seen.joinToString("; ") +
            " -> " + (if (pick >= 0) "$pick MHz (${pickPath!!.substringAfterLast('/')})" else "tidak valid")
        return pick
    }

    private fun parseCpuFreq(block: String): Int {
        var best = -1; val parts = ArrayList<String>()
        for (l in block.lines()) {
            val f = l.trim().split(':'); if (f.size < 2 || !f[0].startsWith("cpu")) continue
            val scaling = f[1].trim().toLongOrNull()?.takeIf { it > 0 }
            val info = f.getOrNull(2)?.trim()?.toLongOrNull()?.takeIf { it > 0 }
            val kHz = scaling ?: info ?: continue
            val mhz = (kHz / 1000).toInt()
            parts.add("${f[0].removePrefix("cpu")}=$mhz" + if (info != null && info != kHz) "(i${info / 1000})" else "")
            if (mhz in 100..5000 && mhz > best) best = mhz
        }
        cpuFreqDbg = if (parts.isEmpty()) "tidak terbaca" else parts.joinToString(" ") + " -> $best MHz"
        return best
    }

    private fun coreTimes(block: String): Map<Int, LongArray> {
        val m = HashMap<Int, LongArray>()
        for (l in block.lines()) {
            val mt = Regex("^cpu(\\d+)\\s+(.+)$").find(l.trim()) ?: continue
            val idx = mt.groupValues[1].toIntOrNull() ?: continue
            val v = mt.groupValues[2].trim().split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }
            if (v.size >= 5) m[idx] = longArrayOf(v.take(8).sum(), v[3] + v[4])
        }
        return m
    }

    private fun clusterUsage(statBlock: String, policyBlock: String): List<Pair<Int, Int>> {
        val cur = coreTimes(statBlock)
        val starts = Regex("policy(\\d+)").findAll(policyBlock).mapNotNull { it.groupValues[1].toIntOrNull() }.distinct().sorted().toList()
        val dTotal = HashMap<Int, Long>(); val dBusy = HashMap<Int, Long>()
        for ((i, now) in cur) {
            val p = prevCore[i]; prevCore[i] = now
            if (p == null || now[0] <= p[0] || starts.isEmpty()) continue
            val dt = now[0] - p[0]; val busy = dt - (now[1] - p[1])
            val cl = starts.lastOrNull { it <= i } ?: continue
            dTotal[cl] = (dTotal[cl] ?: 0L) + dt; dBusy[cl] = (dBusy[cl] ?: 0L) + busy.coerceIn(0L, dt)
        }
        return starts.mapNotNull { cl ->
            val t = dTotal[cl] ?: return@mapNotNull null
            cl to Math.round(100.0 * (dBusy[cl] ?: 0L) / t).toInt().coerceIn(0, 100)
        }
    }

    private fun parseCoreFreqs(block: String): List<Int> {
        val m = java.util.TreeMap<Int, Int>()
        for (l in block.lines()) {
            val f = l.trim().split(':'); if (f.size < 2 || !f[0].startsWith("cpu")) continue
            val idx = f[0].removePrefix("cpu").toIntOrNull() ?: continue
            val kHz = f[1].trim().toLongOrNull()?.takeIf { it > 0 } ?: f.getOrNull(2)?.trim()?.toLongOrNull()?.takeIf { it > 0 }
            m[idx] = if (kHz != null) (kHz / 1000).toInt() else -1
        }
        if (m.isEmpty()) return emptyList()
        return (0..m.lastKey()).map { m[it] ?: -1 }
    }

    /** Satu pembacaan semua sensor. Null bila tidak ada akses Shizuku/root. Panggil dari thread latar (menjalankan shell). */
    @Synchronized
    fun read(ctx: Context): Data? {   // @Synchronized: tab Statistik dan perekam bisa membaca bersamaan, pembanding CPU dipakai bersama
        appCtx = ctx.applicationContext
        if (Shell.mode() == "-") return null
        val t0 = SystemClock.elapsedRealtime()
        // Jeda panjang sejak pembacaan terakhir (rekaman baru): pembanding CPU basi, ambil ulang supaya selisih pertama bermakna
        if (t0 - lastReadAt > 5_000L) { prevTotal = 0L; prevIdle = 0L; prevCore.clear() }
        lastReadAt = t0
        if (prevTotal == 0L) runCatching {
            val blk = Shell.exec("grep '^cpu' /proc/stat")
            val b = blk.trim().lines().firstOrNull().orEmpty().trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (b.size >= 5) {
                prevTotal = b.take(8).sum(); prevIdle = b[3] + b[4]
                prevCore.clear(); prevCore.putAll(coreTimes(blk))
                Thread.sleep(300)
            }
        }
        val out = Shell.exec(
            "grep '^cpu' /proc/stat; echo ==; for n in 1 2 3 4 5 6; do for f in $GPU_PATHS; do [ -r \$f ] && echo \"\$f:\$(cat \$f 2>/dev/null)\"; done; [ \$n -lt 6 ] && sleep 0.07; done; echo ==; " +
            "grep -E '^(MemTotal|MemAvailable|SwapTotal|SwapFree):' /proc/meminfo; echo ==; grep -H . /sys/class/thermal/thermal_zone*/type /sys/class/thermal/thermal_zone*/temp 2>/dev/null; " +
            "echo ==; cat /sys/class/kgsl/kgsl-3d0/temp 2>/dev/null; " +
            "echo ==; for d in /sys/devices/system/cpu/cpu[0-9]*; do [ -r \$d/cpufreq/scaling_cur_freq ] && echo \"\${d##*/}:\$(cat \$d/cpufreq/scaling_cur_freq 2>/dev/null):\$(cat \$d/cpufreq/cpuinfo_cur_freq 2>/dev/null)\"; done; " +
            "echo ==; for n in 1 2 3 4; do for f in /sys/class/kgsl/kgsl-3d0/devfreq/cur_freq /sys/class/kgsl/kgsl-3d0/gpuclk " +
            "/sys/class/kgsl/kgsl-3d0/clock_mhz /sys/class/devfreq/*kgsl*/cur_freq " +
            "/sys/class/devfreq/*mali*/cur_freq /sys/class/devfreq/*.gpu/cur_freq /sys/devices/platform/*mali*/cur_freq " +
            "/sys/kernel/ged/hal/current_freqency /sys/kernel/gpu/gpu_clock; " +
            "do [ -r \$f ] && echo \"\$f:\$(cat \$f 2>/dev/null | tr '\\n' ' ')\"; done; [ \$n -lt 4 ] && sleep 0.05; done; " +
            "[ -r /proc/gpufreqv2/gpufreq_status ] && grep -i -E 'freq' /proc/gpufreqv2/gpufreq_status 2>/dev/null | head -12 | sed 's/^/GPUFREQV2:/'; " +
            "echo ==; for d in /sys/class/kgsl/kgsl-3d0/devfreq /sys/class/devfreq/*kgsl* /sys/class/devfreq/*mali* /sys/class/devfreq/*.gpu; do " +
            "[ -r \$d/trans_stat ] && { echo \"##\$d\"; cat \$d/trans_stat 2>/dev/null; }; done; " +
            "echo ==; echo ==; " +
            // Governor tiap cluster (blok ke-11 hasil split, sebelumnya kosong)
            "echo ==; for p in /sys/devices/system/cpu/cpufreq/policy[0-9]*; do [ -r \$p/scaling_governor ] && echo \"\${p##*/}:\$(cat \$p/scaling_governor 2>/dev/null)\"; done; " +
            "echo ==; for p in /sys/devices/system/cpu/cpufreq/policy[0-9]*; do [ -d \$p ] && echo \"\${p##*/}:\$(cat \$p/cpuinfo_max_freq 2>/dev/null || cat \$p/scaling_max_freq 2>/dev/null)\"; done; " + "echo ==" +
            // Arus + tegangan baterai langsung dari sysfs, 3 pembacaan berjarak 80 ms lalu dirata-rata di powerSysfs()
            "; echo ==; for n in 1 2 3; do for f in $PWR_PATHS; do [ -r \$f ] && echo \"\$f:\$(cat \$f 2>/dev/null)\"; done; [ \$n -lt 3 ] && sleep 0.08; done" +
            // Frekuensi DDR (blok ke-14, setelah blok daya)
            "; echo ==; for f in $DDR_PATHS; do [ -r \$f ] && echo \"\$f:\$(cat \$f 2>/dev/null | tr '\\n' ' ')\"; done"
        ).split("==")
        if (out.size < 4) return null

        // CPU total
        val c = out[0].trim().lines().firstOrNull().orEmpty().trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        var cpu = -1
        if (c.size >= 5) {
            val total = c.take(8).sum(); val idle = c[3] + c[4]
            if (prevTotal > 0 && total > prevTotal) cpu = (100 * ((total - prevTotal) - (idle - prevIdle)) / (total - prevTotal)).toInt()
            prevTotal = total; prevIdle = idle
        }
        if (cpu < 0) cpu = lastCpu else lastCpu = cpu
        val clusterCpu = runCatching { clusterUsage(out[0], out.getOrNull(11) ?: "") }.getOrDefault(emptyList())

        // Beban GPU: tiap jalur dibaca 6x dalam ~0,4 detik lalu dirata-rata; jalur pertama (urutan prioritas) yang punya sampel dipakai
        val loadBy = LinkedHashMap<String, MutableList<Int>>()
        for (line in out[1].lines()) {
            val path = line.substringBefore(':')
            val nums = Regex("\\d+").findAll(line.substringAfter(':', "")).mapNotNull { it.value.toLongOrNull() }.toList()
            val v: Int = when {
                nums.isEmpty() -> null
                path.endsWith("gpubusy") -> nums.getOrNull(1)?.takeIf { it > 0 }?.let { (100 * nums[0] / it).toInt().coerceIn(0, 100) }
                else -> nums[0].toInt().takeIf { it in 0..100 }
            } ?: continue
            loadBy.getOrPut(path) { ArrayList() }.add(v)
        }
        val loadPick = loadBy.entries.firstOrNull { it.value.isNotEmpty() }
        val gpu = loadPick?.let { Math.round(it.value.average()).toInt() } ?: -1
        gpuLoadPath = loadPick?.key

        // Frekuensi GPU (trans_stat berbobot waktu, kecuali sumber MediaTek yang harus dibaca langsung)
        val gpuInst = parseGpuFreq(out.getOrNull(6) ?: "")
        val gpuTrans = transAvg(out.getOrNull(7) ?: "")
        val preferInst = gpuPickPath?.let { it.endsWith("current_freqency") || it == "gpufreqv2" } ?: false
        val gpuMhz = (if (!preferInst && gpuTrans > 0) gpuTrans else gpuInst).takeIf { it > 0 } ?: -1

        // RAM
        val meminfo = out[2]
        fun kb(n: String) = Regex("(?m)^$n:\\s+(\\d+)").find(meminfo)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        val tot = kb("MemTotal"); val av = kb("MemAvailable")
        val ramPct = if (tot > 0) (100 * (tot - av).coerceIn(0L, tot) / tot).toInt() else -1

        // Suhu: sysfs (segar tiap tick) -> HAL thermal di latar (cadangan); baterai dari file sistem / broadcast
        val qt = resolveTemps(out[3], out.getOrNull(4))
        val tCpu = qt.tCpu; val tGpu = qt.tGpu; val tBat = qt.tBat; val tSkin = qt.tSkin

        // Daya: sysfs (arus x tegangan, dirata-rata) dulu; cadangan BatteryManager
        val watt = powerSysfs(out.getOrNull(13) ?: "") ?: batteryWatt()

        return Data(cpu, gpu, ramPct, tCpu, tGpu, tBat, tSkin, watt, batteryPct(), gpuMhz,
            parseCoreFreqs(out.getOrNull(5) ?: ""), clusterCpu,
            parseClusterMax(out.getOrNull(11) ?: ""), parseGovs(out.getOrNull(10) ?: ""),
            ddrMhz = parseDdrFreq(out.getOrNull(14) ?: ""))
    }

    /** Frekuensi DDR dari baris "jalur:nilai". Jalur pertama yang punya angka dipakai. Satuan: Hz, kHz, atau MHz (ditebak dari besarnya). */
    private fun parseDdrFreq(block: String): Int {
        for (l in block.lines()) {
            val v = Regex("\\d+").find(l.substringAfter(':', ""))?.value?.toLongOrNull()?.takeIf { it > 0 } ?: continue
            val mhz = when { v >= 100_000_000L -> v / 1_000_000L; v >= 100_000L -> v / 1_000L; else -> v }
            if (mhz in 50L..10_000L) return mhz.toInt()
        }
        return -1
    }

    /** Governor tiap cluster dari baris "policyN:nama". N = nomor inti pertama cluster. */
    private fun parseGovs(block: String): List<Pair<Int, String>> =
        block.lines().mapNotNull { l ->
            val m = Regex("^policy(\\d+):(.+)$").find(l.trim()) ?: return@mapNotNull null
            val g = m.groupValues[2].trim().ifEmpty { return@mapNotNull null }
            (m.groupValues[1].toIntOrNull() ?: return@mapNotNull null) to g
        }.sortedBy { it.first }

    /** Frekuensi maksimum tiap cluster dari baris "policyN:kHz". Cluster tanpa nilai terbaca dilewati. */
    private fun parseClusterMax(block: String): List<Pair<Int, Int>> =
        block.lines().mapNotNull { l ->
            val m = Regex("^policy(\\d+):(\\d+)$").find(l.trim()) ?: return@mapNotNull null
            val mhz = (m.groupValues[2].toLongOrNull() ?: return@mapNotNull null) / 1000
            if (mhz <= 0) return@mapNotNull null
            (m.groupValues[1].toIntOrNull() ?: return@mapNotNull null) to mhz.toInt()
        }.sortedBy { it.first }
}
