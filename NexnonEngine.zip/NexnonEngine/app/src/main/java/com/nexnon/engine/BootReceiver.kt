package com.nexnon.engine

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Setelah HP menyala / aplikasi diperbarui: bila notifikasi pantauan nyala, hidupkan lagi. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED || i.action == Intent.ACTION_MY_PACKAGE_REPLACED) RecService.ensureRunning(c)
        if (i.action == Intent.ACTION_BOOT_COMPLETED || i.action == Intent.ACTION_MY_PACKAGE_REPLACED) Gamebar.sync(c)
    }
}
