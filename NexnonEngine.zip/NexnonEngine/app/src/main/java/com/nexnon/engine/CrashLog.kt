package com.nexnon.engine

import android.app.Application
import java.io.File

/** Menyimpan jejak crash ke log (ikut tertulis di berkas log Download dan laporan kesehatan). */
object CrashLog {
    fun install(app: Application) {
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching { AppLog.e("CRASH", "thread ${t.name}", e) }
            runCatching { AppLog.keepCrash(app, "${java.util.Date()}\nThread: ${t.name}\n${android.util.Log.getStackTraceString(e)}") }
            runCatching { AppLog.exportNow() }
            old?.uncaughtException(t, e)
        }
    }
}
