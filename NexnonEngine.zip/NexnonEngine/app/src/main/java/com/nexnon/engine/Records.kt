package com.nexnon.engine

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val RowBg = Color(0xFF0F1116)

fun appIcon(ctx: Context, pkg: String): Bitmap? = runCatching {
    val d = ctx.packageManager.getApplicationIcon(pkg)
    val bmp = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
    d.setBounds(0, 0, 192, 192); d.draw(android.graphics.Canvas(bmp)); bmp
}.getOrNull()

/** Daftar rekaman, dimuat ulang tiap Recorder.version berubah. */
@Composable
fun rememberRecords(): State<List<Session>> {
    val ctx = LocalContext.current
    val ver = Recorder.version
    return produceState<List<Session>>(emptyList(), ver) { value = withContext(Dispatchers.IO) { Recorder.list(ctx) } }
}

/** Ikon daftar (tiga titik + garis), sama seperti ikon riwayat di Pulse Monitor. */
@Composable
fun HistoryIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width; val h = size.height; val sw = w * 0.1f
    listOf(0.22f, 0.5f, 0.78f).forEach { y ->
        drawCircle(c, sw * 0.8f, Offset(w * 0.1f, h * y))
        drawLine(c, Offset(w * 0.32f, h * y), Offset(w * 0.92f, h * y), sw, StrokeCap.Round)
    }
}

/** Kartu Rekam FPS di Beranda: titik status, judul + keterangan, ikon riwayat berlencana, tombol Mulai / Berhenti. */
@Composable
fun RecCard() {
    val ctx = LocalContext.current
    val list by rememberRecords()
    var showList by remember { mutableStateOf(false) }
    val rec = Recorder.active
    // Detik berjalan: Recorder.count bertambah ~tiap detik
    val sh = RoundedCornerShape(22.dp)
    val red = Color(0xFFFF5C5C)
    Row(Modifier.fillMaxWidth().background(cardBg, sh).border(1.dp, BD, sh).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        val blink by rememberInfiniteTransition(label = "rec").animateFloat(1f, 0.25f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "dot")
        Box(Modifier.size(12.dp).graphicsLayer { alpha = if (rec) blink else 1f }.background(if (rec) red else PINK, CircleShape))
        Column(Modifier.weight(1f)) {
            T(if (rec) "Merekam · ${fmtDur(Recorder.count)}" else "Rekam FPS", 17, TX, true, maxLines = 1)
            T(if (rec) "${Recorder.lastFps} FPS saat ini" else "Lalu buka game", 13, MUT, maxLines = 1)
        }
        Box(Modifier.size(44.dp)) {
            Box(Modifier.fillMaxSize().clip(CircleShape).background(Color(0xFF2B2F3A)).clickable { showList = true }, contentAlignment = Alignment.Center) {
                HistoryIcon(TX, Modifier.size(20.dp))
            }
            if (list.isNotEmpty()) Box(Modifier.align(Alignment.TopEnd).offset(6.dp, (-6).dp).defaultMinSize(20.dp, 20.dp)
                .background(PINK, CircleShape).padding(horizontal = 4.dp), contentAlignment = Alignment.Center) {
                T(if (list.size > 9) "9+" else "${list.size}", 11, Color.Black, true, maxLines = 1)
            }
        }
        Box(Modifier.clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(if (rec) listOf(Color(0xFFE5677A), PINK) else listOf(Color(0xFFF4A0C4), PINK)))
            .clickable { RecCtl.toggle(ctx) }.padding(horizontal = 20.dp, vertical = 12.dp)) {
            T(if (rec) "Berhenti" else "Mulai", 16, if (rec) Color.White else Color.Black, true, maxLines = 1)
        }
    }
    if (showList) TabDialog("Rekaman", if (list.isEmpty()) "Belum ada rekaman FPS" else "${list.size} rekaman FPS, ketuk untuk lihat laporan", { showList = false }) {
        if (list.isEmpty()) Text("Belum ada rekaman. Tekan Mulai, lalu buka game.", color = MUT, fontSize = 13.sp,
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), textAlign = TextAlign.Center)
        else list.forEach { r -> RecRow(r) { showList = false; Store.reportId = r.id } }
        Text("Rekaman juga bisa dimulai dan dihentikan lewat tombol di notifikasi, jadi tidak perlu keluar dari game.",
            color = MUT.copy(alpha = 0.85f), fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 8.dp, start = 4.dp, end = 4.dp))
    }
}

/** Kartu riwayat: ikon game, nama, tanggal, rata-rata FPS, grafik mini FPS, dan chip Min / 5% low / Maks. */
@Composable
fun RecRow(r: Session, onClick: () -> Unit) {
    val st = remember(r.id) { r.stats() }
    val ctx = LocalContext.current
    val icon = remember(r.pkg) { appIcon(ctx, r.pkg) }
    val whenTxt = remember(r.id) { SimpleDateFormat("d MMM · HH:mm", Locale.getDefault()).format(Date(r.id)) }
    val spark = remember(r.id) {
        val f = r.fps.filter { it > 0f }
        if (f.size <= 60) f else List(60) { i -> f[(i * (f.size - 1)) / 59] }
    }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(RowBg).clickable { onClick() }
        .padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) Image(icon.asImageBitmap(), null, Modifier.size(44.dp).clip(RoundedCornerShape(11.dp)))
            else Box(Modifier.size(44.dp).background(Color(0xFF262833), RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
                T(r.label.take(1).uppercase(), 18, Color.White, true)
            }
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                T(r.label, 16, Color.White, true, maxLines = 1)
                T(whenTxt + (if (r.res.isBlank()) "" else " · ${r.res}"), 12, MUT, maxLines = 1)
            }
            Column(Modifier.padding(start = 10.dp), horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.Bottom) {
                    T(f1(st.avg), 22, CYAN, true, maxLines = 1)
                    Text(" FPS", color = MUT, fontSize = 11.sp, modifier = Modifier.padding(bottom = 3.dp))
                }
                T(fmtDur(r.dur), 12, MUT, maxLines = 1)
            }
        }
        if (spark.size >= 2) Canvas(Modifier.fillMaxWidth().height(30.dp)) {
            var lo = spark.min(); var hi = spark.max()
            if (hi - lo < 4f) { val m = (hi + lo) / 2f; lo = m - 2f; hi = m + 2f }
            val path = Path()
            spark.forEachIndexed { i, v ->
                val x = size.width * i / (spark.size - 1)
                val y = size.height * (1f - (v - lo) / (hi - lo))
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, CYAN.copy(alpha = 0.9f), style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Min" to st.min, "5% low" to st.low5, "Maks" to st.max).forEach { (k, v) ->
                Row(Modifier.background(Color.White.copy(alpha = 0.06f), CircleShape).padding(horizontal = 10.dp, vertical = 4.dp)) {
                    Text("$k ", color = MUT, fontSize = 11.sp)
                    Text("%.0f".format(v), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/** Laporan satu rekaman: header, kartu statistik, grafik FPS, catatan, bagikan / CSV / hapus. */
@Composable
fun ReportScreen(id: Long, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val sess by produceState<Session?>(null, id) { value = withContext(Dispatchers.IO) { Recorder.load(ctx, id) } }
    val s = sess
    if (s == null) { Box(Modifier.fillMaxSize().background(BG), contentAlignment = Alignment.Center) { T("Memuat…", 14, MUT) }; return }
    val st = remember(s) { s.stats() }
    val icon = remember(s.pkg) { appIcon(ctx, s.pkg) }
    var desc by remember(s.id) { mutableStateOf(s.desc) }
    var confirm by remember { mutableStateOf(false) }
    var deleted by remember { mutableStateOf(false) }
    LaunchedEffect(desc) { if (desc != s.desc && !deleted) { delay(600); withContext(Dispatchers.IO) { Recorder.saveDesc(ctx, s, desc) } } }
    // Catatan yang baru diketik lalu langsung ditinggal tetap tersimpan
    val latest by rememberUpdatedState(desc)
    DisposableEffect(s.id) { onDispose { if (!deleted && latest != s.desc) Thread { Recorder.saveDesc(ctx, s, latest) }.start() } }

    Column(Modifier.fillMaxSize().background(BG).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        T("‹ Kembali", 15, AC, true, Modifier.clickable { onBack() }.padding(vertical = 4.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (icon != null) Image(icon.asImageBitmap(), null, Modifier.size(52.dp).clip(RoundedCornerShape(13.dp)))
            Column(Modifier.weight(1f)) {
                T(s.label, 22, TX, true, maxLines = 1)
                T("${fmtDate(s.id)} · ${fmtDur(s.dur)}", 12, MUT)
            }
            Column(horizontalAlignment = Alignment.End) { T(f1(st.avg), 30, CYAN, true); T("FPS rata-rata", 11, MUT) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile("Min", "%.0f".format(st.min), Modifier.weight(1f)); Tile("Maks", "%.0f".format(st.max), Modifier.weight(1f)); Tile("5% low", f1(st.low5), Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile("1% low", f1(st.low1), Modifier.weight(1f)); Tile("Kehalusan", "${f1(st.smooth)}%", Modifier.weight(1f)); Tile("Drop FPS", "${st.drops}×", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile("Frametime", "${f1(st.ftAvg)} ms", Modifier.weight(1f))
            Tile("Terburuk", if (st.frameBased) "${f1(st.ftMax)} ms" else "${f1(st.ftMax)} ms*", Modifier.weight(1f))
            Tile("Jank / Big", if (st.frameBased) "${st.jank} / ${st.bigJank}" else "-", Modifier.weight(1f))
        }
        if (!st.frameBased) T("* Frame asli tidak cukup terbaca di rekaman ini, jadi 5% / 1% low dan Frametime dihitung dari FPS per detik.", 11, MUT)

        Card2 {
            T("FPS", 14, TX, true); Sp(8)
            val pts = remember(s.id) { capFps(s.fps).despike() }
            Canvas(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(12.dp)).background(CYAN.copy(alpha = 0.08f))) {
                if (pts.size < 2) return@Canvas
                val hi = maxOf(60f, pts.max()) * 1.1f
                listOf(30f, 60f, 90f, 120f).filter { it < hi }.forEach { g ->
                    val y = size.height - (g / hi) * size.height
                    drawLine(Color.White.copy(alpha = 0.12f), Offset(0f, y), Offset(size.width, y), 1.dp.toPx())
                }
                val path = Path()
                pts.forEachIndexed { i, v ->
                    val x = size.width * i / (pts.size - 1)
                    val y = size.height - 4.dp.toPx() - (v.coerceAtLeast(0f) / hi) * (size.height - 8.dp.toPx())
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, CYAN, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            Sp(6)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                T("0:00", 11, MUT); T("30 · 60 · 90 · 120 FPS (garis bantu)", 11, MUT); T(fmtDur(s.dur), 11, MUT)
            }
        }

        OutlinedTextField(desc, { desc = it }, label = { Text("Catatan (opsional)") }, modifier = Modifier.fillMaxWidth())

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PillButton("Bagikan") {
                val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, Recorder.summary(s)) }
                ctx.startActivity(Intent.createChooser(i, "Bagikan laporan"))
            }
            PillButton("Simpan CSV", filled = false) {
                Thread {
                    val ok = Recorder.exportCsv(ctx, s)
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        Toast.makeText(ctx, if (ok) "CSV tersimpan di folder Download" else "Gagal menyimpan CSV", Toast.LENGTH_SHORT).show()
                    }
                }.start()
            }
            PillButton("Hapus", filled = false) { confirm = true }
        }
        Sp(8)
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, containerColor = Color.Black, shape = RoundedCornerShape(28.dp),
        title = { Text("Hapus rekaman?", color = TX, fontWeight = FontWeight.SemiBold) },
        text = { Text("${s.label} · ${fmtDur(s.dur)} akan dihapus permanen.", color = TX) },
        confirmButton = { TextButton(onClick = { confirm = false; deleted = true; Recorder.delete(ctx, s.id); onBack() }) { Text("Hapus", color = Color(0xFFFF5C5C), fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Batal", color = VIOLET, fontWeight = FontWeight.Bold) } }
    )
}
