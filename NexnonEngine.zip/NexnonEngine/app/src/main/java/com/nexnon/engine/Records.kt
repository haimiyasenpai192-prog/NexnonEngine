package com.nexnon.engine

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val RowBg = Color(0xFF0F1116)

fun appIcon(ctx: Context, pkg: String): Bitmap? = runCatching {
    val d = ctx.packageManager.getApplicationIcon(pkg)
    val bmp = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
    d.setBounds(0, 0, 192, 192); d.draw(android.graphics.Canvas(bmp)); bmp
}.getOrNull()

/** Daftar rekaman, dimuat ulang tiap Recorder.version berubah. */
@Composable
fun rememberRecords(): State<List<Session>> {
    val ctx = LocalContext.current
    val ver = Recorder.version
    return produceState<List<Session>>(emptyList(), ver) { value = withContext(Dispatchers.IO) { Recorder.list(ctx) } }
}

/** Ikon daftar (tiga titik + garis), sama seperti ikon riwayat di Pulse Monitor. */
@Composable
fun HistoryIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width; val h = size.height; val sw = w * 0.1f
    listOf(0.22f, 0.5f, 0.78f).forEach { y ->
        drawCircle(c, sw * 0.8f, Offset(w * 0.1f, h * y))
        drawLine(c, Offset(w * 0.32f, h * y), Offset(w * 0.92f, h * y), sw, StrokeCap.Round)
    }
}

/** Kartu Rekam FPS di Beranda: titik status, judul + keterangan, ikon riwayat berlencana, tombol Mulai / Berhenti. */
@Composable
fun RecCard() {
    val ctx = LocalContext.current
    val list by rememberRecords()
    var showList by remember { mutableStateOf(false) }
    val rec = Recorder.active
    // Detik berjalan: Recorder.count bertambah ~tiap detik
    val sh = RoundedCornerShape(22.dp)
    val red = Color(0xFFFF5C5C)
    Row(Modifier.fillMaxWidth().background(cardBg, sh).border(1.dp, BD, sh).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        val blink by rememberInfiniteTransition(label = "rec").animateFloat(1f, 0.25f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "dot")
        Box(Modifier.size(12.dp).graphicsLayer { alpha = if (rec) blink else 1f }.background(if (rec) red else PINK, CircleShape))
        Column(Modifier.weight(1f)) {
            T(if (rec) "Merekam · ${fmtDur(Recorder.count)}" else "Rekam FPS", 17, TX, true, maxLines = 1)
            T(if (rec) "${Recorder.lastFps} FPS saat ini" else "Lalu buka game", 13, MUT, maxLines = 1)
        }
        Box(Modifier.size(44.dp)) {
            Box(Modifier.fillMaxSize().clip(CircleShape).background(Color(0xFF2B2F3A)).clickable { showList = true }, contentAlignment = Alignment.Center) {
                HistoryIcon(TX, Modifier.size(20.dp))
            }
            if (list.isNotEmpty()) Box(Modifier.align(Alignment.TopEnd).offset(6.dp, (-6).dp).defaultMinSize(20.dp, 20.dp)
                .background(PINK, CircleShape).padding(horizontal = 4.dp), contentAlignment = Alignment.Center) {
                T(if (list.size > 9) "9+" else "${list.size}", 11, Color.Black, true, maxLines = 1)
            }
        }
        Box(Modifier.clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(if (rec) listOf(Color(0xFFE5677A), PINK) else listOf(Color(0xFFF4A0C4), PINK)))
            .clickable { RecCtl.toggle(ctx) }.padding(horizontal = 20.dp, vertical = 12.dp)) {
            T(if (rec) "Berhenti" else "Mulai", 16, if (rec) Color.White else Color.Black, true, maxLines = 1)
        }
    }
    if (showList) TabDialog("Rekaman", if (list.isEmpty()) "Belum ada rekaman FPS" else "${list.size} rekaman FPS, ketuk untuk lihat laporan", { showList = false }) {
        if (list.isEmpty()) Text("Belum ada rekaman. Tekan Mulai, lalu buka game.", color = MUT, fontSize = 13.sp,
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), textAlign = TextAlign.Center)
        else list.forEach { r -> RecRow(r) { showList = false; Store.reportId = r.id } }
        Text("Rekaman juga bisa dimulai dan dihentikan lewat tombol di notifikasi, jadi tidak perlu keluar dari game.",
            color = MUT.copy(alpha = 0.85f), fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 8.dp, start = 4.dp, end = 4.dp))
    }
}

/** Kartu riwayat: ikon game, nama, tanggal, rata-rata FPS, grafik mini FPS, dan chip Min / 5% low / Maks. */
@Composable
fun RecRow(r: Session, onClick: () -> Unit) {
    val st = remember(r.id) { r.stats() }
    val ctx = LocalContext.current
    val icon = remember(r.pkg) { appIcon(ctx, r.pkg) }
    val whenTxt = remember(r.id) { SimpleDateFormat("d MMM · HH:mm", Locale.getDefault()).format(Date(r.id)) }
    val spark = remember(r.id) {
        val f = r.fps.filter { it > 0f }
        if (f.size <= 60) f else List(60) { i -> f[(i * (f.size - 1)) / 59] }
    }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(RowBg).clickable { onClick() }
        .padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) Image(icon.asImageBitmap(), null, Modifier.size(44.dp).clip(RoundedCornerShape(11.dp)))
            else Box(Modifier.size(44.dp).background(Color(0xFF262833), RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
                T(r.label.take(1).uppercase(), 18, Color.White, true)
            }
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                T(r.label, 16, Color.White, true, maxLines = 1)
                T(whenTxt + (if (r.res.isBlank()) "" else " · ${r.res}"), 12, MUT, maxLines = 1)
            }
            Column(Modifier.padding(start = 10.dp), horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.Bottom) {
                    T(f1(st.avg), 22, CYAN, true, maxLines = 1)
                    Text(" FPS", color = MUT, fontSize = 11.sp, modifier = Modifier.padding(bottom = 3.dp))
                }
                T(fmtDur(r.dur), 12, MUT, maxLines = 1)
            }
        }
        if (spark.size >= 2) Canvas(Modifier.fillMaxWidth().height(30.dp)) {
            var lo = spark.min(); var hi = spark.max()
            if (hi - lo < 4f) { val m = (hi + lo) / 2f; lo = m - 2f; hi = m + 2f }
            val path = Path()
            spark.forEachIndexed { i, v ->
                val x = size.width * i / (spark.size - 1)
                val y = size.height * (1f - (v - lo) / (hi - lo))
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, CYAN.copy(alpha = 0.9f), style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Min" to st.min, "5% low" to st.low5, "Maks" to st.max).forEach { (k, v) ->
                Row(Modifier.background(Color.White.copy(alpha = 0.06f), CircleShape).padding(horizontal = 10.dp, vertical = 4.dp)) {
                    Text("$k ", color = MUT, fontSize = 11.sp)
                    Text("%.0f".format(v), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/** Laporan satu rekaman: tampilan sama dengan PulseMonitor (ReportView di RecReport.kt). */
@Composable
fun ReportScreen(id: Long, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val sess by produceState<Session?>(null, id) { value = withContext(Dispatchers.IO) { Recorder.load(ctx, id) } }
    var deleted by remember { mutableStateOf(false) }
    val s = sess
    if (s == null) { Box(Modifier.fillMaxSize().background(BG), contentAlignment = Alignment.Center) { T("Memuat…", 14, MUT) }; return }
    ReportView(s,
        onBack = onBack,
        onShare = { ReportShare.share(ctx, s) },
        onSave = { ReportShare.save(ctx, s) },
        onCsv = { ReportShare.csv(ctx, s) },
        onDelete = { deleted = true; Recorder.delete(ctx, s.id); onBack() },
        onDesc = { text -> if (!deleted) Thread { Recorder.saveDesc(ctx, s, text) }.start() },
        wallpaper = Wallpaper.image, dim = Wallpaper.dim)
}
