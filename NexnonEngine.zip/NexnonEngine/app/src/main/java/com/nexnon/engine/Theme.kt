package com.nexnon.engine

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

val BG = Color(0xFF0F1117); val CARD = Color(0xFF181B25); val BD = Color(0xFF2A2E3B)
val TX = Color(0xFFEEF0F6); val MUT = Color(0xFF99A1B5); val AC = Color(0xFFFF7A2F)
val CYAN = Color(0xFF22D3EE); val PINK = Color(0xFFE58AA6); val VIOLET = Color(0xFF8B86EA)

@Composable
fun T(text: String, size: Int = 14, color: Color = TX, bold: Boolean = false, mod: Modifier = Modifier, maxLines: Int = Int.MAX_VALUE) =
    Text(text, color = color, fontSize = size.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        modifier = mod, maxLines = maxLines, overflow = TextOverflow.Ellipsis)

@Composable
fun Card2(mod: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val sh = RoundedCornerShape(20.dp)
    Column(mod.fillMaxWidth().background(CARD, sh).border(1.dp, BD, sh).padding(16.dp), content = content)
}

/** Ikon sederhana digambar manual (tanpa dependensi material-icons). 0 home, 1 petir, 2 daftar, 3 gerigi, 4 layer, 5 slider */
@Composable
fun Ico(kind: Int, color: Color, size: Dp = 24.dp) = Canvas(Modifier.size(size)) {
    val s = this.size.width / 24f
    val st = Stroke(1.8f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun line(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(color, Offset(x1 * s, y1 * s), Offset(x2 * s, y2 * s), 1.8f * s, StrokeCap.Round)
    when (kind) {
        0 -> drawPath(Path().apply { moveTo(4 * s, 11 * s); lineTo(12 * s, 4 * s); lineTo(20 * s, 11 * s); lineTo(20 * s, 20 * s); lineTo(4 * s, 20 * s); close() }, color, style = st)
        1 -> drawPath(Path().apply { moveTo(13 * s, 3 * s); lineTo(5 * s, 13 * s); lineTo(11 * s, 13 * s); lineTo(10 * s, 21 * s); lineTo(18 * s, 11 * s); lineTo(12 * s, 11 * s); close() }, color, style = st)
        2 -> listOf(7f, 12f, 17f).forEach { y -> line(8f, y, 20f, y); drawCircle(color, 1.3f * s, Offset(4 * s, y * s)) }
        3 -> {
            drawCircle(color, 3f * s, Offset(12 * s, 12 * s), style = st)
            for (a in 0 until 8) {
                val r = Math.toRadians(a * 45.0)
                line(12f + 6f * cos(r).toFloat(), 12f + 6f * sin(r).toFloat(), 12f + 9f * cos(r).toFloat(), 12f + 9f * sin(r).toFloat())
            }
        }
        4 -> {
            drawPath(Path().apply { moveTo(12 * s, 3 * s); lineTo(21 * s, 8 * s); lineTo(12 * s, 13 * s); lineTo(3 * s, 8 * s); close() }, color, style = st)
            drawPath(Path().apply { moveTo(3 * s, 13 * s); lineTo(12 * s, 18 * s); lineTo(21 * s, 13 * s) }, color, style = st)
        }
        else -> {
            listOf(7f, 12f, 17f).forEach { y -> line(4f, y, 20f, y) }
            drawCircle(color, 2.2f * s, Offset(15 * s, 7 * s)); drawCircle(color, 2.2f * s, Offset(9 * s, 12 * s)); drawCircle(color, 2.2f * s, Offset(14 * s, 17 * s))
        }
    }
}
