package com.nexnon.engine

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

val BG = Color(0xFF050507); val CARD = Color(0xFF0D0E12)
// Border kartu: transparan kalau pakai wallpaper, gelap solid kalau tidak
val BD: Color get() = if (Wallpaper.image != null) Color.Transparent else Color(0xFF1C1E26)
val TX = Color(0xFFEEF0F6); val AC = Color(0xFFFF7A2F)
// Teks sekunder: putih kalau pakai wallpaper (biar jelas), abu-abu kalau tidak
val MUT: Color get() = if (Wallpaper.image != null) Color.White else Color(0xFF99A1B5)
val CYAN = Color(0xFF22D3EE); val PINK = Color(0xFFE58AA6); val VIOLET = Color(0xFF8B86EA)

/** Kartu: kaca gelap 80% tembus (opasitas 20%) di semua halaman bila ada wallpaper, pekat bila tidak ada. */
val cardBg: Color get() = if (Wallpaper.image != null) Color(0xFF1E1F26).copy(alpha = 0.20f) else CARD
/** Teks sekunder: putih di atas wallpaper supaya terbaca. */
val subTx: Color get() = if (Wallpaper.image != null) Color.White else MUT

@Composable
fun AccSlider(value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit, onDone: () -> Unit) {
    Slider(value = value, onValueChange = onChange, valueRange = range, onValueChangeFinished = onDone,
        colors = SliderDefaults.colors(thumbColor = AC, activeTrackColor = AC, inactiveTrackColor = Color(0x22FFFFFF)))
}

/** Tombol seragam: terisi (aksi utama) atau garis tepi (aksi sekunder). */
@Composable
fun PillButton(text: String, filled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(modifier.clip(shape)
        .then(if (filled) Modifier.background(Color(0xFF6FA8FF)) else Modifier.border(1.dp, Color(0x33FFFFFF), shape))
        .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
        Text(text, color = if (filled) Color(0xFF0C0C0E) else Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Baris tautan: ikon, judul, keterangan di kanan, dan tanda buka-luar. */
@Composable
fun LinkRow(icon: @Composable () -> Unit, title: String, trailing: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onClick() }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(34.dp), contentAlignment = Alignment.Center) { icon() }
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).padding(start = 10.dp))
        if (trailing.isNotEmpty()) Text(trailing, color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(end = 8.dp))
        Text("↗", color = Color.White, fontSize = 20.sp)
    }
}

@Composable
fun GamepadIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width; val h = size.height; val st = Stroke(width = w * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    drawRoundRect(c, Offset(w * 0.04f, h * 0.22f), Size(w * 0.92f, h * 0.56f), CornerRadius(w * 0.24f), style = st)
    drawLine(c, Offset(w * 0.28f, h * 0.4f), Offset(w * 0.28f, h * 0.6f), st.width, StrokeCap.Round)
    drawLine(c, Offset(w * 0.18f, h * 0.5f), Offset(w * 0.38f, h * 0.5f), st.width, StrokeCap.Round)
    drawCircle(c, w * 0.05f, Offset(w * 0.66f, h * 0.46f))
    drawCircle(c, w * 0.05f, Offset(w * 0.78f, h * 0.56f))
}

@Composable
fun PersonIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width; val h = size.height; val st = Stroke(width = w * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    drawCircle(c, w * 0.2f, Offset(w * 0.5f, h * 0.3f), style = st)
    val p = Path().apply { moveTo(w * 0.14f, h * 0.9f); cubicTo(w * 0.14f, h * 0.55f, w * 0.86f, h * 0.55f, w * 0.86f, h * 0.9f); close() }
    drawPath(p, c, style = st)
}

@Composable
fun T(text: String, size: Int = 14, color: Color = TX, bold: Boolean = false, mod: Modifier = Modifier, maxLines: Int = Int.MAX_VALUE) =
    Text(text, color = color, fontSize = size.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        modifier = mod, maxLines = maxLines, overflow = TextOverflow.Ellipsis)

@Composable
fun Card2(mod: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val sh = RoundedCornerShape(20.dp)
    Column(mod.fillMaxWidth().background(cardBg, sh).border(1.dp, BD, sh).padding(16.dp), content = content)
}

/** Ikon sederhana digambar manual (tanpa dependensi material-icons). 0 home, 1 petir, 2 daftar, 3 gerigi, 4 layer, 5 slider, 6 perisai, 7 orang, 8 speedometer, 9 reset, 10 sampah, 11 sapu */
@Composable
fun Ico(kind: Int, color: Color, size: Dp = 24.dp) = Canvas(Modifier.size(size)) {
    val s = this.size.width / 24f
    val st = Stroke(1.8f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun line(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(color, Offset(x1 * s, y1 * s), Offset(x2 * s, y2 * s), 1.8f * s, StrokeCap.Round)
    when (kind) {
        0 -> drawPath(Path().apply { moveTo(4 * s, 11 * s); lineTo(12 * s, 4 * s); lineTo(20 * s, 11 * s); lineTo(20 * s, 20 * s); lineTo(4 * s, 20 * s); close() }, color, style = st)
        1 -> drawPath(Path().apply { moveTo(13 * s, 3 * s); lineTo(5 * s, 13 * s); lineTo(11 * s, 13 * s); lineTo(10 * s, 21 * s); lineTo(18 * s, 11 * s); lineTo(12 * s, 11 * s); close() }, color, style = st)
        2 -> listOf(7f, 12f, 17f).forEach { y -> line(8f, y, 20f, y); drawCircle(color, 1.3f * s, Offset(4 * s, y * s)) }
        3 -> {
            drawCircle(color, 3f * s, Offset(12 * s, 12 * s), style = st)
            for (a in 0 until 8) {
                val r = Math.toRadians(a * 45.0)
                line(12f + 6f * cos(r).toFloat(), 12f + 6f * sin(r).toFloat(), 12f + 9f * cos(r).toFloat(), 12f + 9f * sin(r).toFloat())
            }
        }
        6 -> drawPath(Path().apply { moveTo(12 * s, 2 * s); lineTo(21 * s, 5 * s); lineTo(21 * s, 12 * s); cubicTo(21 * s, 17 * s, 17 * s, 20.5f * s, 12 * s, 22 * s); cubicTo(7 * s, 20.5f * s, 3 * s, 17 * s, 3 * s, 12 * s); lineTo(3 * s, 5 * s); close() }, color)
        7 -> { drawCircle(color, 4.5f * s, Offset(12 * s, 8 * s), style = st); drawPath(Path().apply { moveTo(4 * s, 21 * s); cubicTo(4 * s, 14 * s, 20 * s, 14 * s, 20 * s, 21 * s); close() }, color, style = st) }
        8 -> { // speedometer
            drawArc(color, 160f, 220f, false, Offset(3 * s, 3 * s), Size(18 * s, 18 * s), style = st)
            line(12f, 13f, 16.5f, 8.5f); drawCircle(color, 1.4f * s, Offset(12 * s, 13 * s))
        }
        9 -> { // reset (panah melingkar)
            drawArc(color, -60f, 280f, false, Offset(4 * s, 4 * s), Size(16 * s, 16 * s), style = st)
            drawPath(Path().apply { moveTo(17.5f * s, 2.5f * s); lineTo(18.5f * s, 7.5f * s); lineTo(13.5f * s, 7f * s) }, color, style = st)
        }
        10 -> { // tempat sampah
            line(4f, 7f, 20f, 7f); line(9f, 4f, 15f, 4f)
            drawPath(Path().apply { moveTo(6 * s, 7 * s); lineTo(7 * s, 20 * s); lineTo(17 * s, 20 * s); lineTo(18 * s, 7 * s) }, color, style = st)
            line(10f, 11f, 10f, 16f); line(14f, 11f, 14f, 16f)
        }
        11 -> { // pembersih (sapu)
            line(14f, 3f, 9f, 11f)
            drawPath(Path().apply { moveTo(5 * s, 12 * s); lineTo(15 * s, 12 * s); lineTo(17 * s, 21 * s); lineTo(4 * s, 21 * s); close() }, color, style = st)
            line(9f, 16f, 9f, 21f); line(13f, 16f, 13f, 21f)
        }
        12 -> { // rasio layar / resolusi
            drawPath(Path().apply { moveTo(3 * s, 5 * s); lineTo(21 * s, 5 * s); lineTo(21 * s, 19 * s); lineTo(3 * s, 19 * s); close() }, color, style = st)
            line(7f, 11f, 7f, 15f); line(7f, 15f, 11f, 15f); line(17f, 13f, 17f, 9f); line(17f, 9f, 13f, 9f)
        }
        4 -> {
            drawPath(Path().apply { moveTo(12 * s, 3 * s); lineTo(21 * s, 8 * s); lineTo(12 * s, 13 * s); lineTo(3 * s, 8 * s); close() }, color, style = st)
            drawPath(Path().apply { moveTo(3 * s, 13 * s); lineTo(12 * s, 18 * s); lineTo(21 * s, 13 * s) }, color, style = st)
        }
        else -> {
            listOf(7f, 12f, 17f).forEach { y -> line(4f, y, 20f, y) }
            drawCircle(color, 2.2f * s, Offset(15 * s, 7 * s)); drawCircle(color, 2.2f * s, Offset(9 * s, 12 * s)); drawCircle(color, 2.2f * s, Offset(14 * s, 17 * s))
        }
    }
}
