package com.nexnon.engine

import rikka.shizuku.Shizuku

/** Eksekusi perintah shell lewat Shizuku (uid shell) atau Root (su). */
object Shell {
    private val rootOk: Boolean by lazy {
        runCatching { ProcessBuilder("su", "-c", "id").start().inputStream.bufferedReader().readText().contains("uid=0") }.getOrDefault(false)
    }
    fun shizukuReady() = runCatching { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == 0 }.getOrDefault(false)

    /** "Shizuku", "Root", atau "-" bila tidak ada akses. Mengikuti pilihan di Access. */
    fun mode(): String = when (Access.choice) {
        Access.ROOT -> if (Access.rootState == 2) "Root" else "-"
        Access.SHIZUKU -> if (shizukuReady()) "Shizuku" else "-"
        else -> if (shizukuReady()) "Shizuku" else if (rootOk) "Root" else "-"
    }

    private fun proc(cmd: String): Process? = when (mode()) {
        // newProcess private di Shizuku 13.x, dipanggil lewat refleksi (karena itu minify harus mati)
        "Shizuku" -> Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        "Root" -> ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        else -> null
    }

    fun exec(cmd: String): String {
        val p = proc(cmd) ?: return ""
        return runCatching { p.inputStream.bufferedReader().readText() }.getOrDefault("").also { p.destroy() }
    }

    /** Jalankan [cmd], kirim [stdin] bila ada. Mengembalikan (kode keluar, output gabungan stdout+stderr). */
    fun run(cmd: String, stdin: ByteArray? = null): Pair<Int, String> {
        val p = proc("($cmd) 2>&1") ?: return -1 to "Akses belum aktif"
        return try {
            if (stdin != null) p.outputStream.use { it.write(stdin) } else p.outputStream.close()
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor() to out.trim()
        } catch (e: Throwable) { -1 to (e.message ?: "Error") } finally { p.destroy() }
    }
}
