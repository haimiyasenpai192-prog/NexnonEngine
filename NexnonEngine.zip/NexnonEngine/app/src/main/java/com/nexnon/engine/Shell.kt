package com.nexnon.engine

import rikka.shizuku.Shizuku

/** Eksekusi perintah shell lewat Shizuku (uid shell) atau Root (su). */
object Shell {
    private val rootOk: Boolean by lazy {
        runCatching { ProcessBuilder("su", "-c", "id").start().inputStream.bufferedReader().readText().contains("uid=0") }.getOrDefault(false)
    }
    fun shizukuReady() = runCatching { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == 0 }.getOrDefault(false)

    /** "Shizuku", "Root", atau "-" bila tidak ada akses. Mengikuti pilihan di Access. */
    fun mode(): String = when (Access.choice) {
        Access.ROOT -> if (Access.rootState == 2) "Root" else "-"
        Access.SHIZUKU -> if (shizukuReady()) "Shizuku" else "-"
        else -> if (shizukuReady()) "Shizuku" else if (rootOk) "Root" else "-"
    }

    private fun proc(cmd: String): Process? = when (mode()) {
        // newProcess private di Shizuku 13.x, dipanggil lewat refleksi (karena itu minify harus mati)
        "Shizuku" -> Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        "Root" -> ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        else -> null
    }

    /** Proses jangka panjang (daemon FPS): stdout dibaca terus-menerus oleh pemanggil. */
    fun spawn(cmd: String): Process? = proc(cmd)

    private val inFlight = java.util.concurrent.atomic.AtomicInteger(0)

    /**
     * exec dengan batas waktu: perintah jalan di thread sendiri; lewat [ms] -> proses dimatikan dan hasilnya "" (bukan keluaran setengah jadi).
     * Maksimal 4 perintah menggantung sekaligus; selebihnya dilewati supaya tidak menumpuk (dumpsys bisa macet saat game berat).
     */
    fun execLimited(cmd: String, ms: Long): String {
        if (inFlight.get() >= 4) { AppLog.w("Shell", "dilewati: sudah 4 perintah menggantung"); return "" }
        val p = proc(cmd) ?: return ""
        inFlight.incrementAndGet()
        val sb = StringBuilder()
        val t = Thread {
            try { runCatching { p.inputStream.bufferedReader().forEachLine { sb.append(it).append('\n') } } }
            finally { inFlight.decrementAndGet() }
        }.apply { isDaemon = true; name = "shell-limited"; start() }
        t.join(ms)
        val timedOut = t.isAlive
        runCatching { p.destroy() }
        if (timedOut) { AppLog.w("Shell", "melebihi $ms ms, dilewati: ${cmd.take(60)}"); return "" }
        return sb.toString()
    }

    fun exec(cmd: String): String {
        val p = proc(cmd) ?: return ""
        return runCatching { p.inputStream.bufferedReader().readText() }.getOrDefault("").also { p.destroy() }
    }

    /** Jalankan [cmd], kirim [stdin] bila ada. Mengembalikan (kode keluar, output gabungan stdout+stderr). */
    fun run(cmd: String, stdin: ByteArray? = null): Pair<Int, String> {
        val p = proc("($cmd) 2>&1") ?: return -1 to "Akses belum aktif"
        return try {
            if (stdin != null) p.outputStream.use { it.write(stdin) } else p.outputStream.close()
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor() to out.trim()
        } catch (e: Throwable) { -1 to (e.message ?: "Error") } finally { p.destroy() }
    }
}
