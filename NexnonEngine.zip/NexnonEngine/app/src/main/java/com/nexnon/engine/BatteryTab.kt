package com.nexnon.engine

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// Tab Baterai: level besar + metrik langsung (arus, tegangan, daya, suhu) yang dibaca ulang tiap detik,
// pintu ke riwayat sesi baterai, dan ringkasan "Sedang berjalan" sejak dicabut dari charger.

private val BtInner: Color get() = Color(0xFF1E1F26).copy(alpha = 0.30f)
private val BtLabel = Color(0xFFA9ADBA)
private val BtGreen = Color(0xFF5BD68E)
private val BtYellow = Color(0xFFFFD866)
private val BtRed = Color(0xFFFF6B6B)
private val BtAmber = Color(0xFFE8B84A)
private val BtBlue = Color(0xFF6FA8FF)
private val BtPurple = Color(0xFFA78BFA)
private val BtMono = FontFamily.Monospace
private val BtShadow = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.6f), Offset(0f, 2f), 8f))

@Composable
fun BatteryScreen() {
    val ctx = LocalContext.current
    val lv by produceState<BatLive?>(null) {
        while (true) { value = withContext(Dispatchers.IO) { BatteryLive.read(ctx) }; delay(1000) }
    }
    val hl by produceState<BatHealth?>(null) {
        while (true) { value = withContext(Dispatchers.IO) { BatteryHealthReader.read(ctx) }; delay(30_000) }
    }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("BATERAI", color = Color.White, fontSize = 20.sp, fontFamily = BtMono, letterSpacing = 3.sp,
                    style = BtShadow, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = NAV_SPACE), contentAlignment = Alignment.BottomCenter) {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                BatHero(lv)
                BatLiveGrid(lv)
                BatHealthGrid(hl)
                BatHistoryCard()
                BatOngoingCard()
            }
        }
    }
}

/** Kartu level: ikon baterai terisi sesuai level (hijau, kuning <= 30%, merah <= 15%), persen besar, status, dan daya + suhu di kanan. */
@Composable
private fun BatHero(lv: BatLive?) {
    val pct = lv?.pct ?: -1
    val frac by animateFloatAsState(if (pct >= 0) pct / 100f else 0f, tween(500), label = "batFill")
    val col = when { pct in 0..15 -> BtRed; pct in 0..30 -> BtYellow; else -> BtGreen }
    Row(Modifier.fillMaxWidth().background(BtInner, RoundedCornerShape(24.dp)).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.padding(top = 8.dp)) {
            Box(Modifier.size(52.dp, 84.dp).border(3.dp, col, RoundedCornerShape(12.dp)).padding(3.dp), contentAlignment = Alignment.BottomCenter) {
                Box(Modifier.fillMaxWidth().fillMaxHeight(frac.coerceIn(0f, 1f)).background(col, RoundedCornerShape(7.dp)))
            }
            Box(Modifier.align(Alignment.TopCenter).offset(y = (-8).dp).size(16.dp, 5.dp).background(col, RoundedCornerShape(2.dp)))
        }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text("Level baterai", color = BtLabel, fontSize = 12.sp)
            Text(if (pct >= 0) "$pct%" else "-", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
            if (lv != null) {
                val dot = if (lv.charging) BtGreen else if (lv.full) BtBlue else BtAmber
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                    Box(Modifier.size(8.dp).background(dot, CircleShape))
                    Text(lv.statusText, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 6.dp))
                }
            }
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(if (lv != null && lv.watt >= 0f) "%.1f W".format(lv.watt) else "-", color = col, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(if (lv != null && lv.tempC >= 0f) "%.0f°C".format(lv.tempC) else "-", color = BtLabel, fontSize = 13.sp)
        }
    }
}

/** Empat metrik langsung. Tanda arus: + saat mengisi, - saat terpakai. Di bawahnya tertulis dari mana arus dibaca. */
@Composable
private fun BatLiveGrid(lv: BatLive?) {
    val sign = when { lv == null -> ""; lv.charging -> "+"; !lv.plugged -> "-"; else -> "" }
    val cur = if (lv != null && lv.mA >= 0f) "$sign%.0f mA".format(lv.mA) else "-"
    val vol = if (lv != null && lv.mV > 0f) "%.2f V".format(lv.mV / 1000f) else "-"
    val pwr = if (lv != null && lv.watt >= 0f) "%.2f W".format(lv.watt) else "-"
    val tmp = if (lv != null && lv.tempC >= 0f) "%.0f°C".format(lv.tempC) else "-"
    val src = when (lv?.src) { "sysfs" -> "file sistem"; "shell" -> "Shizuku/Root"; "api" -> "BatteryManager"; else -> "tidak terbaca" }
    @Composable fun Tile(label: String, value: String, tint: Color, mod: Modifier) =
        Column(mod.background(BtInner, RoundedCornerShape(20.dp)).padding(horizontal = 14.dp, vertical = 12.dp)) {
            Text(label, color = BtLabel, fontSize = 12.sp, maxLines = 1)
            Text(value, color = tint, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
        }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile("Arus", cur, Color.White, Modifier.weight(1f))
            Tile("Tegangan", vol, Color.White, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tile("Daya", pwr, BtGreen, Modifier.weight(1f))
            Tile("Suhu", tmp, BtAmber, Modifier.weight(1f))
        }
        Text("Langsung, diperbarui tiap detik · sumber arus: $src", color = BtLabel, fontSize = 11.sp, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 6.dp))
    }
}

/** Dua kotak: kesehatan (kapasitas penuh dibanding desain) dan siklus pengisian. "-" bila HP tidak menyediakan datanya. */
@Composable
private fun BatHealthGrid(h: BatHealth?) {
    val hp = if (h != null && h.hasHealth) "%.0f%%".format(h.pct) else "-"
    val hCol = when { h == null || !h.hasHealth -> Color.White; h.pct >= 80f -> BtGreen; h.pct >= 60f -> BtYellow; else -> BtRed }
    val hSub = when {
        h == null || !h.hasHealth -> "tidak terbaca"
        h.fullMah > 0f && h.designMah > 0f -> (if (h.estimated) "≈ " else "") + "%.0f / %.0f mAh".format(h.fullMah, h.designMah)
        else -> "dari sistem Android"
    }
    val cy = if (h != null && h.cycles >= 0) "${h.cycles}" else "-"
    val cSub = if (h != null && h.cycles >= 0) "siklus pengisian" else "tidak terbaca"
    @Composable fun Tile(label: String, value: String, sub: String, tint: Color, mod: Modifier) =
        Column(mod.background(BtInner, RoundedCornerShape(20.dp)).padding(horizontal = 14.dp, vertical = 12.dp)) {
            Text(label, color = BtLabel, fontSize = 12.sp, maxLines = 1)
            Text(value, color = tint, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
            Text(sub, color = BtLabel, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
        }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Tile("Kesehatan", hp, hSub, hCol, Modifier.weight(1f))
        Tile("Siklus", cy, cSub, Color.White, Modifier.weight(1f))
    }
}

/** Kartu pintu ke riwayat baterai (grafik level / daya / suhu dan pemakaian per aplikasi). */
@Composable
private fun BatHistoryCard() {
    val ctx = LocalContext.current
    val ver by BatteryHistory.version.collectAsState()
    val count by produceState(0, ver / 3) { value = withContext(Dispatchers.IO) { BatteryHistory.list(ctx).size } }
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(BtInner).clickable { Store.batPage = 0L }
        .padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Riwayat baterai", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(if (count == 0) "Terekam otomatis saat aplikasi dibuka" else "$count sesi · pemakaian per aplikasi",
                color = BtLabel, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text("›", color = BtLabel, fontSize = 26.sp)
    }
}

/** Kartu "Sedang berjalan": layar menyala/mati, terjaga, tidur lelap, dan baterai terpakai sejak dicabut dari charger. */
@Composable
private fun BatOngoingCard() {
    val og by produceState(BatteryStats.ongoing()) { while (true) { value = BatteryStats.ongoing(); delay(1000) } }
    val tile = Color(0x0DFFFFFF)
    @Composable fun Tile(label: String, value: String, mod: Modifier, icon: @Composable () -> Unit) {
        Column(mod.background(tile, RoundedCornerShape(18.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(22.dp), contentAlignment = Alignment.CenterStart) { icon() }
                Text(label, color = BtLabel, fontSize = 12.sp, maxLines = 1)
            }
            Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
    }
    Column(Modifier.fillMaxWidth().background(BtInner, RoundedCornerShape(24.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text("Sedang berjalan", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text("  ·  sejak dicabut", color = BtLabel, fontSize = 11.sp, modifier = Modifier.padding(bottom = 1.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile("Layar menyala", og.on, Modifier.weight(1f)) { SunIcon(BtAmber) }
            Tile("Layar mati", og.off, Modifier.weight(1f)) { MoonIcon(BtBlue) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile("Terjaga", og.awake, Modifier.weight(1f)) { EyeIcon(BtGreen) }
            Tile("Tidur lelap", og.deep, Modifier.weight(1f)) { Text("Zz", color = BtPurple, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
        }
        Row(Modifier.fillMaxWidth().background(tile, RoundedCornerShape(18.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(22.dp), contentAlignment = Alignment.CenterStart) { BatteryNavIcon(Color.White) }
            Text("Baterai terpakai", color = BtLabel, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text(og.used, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            if (og.mah.isNotEmpty()) Text("  ${og.mah}", color = Color.White, fontSize = 13.sp)
        }
    }
}
