package com.nexnon.engine

import android.content.Context
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.view.Display
import kotlin.math.max
import kotlin.math.min

/**
 * Resolusi untuk header laporan ("1080x2336"): ukuran layar asli (Display.getRealSize),
 * ditulis sisi pendek x sisi panjang. Tidak butuh Shizuku / Root. String kosong bila tidak terbaca.
 */
object Resolution {
    fun display(ctx: Context): String = runCatching {
        val d = ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val p = Point()
        @Suppress("DEPRECATION") d.getRealSize(p)
        if (p.x > 0 && p.y > 0) "${min(p.x, p.y)}x${max(p.x, p.y)}" else ""
    }.getOrDefault("")

    /**
     * Resolusi render game (mis. "908x1968"), seperti RedFox: ukuran buffer layer game di SurfaceFlinger,
     * bukan ukuran layar. Dibaca lewat `dumpsys SurfaceFlinger` (butuh Shizuku/Root). Bila tidak terbaca
     * (akses mati, layer game sudah hilang, format dump beda), jatuh ke [display] = ukuran layar asli.
     */
    fun game(ctx: Context, pkg: String): String {
        val fallback = display(ctx)
        if (pkg.isBlank() || Shell.mode() == "-") return fallback
        return runCatching {
            val txt = Shell.execLimited("dumpsys SurfaceFlinger", 6000L)
            val rxs = listOf(
                Regex("""activeBuffer=\[\s*(\d+)\s*x\s*(\d+)"""),
                Regex("""buffer(?:Size)?\s*[=:]\s*\[?\s*(\d+)\s*[x,]\s*(\d+)""", RegexOption.IGNORE_CASE),
                Regex("""bufferWidth\s*=\s*(\d+)\D+bufferHeight\s*=\s*(\d+)""", RegexOption.IGNORE_CASE)
            )
            val short = fallback.substringBefore('x').toIntOrNull() ?: 0
            var best: Pair<Int, Int>? = null
            var inBlock = false
            for (line in txt.lineSequence()) {
                val t = line.trimStart()
                // Baris judul layer: "+ BufferStateLayer (SurfaceView[pkg/..]@0#123)" atau "* Layer 0x.. (...)"
                if (t.startsWith("+ ") || t.startsWith("* ") || t.startsWith("Layer ")) inBlock = line.contains(pkg)
                if (!inBlock) continue
                for (rx in rxs) {
                    val m = rx.find(line) ?: continue
                    val a = m.groupValues[1].toIntOrNull() ?: continue; val b = m.groupValues[2].toIntOrNull() ?: continue
                    if (a <= 0 || b <= 0) continue
                    val w = min(a, b); val h = max(a, b)
                    if (short > 0 && w < short / 4) continue            // buang layer kecil (ikon, kursor)
                    if (best == null || w.toLong() * h > best.first.toLong() * best.second) best = w to h
                    break
                }
            }
            best?.let { "${it.first}x${it.second}" } ?: fallback
        }.getOrDefault(fallback)
    }
}
