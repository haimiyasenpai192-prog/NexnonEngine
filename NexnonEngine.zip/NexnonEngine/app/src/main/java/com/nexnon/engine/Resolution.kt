package com.nexnon.engine

import android.content.Context
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.view.Display
import kotlin.math.max
import kotlin.math.min

/**
 * Resolusi untuk header laporan ("1080x2336"): ukuran layar asli (Display.getRealSize),
 * ditulis sisi pendek x sisi panjang. Tidak butuh Shizuku / Root. String kosong bila tidak terbaca.
 */
object Resolution {
    fun display(ctx: Context): String = runCatching {
        val d = ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val p = Point()
        @Suppress("DEPRECATION") d.getRealSize(p)
        if (p.x > 0 && p.y > 0) "${min(p.x, p.y)}x${max(p.x, p.y)}" else ""
    }.getOrDefault("")

    private val cache = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val probing = java.util.concurrent.atomic.AtomicBoolean(false)
    private val failLogged = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    /** Hasil baca resolusi render yang sudah berhasil untuk [pkg] ("" bila belum ada). */
    fun cached(pkg: String): String = cache[pkg].orEmpty()

    /**
     * Dipanggil Sampler selama rekaman (saat game masih di depan): baca resolusi render game di thread latar
     * dan simpan hasilnya. Baru dibaca di akhir rekaman terlalu telat: layer game sudah hilang dan hasilnya jatuh ke ukuran layar.
     */
    fun probeAsync(ctx: Context, pkg: String) {
        if (pkg.isBlank() || cache.containsKey(pkg) || Shell.mode() == "-") return
        if (!probing.compareAndSet(false, true)) return
        val app = ctx.applicationContext
        Thread {
            try { probe(app, pkg) } finally { probing.set(false) }
        }.apply { isDaemon = true; name = "res-probe"; start() }
    }

    /** Ukuran buffer layer game dari `dumpsys SurfaceFlinger`, atau null bila tidak ketemu. Hasil yang ketemu disimpan di cache. */
    private fun probe(ctx: Context, pkg: String): String? = runCatching {
        val fallback = display(ctx)
        val txt = Shell.execLimited("dumpsys SurfaceFlinger", 6000L)
        if (txt.isBlank()) return@runCatching null
        val rxs = listOf(
            Regex("""activeBuffer=\[\s*(\d+)\s*x\s*(\d+)"""),
            Regex("""buffer(?:Size)?\s*[=:]\s*\[?\s*(\d+)\s*[x,]\s*(\d+)""", RegexOption.IGNORE_CASE),
            Regex("""bufferWidth\s*=\s*(\d+)\D+bufferHeight\s*=\s*(\d+)""", RegexOption.IGNORE_CASE)
        )
        val titleRx = Regex("""^[+*]?\s*(\w*Layer\b|Layer\b)""")
        val short = fallback.substringBefore('x').toIntOrNull() ?: 0
        // Kandidat: (judul layer, lebar, tinggi). Layer "SurfaceView[...]" = buffer yang digambar game (bisa lebih kecil dari layar).
        val cands = ArrayList<Triple<String, Int, Int>>()
        var title = ""; var inBlock = false
        for (line in txt.lineSequence()) {
            val t = line.trimStart()
            if (t.startsWith("+ ") || t.startsWith("* ") || titleRx.containsMatchIn(t)) { title = t; inBlock = line.contains(pkg) }
            if (!inBlock) continue
            for (rx in rxs) {
                val m = rx.find(line) ?: continue
                val a = m.groupValues[1].toIntOrNull() ?: continue; val b = m.groupValues[2].toIntOrNull() ?: continue
                if (a <= 0 || b <= 0) continue
                val w = min(a, b); val h = max(a, b)
                if (short > 0 && w < short / 4) continue            // buang layer kecil (ikon, kursor)
                cands.add(Triple(title, w, h))
                break
            }
        }
        // Utamakan layer SurfaceView (render game); layer jendela induk biasanya seukuran layar dan menutupi hasil yang benar
        val sv = cands.filter { it.first.contains("SurfaceView", true) && !it.first.contains("Background for", true) }
        val best = (sv.ifEmpty { cands }).maxByOrNull { it.second.toLong() * it.third }
        if (best == null && failLogged.add(pkg)) {
            val hint = txt.lineSequence().filter { it.contains(pkg) }.take(6).joinToString(" | ") { it.trim().take(110) }
            AppLog.w("Res", "resolusi game tidak terbaca ($pkg), pakai ukuran layar. Baris layer: ${hint.ifEmpty { "tidak ada baris berisi nama paket" }}")
        }
        best?.let { "${it.second}x${it.third}".also { r -> cache[pkg] = r; AppLog.i("Res", "resolusi render $pkg = $r (${it.first.take(80)})") } }
    }.getOrNull()

    /**
     * Resolusi render game (mis. "908x1968"): ukuran buffer layer game di SurfaceFlinger, bukan ukuran layar.
     * Memakai hasil yang sudah dibaca saat rekaman ([probeAsync]); bila belum ada, baca sekarang. Butuh Shizuku/Root.
     * Bila tidak terbaca (akses mati, layer game sudah hilang, format dump beda), jatuh ke [display] = ukuran layar asli.
     */
    fun game(ctx: Context, pkg: String): String {
        if (pkg.isBlank()) return display(ctx)
        cache[pkg]?.let { return it }
        if (Shell.mode() == "-") return display(ctx)
        return probe(ctx, pkg) ?: display(ctx)
    }
}
