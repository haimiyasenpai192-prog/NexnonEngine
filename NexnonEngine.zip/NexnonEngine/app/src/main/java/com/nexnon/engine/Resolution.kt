package com.nexnon.engine

import android.content.Context
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.view.Display
import kotlin.math.max
import kotlin.math.min

/**
 * Resolusi untuk header laporan ("1080x2336"): ukuran layar asli (Display.getRealSize),
 * ditulis sisi pendek x sisi panjang. Tidak butuh Shizuku / Root. String kosong bila tidak terbaca.
 */
object Resolution {
    fun display(ctx: Context): String = runCatching {
        val d = ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val p = Point()
        @Suppress("DEPRECATION") d.getRealSize(p)
        if (p.x > 0 && p.y > 0) "${min(p.x, p.y)}x${max(p.x, p.y)}" else ""
    }.getOrDefault("")
}
