package com.nexnon.engine

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.telephony.TelephonyManager
import java.net.Inet4Address

// Data untuk tab Statistik. Disalin dari DeviceExtras dan Sampler.readMem milik Pulse Monitor (cara baca dan satuannya sama),
// semuanya dibaca tanpa Shizuku/Root kecuali /proc/swaps yang punya cadangan lewat shell.

/** Rincian memori dalam GB untuk kartu Memori; swapTotal = 0 bila HP tidak punya swap. */
data class MemInfo(
    val marketGb: Int = 0, val ramTotal: Float = 0f, val ramUsed: Float = 0f, val ramFree: Float = 0f,
    val swapTotal: Float = 0f, val swapUsed: Float = 0f, val swapFree: Float = 0f, val zram: Boolean = false,
    val extraTotal: Float = 0f, val extraUsed: Float = 0f   // swap non-zram (mis. berkas swap "RAM tambahan") bila zram juga ada
) {
    val ramPct get() = if (ramTotal > 0f) Math.round(ramUsed * 100f / ramTotal).coerceIn(0, 100) else -1
}

/** Baterai: persen, suhu (°C), status teks, dan perkiraan sisa waktu ("-" bila tidak terbaca). */
data class BatExtra(val pct: Int = -1, val tempC: Float = -1f, val state: String = "-", val remain: String = "-")
/** Jaringan: jenis koneksi, kecepatan tautan Wi-Fi (Mbps), kekuatan sinyal (persen) dan dBm. -1 = tidak ada. */
data class NetExtra(val type: String = "-", val mbps: Int = -1, val sigPct: Int = -1, val dbm: Int = 0)
/** Rincian jaringan untuk dialog di kartu Jaringan: Wi-Fi, seluler, dan SIM. Teks kosong atau -1 = tidak tersedia. */
data class NetDetail(
    val wifiOn: Boolean = false, val wifiIp: String = "", val wifiMbps: Int = -1, val wifiDbm: Int = 0, val wifiPct: Int = -1, val wifiBand: String = "",
    val mobileOn: Boolean = false, val phoneType: String = "-",
    val simState: String = "-", val simReady: Boolean = false, val operator: String = "-"
)
/** Rincian baterai untuk dialog di kartu Baterai. Teks "-" atau angka -1 = tidak terbaca. */
data class BatDetail(
    val pct: Int = -1, val tempC: Float = -1f, val status: String = "-", val charging: Boolean = false,
    val tech: String = "-", val health: String = "-", val healthGood: Boolean = true,
    val volt: Float = -1f, val designMah: Int = -1, val remainMah: Int = -1, val currentMa: Int = Int.MIN_VALUE, val cycles: Int = -1
)
/** Rincian RAM (dari /proc/meminfo) dalam GB desimal. -1 = tidak terbaca. */
data class MemDetail(val totalGb: Float = -1f, val usedGb: Float = -1f, val availGb: Float = -1f, val freeGb: Float = -1f, val cacheGb: Float = -1f,
                     val swapTotalGb: Float = 0f, val swapUsedGb: Float = 0f)
/** Rincian penyimpanan: partisi data (isi pengguna) dan partisi sistem, dalam GB desimal. */
data class StoDetail(val totalGb: Float = -1f, val usedGb: Float = -1f, val freeGb: Float = -1f, val sysTotalGb: Float = -1f, val sysUsedGb: Float = -1f)
/** Ukuran dalam GB desimal (1 GB = 1 miliar byte). */
data class SizeExtra(val usedGb: Float = -1f, val totalGb: Float = -1f) {
    val pct get() = if (totalGb > 0f && usedGb >= 0f) (usedGb * 100f / totalGb).toInt().coerceIn(0, 100) else -1
}
data class Extras(val bat: BatExtra = BatExtra(), val net: NetExtra = NetExtra(), val ram: SizeExtra = SizeExtra(), val storage: SizeExtra = SizeExtra())

object DeviceExtras {
    private fun fmt(ms: Long): String {
        val m = ms / 60_000
        return "%dj %dm".format(m / 60, m % 60)
    }

    fun read(c: Context): Extras = Extras(battery(c), network(c), ram(c), storage())

    private fun readProc(path: String): String = runCatching { java.io.File(path).readText() }.getOrDefault("")

    /**
     * Baca RAM dan swap. Satuan GB desimal (1 GB = 10^9 byte, seperti DevCheck); /proc/meminfo dalam kB (1024 byte).
     * RAM terpakai = MemTotal - MemAvailable. ZRAM dihitung dari /proc/swaps (hanya perangkat zram) supaya swap lain
     * (berkas swap "RAM tambahan") tidak ikut tercampur ke angka ZRAM; bila /proc/swaps tak terbaca, pakai SwapTotal/SwapFree.
     * Null bila /proc/meminfo tidak terbaca. Panggil dari thread latar.
     */
    fun memInfo(): MemInfo? {
        val meminfo = readProc("/proc/meminfo")
        if (meminfo.isBlank()) return null
        var swaps = readProc("/proc/swaps")
        // Sebagian HP melarang aplikasi membaca /proc/swaps; lewat shell (Shizuku/Root) tetap bisa
        if (swaps.isBlank() && Shell.mode() != "-") swaps = runCatching { Shell.exec("cat /proc/swaps 2>/dev/null") }.getOrDefault("")
        val zramHint = runCatching { java.io.File("/sys/block/zram0").exists() }.getOrDefault(false)
        return parseMem(meminfo, swaps, zramHint)
    }

    private fun parseMem(meminfo: String, swaps: String, zramHint: Boolean): MemInfo? {
        val gb = 1024f / 1_000_000_000f
        fun kb(n: String) = Regex("(?m)^$n:\\s+(\\d+)").find(meminfo)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        val tot = kb("MemTotal"); val av = kb("MemAvailable")
        if (tot <= 0) return null
        var zT = 0L; var zU = 0L; var oT = 0L; var oU = 0L; var any = false
        for (l in swaps.lineSequence()) {
            val f = l.trim().split(Regex("\\s+"))
            if (f.size < 4 || f[0] == "Filename") continue
            val size = f[2].toLongOrNull() ?: continue; val used = f[3].toLongOrNull() ?: continue
            any = true
            if (f[0].contains("zram", ignoreCase = true)) { zT += size; zU += used } else { oT += size; oU += used }
        }
        var zram = zT > 0
        val swT: Long; val swU: Long; val exT: Long; val exU: Long
        if (any) { if (zram) { swT = zT; swU = zU; exT = oT; exU = oU } else { swT = oT; swU = oU; exT = 0; exU = 0 } }
        else { swT = kb("SwapTotal"); swU = (swT - kb("SwapFree")).coerceAtLeast(0L); exT = 0; exU = 0; zram = swT > 0 && zramHint }
        // Ukuran RAM "di kotak" = ukuran umum terdekat di atas MemTotal (kernel menyisihkan sebagian)
        val totGb = tot / 1048576f
        val market = listOf(2, 3, 4, 6, 8, 10, 12, 16, 18, 20, 24, 32).firstOrNull { it >= totGb - 0.01f } ?: Math.ceil(totGb.toDouble()).toInt()
        return MemInfo(market, tot * gb, (tot - av).coerceAtLeast(0L) * gb, av * gb, swT * gb, swU * gb, (swT - swU).coerceAtLeast(0L) * gb, zram, exT * gb, exU * gb)
    }

    /** Rincian RAM dari /proc/meminfo: total, terpakai, tersedia, bebas, cache, dan swap/ZRAM. */
    fun memDetail(): MemDetail = runCatching {
        val m = HashMap<String, Long>()
        java.io.File("/proc/meminfo").forEachLine { line ->
            val p = line.split(Regex("\\s+"))
            if (p.size >= 2) p[0].removeSuffix(":").let { k -> p[1].toLongOrNull()?.let { m[k] = it } }
        }
        fun gb(k: String) = (m[k] ?: 0L) * 1024f / 1e9f
        val total = gb("MemTotal"); val avail = gb("MemAvailable")
        if (total <= 0f) return MemDetail()
        MemDetail(total, (total - avail).coerceAtLeast(0f), avail, gb("MemFree"), gb("Cached") + gb("Buffers"),
            gb("SwapTotal"), (gb("SwapTotal") - gb("SwapFree")).coerceAtLeast(0f))
    }.getOrDefault(MemDetail())

    /** Rincian penyimpanan: partisi data dan partisi sistem. */
    fun stoDetail(): StoDetail = runCatching {
        fun fs(path: String): Pair<Float, Float> {
            val sf = StatFs(path)
            val total = sf.blockCountLong * sf.blockSizeLong
            val free = sf.availableBlocksLong * sf.blockSizeLong
            return total / 1e9f to (total - free) / 1e9f
        }
        val (dt, du) = fs(Environment.getDataDirectory().path)
        val sys = runCatching { fs(Environment.getRootDirectory().path) }.getOrDefault(-1f to -1f)
        StoDetail(dt, du, (dt - du).coerceAtLeast(0f), sys.first, sys.second)
    }.getOrDefault(StoDetail())

    /** Rincian baterai: level, suhu, status, teknologi, kondisi, tegangan, kapasitas desain, muatan tersisa, arus, dan siklus. Tanpa izin tambahan. */
    @Suppress("PrivateApi", "DiscouragedPrivateApi")
    fun batDetail(c: Context): BatDetail = runCatching {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return BatDetail()
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val tRaw = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val charging = plugged && st == BatteryManager.BATTERY_STATUS_CHARGING
        val status = when {
            charging -> "Mengisi"
            plugged && st == BatteryManager.BATTERY_STATUS_FULL -> "Penuh"
            else -> "Tidak mengisi"
        }
        val hl = i.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
        val health = when (hl) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Baik"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Terlalu panas"
            BatteryManager.BATTERY_HEALTH_COLD -> "Terlalu dingin"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Rusak"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Tegangan berlebih"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Gagal"
            else -> "Tidak diketahui"
        }
        val mv = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
        val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        // Kapasitas desain dari profil daya sistem (tidak ada API publik); gagal dibaca -> -1
        val design = runCatching {
            val cls = Class.forName("com.android.internal.os.PowerProfile")
            val pp = cls.getConstructor(Context::class.java).newInstance(c)
            (cls.getMethod("getBatteryCapacity").invoke(pp) as Double).toInt().takeIf { it > 0 } ?: -1
        }.getOrDefault(-1)
        val cnt = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER).toLong()
        val remain = if (cnt > 0) (cnt / 1000).toInt() else -1
        val cur = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW).toLong()
        // Satuan arus beda-beda antar HP (µA atau mA), sama seperti perkiraan sisa waktu
        val curMa = if (cur == 0L || cur == Long.MIN_VALUE || cur == Int.MIN_VALUE.toLong()) Int.MIN_VALUE
            else if (Math.abs(cur) < 20_000) cur.toInt() else (cur / 1000).toInt()
        val cyc = if (Build.VERSION.SDK_INT >= 34) i.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1) else -1
        BatDetail(pct, if (tRaw != Int.MIN_VALUE) tRaw / 10f else -1f, status, charging,
            i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY)?.takeIf { it.isNotBlank() } ?: "-",
            health, hl == BatteryManager.BATTERY_HEALTH_GOOD, if (mv > 0) mv / 1000f else -1f, design, remain, curMa, cyc.takeIf { it > 0 } ?: -1)
    }.getOrDefault(BatDetail())

    /** Rincian Wi-Fi, seluler, dan SIM. Tidak butuh izin tambahan (nama Wi-Fi/SSID sengaja tidak dibaca karena butuh izin lokasi). */
    @Suppress("DEPRECATION")
    fun netDetail(c: Context): NetDetail = runCatching {
        val cm = c.getSystemService(ConnectivityManager::class.java)
        var wifiNet: android.net.Network? = null
        var mobileOn = false
        for (n in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(n) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) && wifiNet == null) wifiNet = n
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) mobileOn = true
        }
        var ip = ""; var mbps = -1; var dbm = 0; var pct = -1; var band = ""
        if (wifiNet != null) {
            ip = cm.getLinkProperties(wifiNet)?.linkAddresses?.map { it.address }?.firstOrNull { it is Inet4Address }?.hostAddress.orEmpty()
            val wi = c.applicationContext.getSystemService(Context.WIFI_SERVICE).let { it as WifiManager }.connectionInfo
            mbps = wi.linkSpeed.takeIf { it > 0 } ?: -1
            dbm = wi.rssi
            pct = ((dbm + 100) * 2).coerceIn(0, 100)
            val f = wi.frequency
            band = when { f in 2400..2500 -> "2,4 GHz"; f in 4900..5900 -> "5 GHz"; f >= 5925 -> "6 GHz"; else -> "" }
        }
        val tm = c.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
        val phone = when (tm?.phoneType) {
            TelephonyManager.PHONE_TYPE_GSM -> "GSM"
            TelephonyManager.PHONE_TYPE_CDMA -> "CDMA"
            TelephonyManager.PHONE_TYPE_SIP -> "SIP"
            else -> "Tidak ada"
        }
        val st = tm?.simState ?: TelephonyManager.SIM_STATE_UNKNOWN
        val stTxt = when (st) {
            TelephonyManager.SIM_STATE_READY -> "Siap"
            TelephonyManager.SIM_STATE_ABSENT -> "Tidak ada SIM"
            TelephonyManager.SIM_STATE_PIN_REQUIRED -> "Butuh PIN"
            TelephonyManager.SIM_STATE_PUK_REQUIRED -> "Butuh PUK"
            TelephonyManager.SIM_STATE_NETWORK_LOCKED -> "Terkunci jaringan"
            else -> "Tidak diketahui"
        }
        val op = (tm?.simOperatorName?.takeIf { it.isNotBlank() } ?: tm?.networkOperatorName?.takeIf { it.isNotBlank() }) ?: "-"
        NetDetail(wifiNet != null, ip, mbps, dbm, pct, band, mobileOn, phone, stTxt, st == TelephonyManager.SIM_STATE_READY, op.uppercase())
    }.getOrDefault(NetDetail())

    private fun battery(c: Context): BatExtra = runCatching {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return BatExtra()
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val tRaw = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val temp = if (tRaw != Int.MIN_VALUE) tRaw / 10f else -1f
        val state = when {
            plugged && st == BatteryManager.BATTERY_STATUS_CHARGING -> "Mengisi"
            plugged && st == BatteryManager.BATTERY_STATUS_FULL -> "Penuh"
            else -> "Tidak mengisi"
        }
        val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        var remain = "-"
        if (plugged && st == BatteryManager.BATTERY_STATUS_CHARGING) {
            val t = if (Build.VERSION.SDK_INT >= 28) bm.computeChargeTimeRemaining() else -1L
            if (t > 0) remain = "Penuh dalam ${fmt(t)}"
        } else if (!plugged) {
            // Perkiraan kasar: muatan tersisa dibagi arus saat ini. Satuan arus beda-beda antar HP (µA atau mA).
            val cur = Math.abs(bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW).toLong())
            val cnt = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER).toLong()
            if (cur > 0 && cnt > 0) {
                val ua = if (cur < 20_000) cur * 1000 else cur
                val ms = (cnt.toDouble() / ua * 3_600_000.0).toLong()
                if (ms in 60_000..(99L * 3_600_000)) remain = "Sisa ${fmt(ms)}"
            }
        }
        BatExtra(pct, temp, state, remain)
    }.getOrDefault(BatExtra())

    @Suppress("DEPRECATION")
    private fun network(c: Context): NetExtra = runCatching {
        val cm = c.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return NetExtra("Tidak ada koneksi")
        when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                val wi = c.applicationContext.getSystemService(Context.WIFI_SERVICE).let { it as WifiManager }.connectionInfo
                val rssi = wi.rssi
                NetExtra("Wi-Fi", wi.linkSpeed.takeIf { it > 0 } ?: -1, ((rssi + 100) * 2).coerceIn(0, 100), rssi)
            }
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetExtra("Data seluler")
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetExtra("Ethernet")
            else -> NetExtra("Terhubung")
        }
    }.getOrDefault(NetExtra())

    private fun ram(c: Context): SizeExtra = runCatching {
        val mi = ActivityManager.MemoryInfo()
        c.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        SizeExtra((mi.totalMem - mi.availMem) / 1e9f, mi.totalMem / 1e9f)
    }.getOrDefault(SizeExtra())

    private fun storage(): SizeExtra = runCatching {
        val sf = StatFs(Environment.getDataDirectory().path)
        val total = sf.blockCountLong * sf.blockSizeLong
        val free = sf.availableBlocksLong * sf.blockSizeLong
        SizeExtra((total - free) / 1e9f, total / 1e9f)
    }.getOrDefault(SizeExtra())
}

fun deg(v: Float) = if (v >= 0) "%.0f°".format(v) else "-"
