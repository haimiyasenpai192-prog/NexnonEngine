package com.nexnon.engine

import android.Manifest
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.os.SystemClock
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import androidx.core.animation.doOnEnd
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private val permL = Shizuku.OnRequestPermissionResultListener { _, r -> Access.onPermissionResult(r == PackageManager.PERMISSION_GRANTED) }
    private val bindL = Shizuku.OnBinderReceivedListener { Access.refresh() }
    private val deadL = Shizuku.OnBinderDeadListener { Access.refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Layar splash: logo N di tengah latar gelap, ditahan sebentar lalu logo membesar sambil memudar (ikut Pulse Monitor)
        val splash = installSplashScreen()
        val t0 = SystemClock.uptimeMillis()
        splash.setKeepOnScreenCondition { SystemClock.uptimeMillis() - t0 < 600 }
        splash.setOnExitAnimationListener { provider ->
            // Di sebagian HP (HyperOS/MIUI) tampilan splash dari sistem tidak punya iconView -> null; jangan sampai crash
            val icon: View? = runCatching { provider.iconView }.getOrNull()
            val root = provider.view
            runCatching {
                val bgOut = ObjectAnimator.ofFloat(root, View.ALPHA, 1f, 0f).apply {
                    duration = 280; interpolator = DecelerateInterpolator()
                }
                val seq = AnimatorSet()
                if (icon != null) {
                    val logoOut = AnimatorSet().apply {
                        playTogether(
                            ObjectAnimator.ofFloat(icon, View.SCALE_X, 1f, 1.25f),
                            ObjectAnimator.ofFloat(icon, View.SCALE_Y, 1f, 1.25f),
                            ObjectAnimator.ofFloat(icon, View.ALPHA, 1f, 0f)
                        )
                        duration = 260; interpolator = AccelerateInterpolator()
                    }
                    seq.playSequentially(logoOut, bgOut)
                } else {
                    // Tanpa iconView: seluruh layar splash membesar tipis sambil memudar
                    val zoom = AnimatorSet().apply {
                        playTogether(
                            ObjectAnimator.ofFloat(root, View.SCALE_X, 1f, 1.04f),
                            ObjectAnimator.ofFloat(root, View.SCALE_Y, 1f, 1.04f)
                        )
                        duration = 280; interpolator = DecelerateInterpolator()
                    }
                    seq.playTogether(zoom, bgOut)
                }
                seq.doOnEnd { runCatching { provider.remove() } }
                seq.start()
            }.onFailure { runCatching { provider.remove() } }
        }
        super.onCreate(savedInstanceState)
        // Layar penuh: bilah status transparan, hero Beranda menjangkau sampai belakang jam
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        AppLog.init(this)
        CrashLog.install(application)
        AppLog.i("App", "proses dimulai")
        Access.init(this)
        Wallpaper.init(this)
        MonitorPrefs.load(this)
        OverlayPrefs.load(this)
        Gamebar.load(this)
        BatteryStats.init(this)
        // Android 13+: notifikasi butuh izin. Tanpa izin, notifikasi pantauan tidak tampil (layanan tetap jalan).
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9)
        Shizuku.addRequestPermissionResultListener(permL)
        Shizuku.addBinderReceivedListenerSticky(bindL)
        Shizuku.addBinderDeadListener(deadL)
        setContent { MaterialTheme(colorScheme = darkColorScheme(background = BG, surface = BG, primary = AC)) { App() } }
    }

    @Volatile private var batLoop = false
    private var batThread: Thread? = null

    /** Riwayat baterai terekam selama aplikasi terbuka, tanpa perlu notifikasi. Sesi yang sama dilanjutkan layanan bila aktif. */
    private fun startBatteryRecording() {
        if (batLoop) return
        batLoop = true
        AppLog.i("Baterai", "perekaman dimulai (aplikasi terbuka)")
        batThread = Thread {
            runCatching { BatteryStats.init(applicationContext) }
            while (batLoop) {
                runCatching { BatteryStats.tick() }
                try { Thread.sleep(10_000L) } catch (e: InterruptedException) { break }
            }
        }.apply { name = "bat-record"; isDaemon = true; start() }
    }

    override fun onStart() { super.onStart(); startBatteryRecording() }
    override fun onStop() {
        if (batLoop) AppLog.i("Baterai", "perekaman berhenti (aplikasi tertutup)")
        batLoop = false; batThread?.interrupt(); batThread = null
        super.onStop()
    }

    override fun onResume() { super.onResume(); FpsMeter.start(); RecService.ensureRunning(this); OverlayService.sync(this); Gamebar.sync(this) }
    override fun onPause() { FpsMeter.stop(); super.onPause() }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permL)
        Shizuku.removeBinderReceivedListener(bindL)
        Shizuku.removeBinderDeadListener(deadL)
        super.onDestroy()
    }
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    BackHandler(enabled = tab == 2 && Store.game != null) { Store.game = null }
    BackHandler(enabled = Store.batPage != null) { val bp = Store.batPage; Store.batPage = if (bp != null && bp > 0L) 0L else null }
    BackHandler(enabled = Store.health) { Store.health = false }
    BackHandler(enabled = Store.reportId != null) { Store.reportId = null }
    // Laporan Rekam FPS: layar penuh sampai belakang jam & bilah navigasi (inset diurus di dalam ReportScreen)
    Store.reportId?.let { id -> Box(Modifier.fillMaxSize().background(BG)) { ReportScreen(id, onBack = { Store.reportId = null }) }; return }
    // Riwayat baterai: daftar sesi, lalu detail sesi (halaman sendiri, menangani wallpaper dan inset)
    Store.batPage?.let { bp ->
        if (bp == 0L) BatteryListScreen(onBack = { Store.batPage = null }, onOpen = { Store.batPage = it }, wallpaper = Wallpaper.image, dim = Wallpaper.dim)
        else BatteryDetailScreen(bp, onBack = { Store.batPage = 0L }, onDeleted = { Store.batPage = 0L }, wallpaper = Wallpaper.image, dim = Wallpaper.dim)
        return
    }
    if (Store.health) { Box(Modifier.fillMaxSize().background(BG).statusBarsPadding().navigationBarsPadding()) { HealthScreen(onBack = { Store.health = false }) }; return }
    Box(Modifier.fillMaxSize().background(BG)) {
        // Tab Statistik (gaya Pulse Monitor): tanpa wallpaper, latar gradien biru tua ke gelap supaya kotak kaca tembus terlihat
        if (tab == 3 && Wallpaper.image == null) Box(Modifier.fillMaxSize().background(
            androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color(0xFF0B0E19), Color(0xFF050507)))))
        Wallpaper.image?.let { bmp ->
            androidx.compose.foundation.Image(remember(bmp) { bmp.asImageBitmap() }, null, Modifier.fillMaxSize(),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop, filterQuality = androidx.compose.ui.graphics.FilterQuality.High)
            Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.verticalGradient(
                listOf(BG.copy(alpha = Wallpaper.dim * 0.12f), BG.copy(alpha = Wallpaper.dim * 0.8f)))))
        }
        // Layar penuh: isi halaman memenuhi seluruh layar dan bergulir di BELAKANG bilah navigasi yang melayang
        Box(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxSize()) {
                // Pindah tab: halaman lama bergeser keluar dan yang baru masuk dari arah tab (kanan bila tab lebih ke kanan), sambil memudar (gaya Pulse Monitor)
                androidx.compose.animation.AnimatedContent(targetState = tab, label = "tab", transitionSpec = {
                    val dir = if (targetState > initialState) 1 else -1
                    (androidx.compose.animation.slideInHorizontally(androidx.compose.animation.core.tween(260)) { it / 4 * dir } +
                        androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(260))) togetherWith
                        (androidx.compose.animation.slideOutHorizontally(androidx.compose.animation.core.tween(200)) { -it / 4 * dir } +
                            androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(160))) using
                        androidx.compose.animation.SizeTransform(clip = true)
                }) { t ->
                    // Beranda mengurus sendiri area bilah status (hero sampai ke atas); tab lain diberi jarak
                    Box(if (t == 0) Modifier else Modifier.statusBarsPadding()) { when (t) {
                        0 -> HomeScreen()
                        1 -> BatteryScreen()
                        2 -> {
                            val g = PRESETS.firstOrNull { it.key == Store.game }
                            if (g == null) ConfigList() else if (g.kind == 1) WuWaDetail(g) else GameDetail(g)
                        }
                        3 -> StatsScreen()
                        else -> SettingsScreen()
                    } }
                }
            }
            // Pudar gelap di bawah bilah supaya isi yang lewat di belakangnya tidak mengganggu
            Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(150.dp).background(
                androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.Transparent, BG.copy(alpha = 0.92f)))))
            Box(Modifier.align(Alignment.BottomCenter).navigationBarsPadding()) {
                NavBar(tab) { i -> if (i == 2) Store.game = null; tab = i }
            }
        }
    }
}
