package com.nexnon.engine

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private val permL = Shizuku.OnRequestPermissionResultListener { _, r -> Access.onPermissionResult(r == PackageManager.PERMISSION_GRANTED) }
    private val bindL = Shizuku.OnBinderReceivedListener { Access.refresh() }
    private val deadL = Shizuku.OnBinderDeadListener { Access.refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLog.init(this)
        CrashLog.install(application)
        AppLog.i("App", "proses dimulai")
        Access.init(this)
        Wallpaper.init(this)
        MonitorPrefs.load(this)
        BatteryStats.init(this)
        // Android 13+: notifikasi butuh izin. Tanpa izin, notifikasi pantauan tidak tampil (layanan tetap jalan).
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9)
        Shizuku.addRequestPermissionResultListener(permL)
        Shizuku.addBinderReceivedListenerSticky(bindL)
        Shizuku.addBinderDeadListener(deadL)
        setContent { MaterialTheme(colorScheme = darkColorScheme(background = BG, surface = BG, primary = AC)) { App() } }
    }

    override fun onResume() { super.onResume(); FpsMeter.start(); RecService.ensureRunning(this) }
    override fun onPause() { FpsMeter.stop(); super.onPause() }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permL)
        Shizuku.removeBinderReceivedListener(bindL)
        Shizuku.removeBinderDeadListener(deadL)
        super.onDestroy()
    }
}

@Composable
fun App() {
    var tab by remember { mutableIntStateOf(0) }
    BackHandler(enabled = tab == 1 && Store.game != null) { Store.game = null }
    BackHandler(enabled = Store.health) { Store.health = false }
    BackHandler(enabled = Store.reportId != null) { Store.reportId = null }
    Store.reportId?.let { id -> ReportScreen(id, onBack = { Store.reportId = null }); return }
    if (Store.health) { HealthScreen(onBack = { Store.health = false }); return }
    Box(Modifier.fillMaxSize().background(BG)) {
        Wallpaper.image?.let { bmp ->
            androidx.compose.foundation.Image(remember(bmp) { bmp.asImageBitmap() }, null, Modifier.fillMaxSize(),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop, filterQuality = androidx.compose.ui.graphics.FilterQuality.High)
            Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.verticalGradient(
                listOf(BG.copy(alpha = Wallpaper.dim * 0.12f), BG.copy(alpha = Wallpaper.dim * 0.8f)))))
        }
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> HomeScreen()
                    1 -> {
                        val g = PRESETS.firstOrNull { it.key == Store.game }
                        if (g == null) ConfigList() else if (g.kind == 1) WuWaDetail(g) else GameDetail(g)
                    }
                    2 -> StatsScreen()
                    else -> SettingsScreen()
                }
            }
            NavBar(tab) { i -> if (i == 1) Store.game = null; tab = i }
        }
        if (FpsMeter.overlay) Box(Modifier.align(Alignment.TopEnd).padding(8.dp)
            .background(Color(0xB3000000), RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 6.dp)) {
            T("${FpsMeter.fps} FPS", 13, CYAN, true)
        }
    }
}
