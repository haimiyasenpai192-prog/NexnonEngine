package com.nexnon.engine

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Tab Statistik bergaya Pulse Monitor: kepala (judul + LIVE), kartu Memori (RAM, ZRAM) yang bisa digeser ke Status CPU,
// penanda halaman, lalu grid 2x2 Baterai / Jaringan / RAM / Penyimpanan. Isi menempel di bawah, wallpaper terlihat di atasnya.

// Kotak dalam: kaca gelap setengah tembus yang tetap (tidak ikut slider wallpaper)
private val StInner: Color get() = Color(0xFF1E1F26).copy(alpha = 0.30f)
private val StAccent = Color(0xFF3DF0FF)
private val StBat = Color(0xFF5BD68E)      // hijau
private val StNet = Color(0xFF6FA8FF)      // biru
private val StRam = Color(0xFFA78BFA)      // ungu
private val StSto = Color(0xFFE8B84A)      // kuning
private val StSwap = Color(0xFFF472B6)     // pink (ZRAM / swap)
private val StLabel = Color(0xFFA9ADBA)
private val StMono = FontFamily.Monospace
private val StShadow = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.6f), Offset(0f, 2f), 8f))

/** Latar ikon: warna aksen 16% di atas dasar gelap, tapi pekat (tidak tembus wallpaper). */
private fun stChipBg(c: Color, a: Float = 0.16f, base: Color = Color(0xFF1E1F26)) =
    Color(base.red + (c.red - base.red) * a, base.green + (c.green - base.green) * a, base.blue + (c.blue - base.blue) * a)

/** Warna batang beban: aksen saat normal, kuning mulai berat, merah hampir penuh. */
private fun stBarLoad(p: Int): Color = when { p < 60 -> StAccent; p < 85 -> Color(0xFFFFD866); else -> Color(0xFFFF6B6B) }

/** Warna suhu: aman, hangat, panas, sangat panas. */
private fun stHeat(t: Float): Color = when {
    t < 45f -> Color(0xFF7CFFB2); t < 55f -> Color(0xFFFFD866); t < 65f -> Color(0xFFFF9F43); else -> Color(0xFFFF5C5C)
}

private fun stGb(v: Float) = if (v >= 0f) "%.1f GB".format(v) else "-"

@Composable
fun StatsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val live = Access.status == 2
    val pager = rememberPagerState { 2 }

    // Memori (RAM + ZRAM) dan info perangkat dibaca tanpa Shizuku/Root
    val mem by produceState<MemInfo?>(null) {
        while (true) { value = withContext(Dispatchers.IO) { DeviceExtras.memInfo() }; delay(1500) }
    }
    val ex by produceState(Extras()) {
        while (true) { value = withContext(Dispatchers.IO) { DeviceExtras.read(ctx) }; delay(2000) }
    }

    // Status CPU butuh shell, jadi hanya dibaca saat halamannya terlihat. Saat merekam FPS, pakai pembacaan milik perekam supaya tidak dobel.
    var cpu by remember { mutableStateOf<Sensors.Data?>(null) }
    val cpuHist = remember { mutableStateListOf<Int>() }
    val onCpuPage = pager.currentPage == 1
    LaunchedEffect(onCpuPage) {
        if (!onCpuPage) return@LaunchedEffect
        while (true) {
            val d = withContext(Dispatchers.IO) {
                if (Recorder.active) Sampler.lastSensors
                else if (Shell.mode() != "-") runCatching { Sensors.read(ctx) }.getOrNull()
                else null
            }
            cpu = d
            if (d != null && d.cpu >= 0) { cpuHist.add(d.cpu); while (cpuHist.size > 60) cpuHist.removeAt(0) }
            delay(if (Recorder.active) 1000L else 500L)
        }
    }

    var tools by remember { mutableStateOf(false) }
    var tempDlg by remember { mutableStateOf(false) }
    var batDlg by remember { mutableStateOf(false) }
    var netDlg by remember { mutableStateOf(false) }
    var ramDlg by remember { mutableStateOf(false) }
    var stoDlg by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        // Kepala: judul + chip akses sebaris, subjudul satu baris di bawahnya
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("STATISTIK", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium, fontFamily = StMono, letterSpacing = 0.8.sp,
                    style = StShadow, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(12.dp))
                Row(Modifier.clip(RoundedCornerShape(50)).background(Color(0xFF1E1F26).copy(alpha = 0.35f)).padding(horizontal = 9.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(6.dp).background(if (live) Color(0xFF7CFFB2) else Color(0xFFFF5C5C), CircleShape))
                    Text(if (live) "LIVE" else "BERI IZIN", color = if (live) Color(0xFF7CFFB2) else Color(0xFFFF8A8A),
                        fontWeight = FontWeight.Medium, fontSize = 9.5.sp, letterSpacing = 0.8.sp, fontFamily = StMono, maxLines = 1,
                        modifier = Modifier.padding(start = 5.dp))
                }
            }
            Box(Modifier.fillMaxWidth().height(22.dp).padding(top = 2.dp)) {
                Text("Statistik memori, suhu, CPU & RAM", color = Color(0xFFE6E6EE), fontSize = 14.sp, style = StShadow, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        // Panel menempel di bawah (di atas navigasi); kalau isinya lebih tinggi dari ruang yang ada, bisa digulir
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), contentAlignment = Alignment.BottomCenter) {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (!live) Text("Belum ada akses. Pilih Shizuku atau Root di tab Settings.", color = Color(0xFFE0B040), fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth().background(Color(0x1FE0B040), RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 10.dp))

                // Geser kiri-kanan: halaman 1 Memori, halaman 2 Status CPU. Tinggi kedua halaman beda; tinggi pager
                // diinterpolasi halus mengikuti jari supaya panel (menempel di bawah) tidak naik-turun mendadak.
                val pageH = remember { mutableStateListOf(0, 0) }
                val density = LocalDensity.current
                val pagerMod = if (pageH[0] > 0 && pageH[1] > 0) {
                    val f = (pager.currentPage + pager.currentPageOffsetFraction).coerceIn(0f, 1f)
                    val hPx = pageH[0] + (pageH[1] - pageH[0]) * f
                    Modifier.fillMaxWidth().height(with(density) { hPx.toDp() })
                } else Modifier.fillMaxWidth()
                HorizontalPager(state = pager, pageSpacing = 10.dp, verticalAlignment = Alignment.Top, beyondViewportPageCount = 1, modifier = pagerMod) { page ->
                    // Halaman yang menjauh sedikit mengecil dan memudar, yang masuk membesar dan menyala
                    Box(Modifier.fillMaxWidth().wrapContentHeight(Alignment.Top, unbounded = true)
                        .onSizeChanged { if (it.height > 0 && pageH[page] != it.height) pageH[page] = it.height }
                        .graphicsLayer {
                            val off = ((pager.currentPage - page) + pager.currentPageOffsetFraction).let { if (it < 0f) -it else it }.coerceIn(0f, 1f)
                            val k = 1f - off
                            transformOrigin = TransformOrigin(0.5f, 0f)
                            scaleX = 0.95f + 0.05f * k; scaleY = 0.95f + 0.05f * k
                            alpha = 0.6f + 0.4f * k
                            translationX = size.width * 0.03f * (if (pager.currentPage + pager.currentPageOffsetFraction > page) off else -off)
                        }) {
                        if (page == 0) MemoryPage(mem, onTools = { tools = true })
                        else StCpuCard(cpu, cpuHist, live, Recorder.active, onTemp = { tempDlg = true })
                    }
                }

                // Penanda halaman: pil aksen meluncur mengikuti jari, dua titik putih di bawahnya. Bisa digeser atau diketuk.
                val pill = 22.dp; val dot = 8.dp; val travel = 16.dp
                val slide = (pager.currentPage + pager.currentPageOffsetFraction).coerceIn(0f, 1f)
                Box(Modifier.fillMaxWidth().padding(top = 2.dp).height(28.dp)
                    .pointerInput(Unit) {
                        detectTapGestures { pos -> scope.launch { pager.animateScrollToPage(if (pos.x < size.width / 2f) 0 else 1) } }
                    }
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures(
                            onDragEnd = {
                                scope.launch {
                                    val f = pager.currentPageOffsetFraction
                                    val target = when { f > 0.2f -> pager.currentPage + 1; f < -0.2f -> pager.currentPage - 1; else -> pager.currentPage }
                                    pager.animateScrollToPage(target.coerceIn(0, 1))
                                }
                            },
                            onDragCancel = { scope.launch { pager.animateScrollToPage(pager.currentPage) } }
                        ) { change, dx -> change.consume(); scope.launch { pager.scrollBy(-dx) } }
                    }, contentAlignment = Alignment.Center) {
                    Box(Modifier.width(pill + travel).height(8.dp)) {
                        Box(Modifier.align(Alignment.CenterStart).size(dot).background(Color(0x99FFFFFF), CircleShape))
                        Box(Modifier.align(Alignment.CenterEnd).size(dot).background(Color(0x99FFFFFF), CircleShape))
                        Box(Modifier.offset { IntOffset((slide * travel.toPx()).toInt(), 0) }
                            .width(pill).height(8.dp).background(StAccent, CircleShape))
                    }
                }

                DeviceGrid(mem, ex, onBat = { batDlg = true }, onNet = { netDlg = true }, onRam = { ramDlg = true }, onSto = { stoDlg = true })
            }
        }
    }

    if (tools) StToolsDialog { tools = false }
    if (tempDlg) StTempDialog(cpu) { tempDlg = false }
    if (batDlg) StBatDialog { batDlg = false }
    if (netDlg) StNetDialog { netDlg = false }
    if (ramDlg) StRamDialog { ramDlg = false }
    if (stoDlg) StStorageDialog { stoDlg = false }
}

/** Halaman 1: kartu judul Memori (ukuran RAM di kotak + tombol pengaturan), lalu RAM dan ZRAM / Swap masing-masing satu kartu. */
@Composable
private fun MemoryPage(m: MemInfo?, onTools: () -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth().background(StInner, RoundedCornerShape(20.dp)).padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("Memori", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            if (m != null && m.marketGb > 0) {
                Text("${m.marketGb} GB", color = Color.White, fontSize = 12.sp,
                    modifier = Modifier.padding(start = 10.dp).background(Color(0xFF1E1F26).copy(alpha = 0.35f), CircleShape).padding(horizontal = 10.dp, vertical = 3.dp))
            }
            Spacer(Modifier.weight(1f))
            Box(Modifier.size(32.dp).clip(CircleShape).background(Color(0xFF1E1F26).copy(alpha = 0.35f)).clickable { onTools() }, contentAlignment = Alignment.Center) {
                Text("⚙", color = Color.White, fontSize = 16.sp)
            }
        }
        val rowCard = Modifier.background(StInner, RoundedCornerShape(20.dp)).padding(horizontal = 14.dp, vertical = 4.dp)
        if (m == null) {
            Text("Memori belum terbaca", color = Color.White, fontSize = 13.sp, modifier = rowCard.fillMaxWidth().padding(vertical = 12.dp))
        } else {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                StMemRow("RAM", m.ramTotal, m.ramUsed, m.ramFree, stBarLoad(m.ramPct), swap = false, modifier = rowCard)
                if (m.swapTotal > 0f) StMemRow(if (m.zram) "ZRAM" else "Swap", m.swapTotal, m.swapUsed, m.swapFree, StSwap, swap = true, modifier = rowCard)
                if (m.extraTotal > 0f) StMemRow("Swap tambahan", m.extraTotal, m.extraUsed, (m.extraTotal - m.extraUsed).coerceAtLeast(0f), StSwap, swap = true, modifier = rowCard)
            }
        }
    }
}

/** Baris memori: chip ikon, label + persen, batang animasi, lalu terpakai dari total dan sisa bebas. */
@Composable
private fun StMemRow(label: String, total: Float, used: Float, free: Float, color: Color, swap: Boolean, modifier: Modifier = Modifier) {
    val frac = if (total > 0f) (used / total).coerceIn(0f, 1f) else 0f
    val anim by animateFloatAsState(frac, tween(600), label = "memFrac")
    Row(modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(Modifier.size(44.dp).background(stChipBg(color), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(22.dp)) {
                val w = size.width; val sw = w * 0.09f
                val st = Stroke(width = sw, cap = StrokeCap.Round)
                if (!swap) {
                    // ikon chip RAM: badan + kaki di atas dan bawah
                    drawRoundRect(color, Offset(w * 0.2f, w * 0.26f), Size(w * 0.6f, w * 0.48f), CornerRadius(w * 0.08f), style = st)
                    for (i in 0..2) {
                        val x = w * (0.34f + 0.16f * i)
                        drawLine(color, Offset(x, w * 0.1f), Offset(x, w * 0.26f), sw, StrokeCap.Round)
                        drawLine(color, Offset(x, w * 0.74f), Offset(x, w * 0.9f), sw, StrokeCap.Round)
                    }
                } else {
                    // ikon tumpukan lapisan untuk ZRAM / Swap
                    for (i in 0..2) {
                        drawRoundRect(color.copy(alpha = if (i == 2) 1f else 0.55f), Offset(w * 0.12f, w * (0.14f + 0.27f * i)),
                            Size(w * 0.76f, w * 0.18f), CornerRadius(w * 0.09f))
                    }
                }
            }
        }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, modifier = Modifier.weight(1f))
                Text(buildAnnotatedString {
                    withStyle(SpanStyle(fontSize = 13.sp, fontWeight = FontWeight.SemiBold)) { append("${Math.round(frac * 100)}") }
                    withStyle(SpanStyle(fontSize = 10.sp, fontWeight = FontWeight.Medium)) { append("%") }
                }, color = Color.White, maxLines = 1)
            }
            Box(Modifier.padding(top = 6.dp, bottom = 8.dp).fillMaxWidth().height(6.dp).clip(CircleShape).background(Color(0x1FFFFFFF))) {
                if (anim > 0f) Box(Modifier.fillMaxWidth(anim).fillMaxHeight().clip(CircleShape).background(color))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(buildAnnotatedString {
                    withStyle(SpanStyle(color = Color.White, fontWeight = FontWeight.SemiBold)) { append("%.1f".format(used)) }
                    append(" dari %.1f GB".format(total))
                }, color = Color.White, fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f))
                Text("Bebas %.1f GB".format(free), color = Color.White, fontSize = 12.sp, maxLines = 1)
            }
        }
    }
}

/** Grid 2 kolom: Baterai, Jaringan, RAM, Penyimpanan. Tiap kotak berisi ikon + judul, angka besar, bilah tipis, dan keterangan kecil. */
@Composable
private fun DeviceGrid(mem: MemInfo?, ex: Extras, onBat: () -> Unit, onNet: () -> Unit, onRam: () -> Unit, onSto: () -> Unit) {
    val bat = ex.bat
    val net = ex.net
    val ram = mem?.let { SizeExtra(it.ramUsed, it.ramTotal) } ?: ex.ram
    val sto = ex.storage
    fun sizeVal(v: SizeExtra) = if (v.usedGb >= 0f && v.totalGb > 0f) "%.1f / %.1f GB".format(v.usedGb, v.totalGb) else "-"
    val batSub = listOf(if (bat.tempC >= 0f) "${deg(bat.tempC)}C" else "", if (bat.remain.isNotBlank() && bat.remain != "-") bat.remain else bat.state)
        .filter { it.isNotBlank() && it != "-" }.joinToString(" · ")
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StTile(Modifier.weight(1f).fillMaxHeight(), StBat, "Baterai", if (bat.pct >= 0) "${bat.pct}" else "-", "%",
                if (bat.pct >= 0) bat.pct / 100f else 0f, batSub, onClick = onBat) {
                Canvas(Modifier.size(14.dp, 18.dp)) {
                    val sw = 1.6.dp.toPx()
                    drawRoundRect(StBat, Offset(sw / 2, 3.dp.toPx()), Size(size.width - sw, size.height - 3.dp.toPx() - sw / 2), CornerRadius(3.dp.toPx()), style = Stroke(sw))
                    drawRoundRect(StBat, Offset(size.width * 0.35f, 0f), Size(size.width * 0.3f, 2.2.dp.toPx()), CornerRadius(1.dp.toPx()))
                }
            }
            StTile(Modifier.weight(1f).fillMaxHeight(), StNet, "Jaringan", if (net.mbps > 0) "${net.mbps}" else net.type, if (net.mbps > 0) " Mbps" else "",
                if (net.sigPct >= 0) net.sigPct / 100f else 0f,
                if (net.sigPct >= 0) "${net.type} · ${net.dbm} dBm" else "", onClick = onNet) {
                StSignalBars(net.sigPct, StNet)
            }
        }
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StTile(Modifier.weight(1f).fillMaxHeight(), StRam, "RAM", if (ram.pct >= 0) "${ram.pct}" else "-", "%",
                if (ram.pct >= 0) ram.pct / 100f else 0f, sizeVal(ram), onClick = onRam) {
                Canvas(Modifier.size(20.dp)) {
                    val w = size.width; val sw = w * 0.09f
                    drawRoundRect(StRam, Offset(w * 0.2f, w * 0.26f), Size(w * 0.6f, w * 0.48f), CornerRadius(w * 0.08f), style = Stroke(sw))
                    for (i in 0..2) {
                        val x = w * (0.34f + 0.16f * i)
                        drawLine(StRam, Offset(x, w * 0.1f), Offset(x, w * 0.26f), sw, StrokeCap.Round)
                        drawLine(StRam, Offset(x, w * 0.74f), Offset(x, w * 0.9f), sw, StrokeCap.Round)
                    }
                }
            }
            StTile(Modifier.weight(1f).fillMaxHeight(), StSto, "Penyimpanan", if (sto.pct >= 0) "${sto.pct}" else "-", "%",
                if (sto.pct >= 0) sto.pct / 100f else 0f, sizeVal(sto), onClick = onSto) {
                Canvas(Modifier.size(20.dp)) {
                    val w = size.width; val sw = w * 0.09f
                    drawRoundRect(StSto, Offset(w * 0.16f, w * 0.24f), Size(w * 0.68f, w * 0.54f), CornerRadius(w * 0.14f), style = Stroke(sw))
                    drawLine(StSto, Offset(w * 0.16f, w * 0.57f), Offset(w * 0.84f, w * 0.57f), sw, StrokeCap.Round)
                    drawCircle(StSto, w * 0.03f, Offset(w * 0.67f, w * 0.68f))
                }
            }
        }
    }
}

/** Satu kotak grid: ikon berwarna + judul, angka utama besar (satuan kecil), bilah progres tipis, keterangan kecil. */
@Composable
private fun StTile(modifier: Modifier, color: Color, title: String, big: String, unit: String, frac: Float, sub: String,
                   onClick: (() -> Unit)? = null, icon: @Composable BoxScope.() -> Unit) {
    val anim by animateFloatAsState(frac.coerceIn(0f, 1f), tween(500), label = "tileFrac")
    Column(modifier.clip(RoundedCornerShape(20.dp)).background(StInner)
        .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(30.dp).background(stChipBg(color), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center, content = icon)
            Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(start = 8.dp))
        }
        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.Bottom) {
            Text(big, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, lineHeight = 26.sp)
            if (unit.isNotEmpty()) Text(unit, color = Color.White, fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(bottom = 3.dp))
        }
        Box(Modifier.padding(top = 6.dp).fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF2A2D38))) {
            Box(Modifier.fillMaxWidth(anim).fillMaxHeight().background(color, RoundedCornerShape(3.dp)))
        }
        Text(sub.ifEmpty { " " }, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
    }
}

/** Ikon sinyal 4 batang; batang yang menyala mengikuti kekuatan sinyal (persen), sisanya redup. */
@Composable
private fun StSignalBars(pct: Int, color: Color) {
    val lit = when { pct >= 80 -> 4; pct >= 55 -> 3; pct >= 30 -> 2; pct >= 1 -> 1; else -> 0 }
    Canvas(Modifier.size(width = 20.dp, height = 16.dp)) {
        val n = 4
        val gap = 2.dp.toPx()
        val bw = (size.width - gap * (n - 1)) / n
        val r = CornerRadius(1.5.dp.toPx())
        for (i in 0 until n) {
            val h = size.height * (i + 1) / n
            drawRoundRect(color = if (i < lit) color else color.copy(alpha = 0.25f), topLeft = Offset(i * (bw + gap), size.height - h),
                size = Size(bw, h), cornerRadius = r)
        }
    }
}

// ---------------------------------------------------------------- Halaman 2: Status CPU

/** Kartu Status CPU: frekuensi tiap inti (empat kolom), info cluster, dan grafik beban CPU di dasar kartu. */
@Composable
private fun StCpuCard(d: Sensors.Data?, hist: List<Int>, access: Boolean, recording: Boolean, onTemp: () -> Unit) {
    val green = Color(0xFF9AA0A6)
    val coreMhz = d?.coreMhz ?: emptyList()
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(StInner)) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Status CPU", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0xFF2E3039)).clickable { onTemp() }, contentAlignment = Alignment.Center) {
                Text("⚙", color = Color.White, fontSize = 18.sp)
            }
        }
        val peak = remember { intArrayOf(0) }
        peak[0] = maxOf(peak[0], coreMhz.maxOrNull() ?: 0)
        if (coreMhz.isEmpty()) {
            Text(if (access) "Frekuensi belum terbaca" else "Butuh akses Shizuku atau Root (tab Settings) untuk membaca CPU",
                color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(16.dp))
        } else Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            coreMhz.withIndex().toList().chunked(4).forEach { group ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    group.forEach { (i, mhz) ->
                        val frac = if (mhz > 0 && peak[0] > 0) (mhz.toFloat() / peak[0]).coerceIn(0.03f, 1f) else 0f
                        val barCol = if (frac >= 0.95f) Color(0xFFE6E8EB) else green
                        Column(Modifier.weight(1f).background(Color(0xFF101116).copy(alpha = 0.35f), RoundedCornerShape(12.dp)).padding(horizontal = 8.dp, vertical = 7.dp)) {
                            Text("Inti $i", color = Color.White, fontSize = 10.sp, maxLines = 1)
                            Text(if (mhz > 0) "$mhz MHz" else "Offline", color = Color.White, fontSize = 12.sp, maxLines = 1, softWrap = false)
                            Box(Modifier.padding(top = 4.dp).fillMaxWidth().height(3.dp).background(Color(0xFF2A2D38), RoundedCornerShape(2.dp))) {
                                Box(Modifier.fillMaxWidth(frac).height(3.dp).background(barCol, RoundedCornerShape(2.dp)))
                            }
                        }
                    }
                    repeat(4 - group.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
        if (d != null) StCpuInfoBox(d)
        if (recording) Text("Sedang merekam FPS: data CPU ikut pembacaan perekam", color = Color.White, fontSize = 11.sp,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp))
        StCpuGraph(hist, green, Modifier.fillMaxWidth().height(36.dp))
    }
}

/** Info di dasar kartu Status CPU: beban sistem, frekuensi sekarang / maksimum tiap cluster (bilah), dan governor. */
@Composable
private fun StCpuInfoBox(d: Sensors.Data) {
    val bar = Color(0xFF9AA0A6); val track = Color(0xFF2A2D38)
    val names = stClusterNames(d.clMaxMhz.size)
    Column(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 10.dp)
        .background(Color(0xFF101116).copy(alpha = 0.35f), RoundedCornerShape(12.dp)).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Column {
            StInfoLine("Beban sistem CPU", if (d.cpu >= 0) "${d.cpu}%" else "-")
            Box(Modifier.padding(top = 4.dp).fillMaxWidth().height(3.dp).background(track, RoundedCornerShape(2.dp))) {
                Box(Modifier.fillMaxWidth((d.cpu.coerceIn(0, 100) / 100f).coerceAtLeast(0.02f)).height(3.dp).background(bar, RoundedCornerShape(2.dp)))
            }
        }
        d.clMaxMhz.forEachIndexed { i, (start, maxMhz) ->
            // Frekuensi sekarang cluster = tertinggi di antara inti-intinya (inti mati = -1 diabaikan)
            val end = d.clMaxMhz.getOrNull(i + 1)?.first ?: Int.MAX_VALUE
            val now = d.coreMhz.withIndex().filter { it.index in start until end && it.value > 0 }.maxOfOrNull { it.value } ?: 0
            val frac = if (maxMhz > 0) (now.toFloat() / maxMhz).coerceIn(0f, 1f) else 0f
            Column {
                StInfoLine(if (names[i] == "CPU") "Frekuensi CPU" else "Frekuensi ${names[i]} cluster", "${if (now > 0) now.toString() else "-"} / $maxMhz MHz")
                Box(Modifier.padding(top = 4.dp).fillMaxWidth().height(3.dp).background(track, RoundedCornerShape(2.dp))) {
                    Box(Modifier.fillMaxWidth(frac.coerceAtLeast(0.02f)).height(3.dp)
                        .background(if (frac >= 0.95f) Color(0xFFE6E8EB) else bar, RoundedCornerShape(2.dp)))
                }
            }
        }
        if (d.govs.isNotEmpty()) {
            Box(Modifier.fillMaxWidth().height(1.dp).background(track))
            val groups = d.govs.groupBy({ it.second }, { it.first })
            if (groups.size == 1) StInfoLine("Governor CPU", groups.keys.first(), alignEnd = false)
            else d.govs.forEach { (core, gov) ->
                val idx = d.clMaxMhz.indexOfFirst { it.first == core }
                StInfoLine("Governor ${if (idx >= 0) names[idx] else "Cluster $core"} cluster", gov, alignEnd = false)
            }
        }
    }
}

/** Satu baris "Label :" di kiri dan nilai tebal. alignEnd = true: nilai rata kanan; false: nilai langsung setelah label (dipakai Governor). */
@Composable
private fun StInfoLine(label: String, value: String, alignEnd: Boolean = true) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("$label :", color = Color.White, fontSize = 12.sp, maxLines = 1, softWrap = false)
        Spacer(Modifier.width(if (alignEnd) 10.dp else 6.dp))
        if (alignEnd) Spacer(Modifier.weight(1f))
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false)
    }
}

/** Nama cluster urut dari terkecil: 1 = CPU, 2 = Little/Big, 3 = Little/Big/Prime, 4+ = Little, Mid, ..., Big, Prime. */
private fun stClusterNames(n: Int): List<String> = when (n) {
    0 -> emptyList()
    1 -> listOf("CPU")
    2 -> listOf("Little", "Big")
    3 -> listOf("Little", "Big", "Prime")
    else -> List(n) { i -> when (i) { 0 -> "Little"; n - 1 -> "Prime"; n - 2 -> "Big"; else -> "Mid $i" } }
}

/** Grafik area beban CPU 0..100%, menempel di dasar kartu. */
@Composable
private fun StCpuGraph(h: List<Int>, col: Color, m: Modifier) {
    Canvas(m) {
        if (h.size < 2) return@Canvas
        val stepX = size.width / (h.size - 1)
        fun py(v: Int) = size.height * (1f - 0.12f - 0.78f * v.coerceIn(0, 100) / 100f)
        val fill = Path(); fill.moveTo(0f, size.height); fill.lineTo(0f, py(h[0]))
        for (i in 1 until h.size) {
            val x0 = (i - 1) * stepX; val y0 = py(h[i - 1]); val x1 = i * stepX; val y1 = py(h[i])
            fill.quadraticBezierTo(x0, y0, (x0 + x1) / 2f, (y0 + y1) / 2f)
            if (i == h.size - 1) fill.lineTo(x1, y1)
        }
        fill.lineTo(size.width, size.height); fill.close()
        drawPath(fill, col.copy(alpha = 0.35f))
    }
}

// ---------------------------------------------------------------- Dialog

/** Pengaturan di kartu Memori: pintu ke Kesehatan & log (diagnostik). */
@Composable
private fun StToolsDialog(onDismiss: () -> Unit) {
    TabDialog("Pengaturan Statistik", "Diagnostik", onDismiss) {
        SettingCard("Diagnostik") {
            Text("Cek fitur mana yang jalan dan mana yang tidak di HP ini, termasuk pembacaan CPU, suhu, dan memori. Hasilnya bisa dikirim sebagai laporan.",
                color = Color.White, fontSize = 12.sp)
            PillButton("Buka Kesehatan & log") { onDismiss(); Store.health = true }
        }
    }
}

/** Dialog di kartu Status CPU: suhu CPU, GPU, dan baterai. */
@Composable
private fun StTempDialog(d: Sensors.Data?, onDismiss: () -> Unit) {
    TabDialog("Suhu", "CPU, GPU, dan Baterai", onDismiss) {
        StTempMeter("CPU", d?.tCpu ?: -1f); StTempMeter("GPU", d?.tGpu ?: -1f); StTempMeter("Baterai", d?.tBat ?: -1f)
    }
}

@Composable
private fun StTempMeter(label: String, t: Float) {
    val word = when { t < 0f -> ""; t < 45f -> "Aman"; t < 55f -> "Hangat"; t < 65f -> "Panas"; else -> "Sangat panas" }
    val col = if (t < 0f) Color.White else stHeat(t)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(if (t < 0f) "-" else "${deg(t)}  $word", color = col, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Box(Modifier.fillMaxWidth().height(5.dp).background(Color(0x1FFFFFFF), CircleShape)) {
            Box(Modifier.fillMaxWidth(if (t < 0f) 0f else ((t - 20f) / 70f).coerceIn(0f, 1f)).fillMaxHeight().background(col, CircleShape))
        }
    }
}

/** Kerangka dialog rincian (RAM, Penyimpanan): ringkasan persen besar + lencana + bilah, lalu kotak rincian dua kolom. */
@Composable
private fun StInfoDialog(title: String, subtitle: String, pct: Int, color: Color, badge: String, cells: List<Pair<String, String>>, onDismiss: () -> Unit) {
    val anim by animateFloatAsState(if (pct >= 0) pct / 100f else 0f, tween(500), label = "infoDlgFrac")
    TabDialog(title, subtitle, onDismiss) {
        StSummaryBox(if (pct >= 0) "$pct" else "-", badge, color, color, anim)
        StCellGrid(cells)
    }
}

/** Ringkasan di dialog: persen besar di kiri, lencana di kanan, bilah di bawahnya. */
@Composable
private fun StSummaryBox(big: String, badge: String, badgeColor: Color, barColor: Color, frac: Float) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF0D0E12), RoundedCornerShape(20.dp)).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), verticalAlignment = Alignment.Bottom) {
                Text(big, color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 44.sp)
                Text("%", color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(start = 2.dp, bottom = 6.dp))
            }
            Text(badge, color = badgeColor, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                modifier = Modifier.background(badgeColor.copy(alpha = 0.14f), CircleShape).padding(horizontal = 10.dp, vertical = 4.dp))
        }
        Box(Modifier.padding(top = 10.dp).fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF2A2D38))) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(barColor, RoundedCornerShape(4.dp)))
        }
    }
}

/** Kotak rincian dua kolom. Sel dengan nilai di daftar [bad] ditandai merah. */
@Composable
private fun StCellGrid(cells: List<Pair<String, String>>, bad: Set<String> = emptySet()) {
    cells.chunked(2).forEach { pair ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            pair.forEach { (label, value) ->
                Column(Modifier.weight(1f).background(Color(0xFF0D0E12), RoundedCornerShape(16.dp)).padding(horizontal = 12.dp, vertical = 10.dp)) {
                    Text(label, color = StLabel, fontSize = 12.sp, maxLines = 1)
                    Text(value, color = if (label in bad) Color(0xFFFF8A8A) else Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, modifier = Modifier.padding(top = 2.dp))
                }
            }
            if (pair.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

/** Dialog di kotak RAM: total, terpakai, tersedia, bebas, cache, dan swap/ZRAM. Diperbarui tiap 2 detik. */
@Composable
private fun StRamDialog(onDismiss: () -> Unit) {
    val d by produceState(MemDetail()) { while (true) { value = withContext(Dispatchers.IO) { DeviceExtras.memDetail() }; delay(2000) } }
    val pct = if (d.totalGb > 0f && d.usedGb >= 0f) (d.usedGb * 100f / d.totalGb).toInt().coerceIn(0, 100) else -1
    StInfoDialog("RAM", "Pemakaian memori saat ini", pct, StRam, if (d.availGb >= 0f) "${stGb(d.availGb)} tersedia" else "-",
        listOf(
            "Total" to stGb(d.totalGb),
            "Terpakai" to stGb(d.usedGb),
            "Tersedia" to stGb(d.availGb),
            "Bebas" to stGb(d.freeGb),
            "Cache" to stGb(d.cacheGb),
            "Swap / ZRAM" to if (d.swapTotalGb > 0f) "%.1f / %.1f GB".format(d.swapUsedGb, d.swapTotalGb) else "Tidak ada"
        ), onDismiss)
}

/** Dialog di kotak Penyimpanan: partisi data (isi pengguna) dan partisi sistem. Diperbarui tiap 2 detik. */
@Composable
private fun StStorageDialog(onDismiss: () -> Unit) {
    val d by produceState(StoDetail()) { while (true) { value = withContext(Dispatchers.IO) { DeviceExtras.stoDetail() }; delay(2000) } }
    val pct = if (d.totalGb > 0f && d.usedGb >= 0f) (d.usedGb * 100f / d.totalGb).toInt().coerceIn(0, 100) else -1
    StInfoDialog("Penyimpanan", "Penyimpanan internal", pct, StSto, if (d.freeGb >= 0f) "${stGb(d.freeGb)} bebas" else "-",
        listOf(
            "Total" to stGb(d.totalGb),
            "Terpakai" to stGb(d.usedGb),
            "Bebas" to stGb(d.freeGb),
            "Terisi" to if (pct >= 0) "$pct%" else "-",
            "Partisi sistem" to stGb(d.sysTotalGb),
            "Sistem terpakai" to stGb(d.sysUsedGb)
        ), onDismiss)
}

/** Dialog di kartu Baterai: ringkasan level + status di atas, lalu rincian dalam kotak kecil dua kolom. Diperbarui tiap 2 detik selama terbuka. */
@Composable
private fun StBatDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val d by produceState(BatDetail()) { while (true) { value = withContext(Dispatchers.IO) { DeviceExtras.batDetail(ctx) }; delay(2000) } }
    val lvlCol = when { d.pct in 0..15 -> Color(0xFFFF6B6B); d.pct in 0..30 -> Color(0xFFFFD866); else -> StBat }
    val anim by animateFloatAsState(if (d.pct >= 0) d.pct / 100f else 0f, tween(500), label = "batDlgFrac")
    val bc = if (d.charging) StBat else Color(0xFF9AA0A6)
    TabDialog("Baterai", "Level, kondisi, dan kapasitas", onDismiss) {
        StSummaryBox(if (d.pct >= 0) "${d.pct}" else "-", d.status, bc, lvlCol, anim)
        StCellGrid(listOf(
            "Suhu" to if (d.tempC >= 0f) "%.1f°C".format(d.tempC) else "-",
            "Tegangan" to if (d.volt > 0f) "%.3f V".format(d.volt) else "-",
            "Kondisi" to d.health,
            "Teknologi" to d.tech,
            "Kapasitas desain" to if (d.designMah > 0) "${d.designMah} mAh" else "-",
            "Muatan tersisa" to if (d.remainMah > 0) "${d.remainMah} mAh" else "-",
            "Arus" to if (d.currentMa != Int.MIN_VALUE) "${d.currentMa} mA" else "-",
            "Siklus" to if (d.cycles > 0) "${d.cycles}x" else "-"
        ), bad = if (d.healthGood) emptySet() else setOf("Kondisi"))
    }
}

/** Dialog di kartu Jaringan: tiga bagian (Wi-Fi, Seluler, SIM), tiap bagian satu kartu dengan lencana status dan baris rincian. */
@Composable
private fun StNetDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val d by produceState(NetDetail()) { while (true) { value = withContext(Dispatchers.IO) { DeviceExtras.netDetail(ctx) }; delay(2000) } }
    val wifiC = StNet; val mobC = StRam; val simC = StBat
    TabDialog("Jaringan", "Wi-Fi, seluler, dan SIM", onDismiss) {
        StNetSection(wifiC, "Wi-Fi", if (d.wifiOn) "Terhubung" else "Tidak terhubung", d.wifiOn, { StSignalBars(if (d.wifiOn) d.wifiPct else 0, wifiC) }) {
            if (d.wifiOn) {
                // Kekuatan sinyal sebagai bilah besar, rincian lain di bawahnya
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                    Text("${d.wifiPct}%", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text("  ${d.wifiDbm} dBm", color = StLabel, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp))
                }
                Box(Modifier.padding(top = 6.dp, bottom = 4.dp).fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF2A2D38))) {
                    Box(Modifier.fillMaxWidth((d.wifiPct / 100f).coerceIn(0f, 1f)).fillMaxHeight().background(wifiC, RoundedCornerShape(3.dp)))
                }
                StNetRow("Alamat IP", d.wifiIp.ifEmpty { "-" })
                StNetRow("Kecepatan link", if (d.wifiMbps > 0) "${d.wifiMbps} Mbps" else "-")
                if (d.wifiBand.isNotEmpty()) StNetRow("Pita", d.wifiBand)
            } else Text("Tidak tersambung ke Wi-Fi.", color = StLabel, fontSize = 13.sp)
        }
        StNetSection(mobC, "Seluler", if (d.mobileOn) "Terhubung" else "Tidak terhubung", d.mobileOn, {
            Canvas(Modifier.size(14.dp, 20.dp)) {
                val sw = 1.7.dp.toPx()
                drawRoundRect(mobC, Offset(sw / 2, sw / 2), Size(size.width - sw, size.height - sw), CornerRadius(3.dp.toPx()), style = Stroke(sw))
                drawCircle(mobC, 1.2.dp.toPx(), Offset(size.width / 2, size.height - 4.dp.toPx()))
            }
        }) {
            StNetRow("Tipe telepon", d.phoneType)
            StNetRow("Data seluler", if (d.mobileOn) "Aktif" else "Tidak aktif")
        }
        StNetSection(simC, "Kartu SIM", d.simState, d.simReady, {
            Canvas(Modifier.size(16.dp, 20.dp)) {
                val sw = 1.7.dp.toPx()
                drawRoundRect(simC, Offset(sw / 2, sw / 2), Size(size.width - sw, size.height - sw), CornerRadius(3.dp.toPx()), style = Stroke(sw))
                drawRoundRect(simC, Offset(size.width * 0.28f, size.height * 0.42f), Size(size.width * 0.44f, size.height * 0.34f), CornerRadius(1.5.dp.toPx()))
            }
        }) {
            StNetRow("Operator", d.operator)
        }
    }
}

/** Satu bagian dialog jaringan: ikon + judul + lencana status di kepala, rincian di bawahnya. */
@Composable
private fun StNetSection(color: Color, title: String, badge: String, on: Boolean, icon: @Composable BoxScope.() -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF0D0E12), RoundedCornerShape(20.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(36.dp).background(stChipBg(color), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center, content = icon)
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f).padding(start = 12.dp))
            val bc = if (on) Color(0xFF5BD68E) else Color(0xFF9AA0A6)
            Text(badge, color = bc, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.background(bc.copy(alpha = 0.14f), CircleShape).padding(horizontal = 10.dp, vertical = 4.dp))
        }
        content()
    }
}

@Composable
private fun StNetRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = StLabel, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}
