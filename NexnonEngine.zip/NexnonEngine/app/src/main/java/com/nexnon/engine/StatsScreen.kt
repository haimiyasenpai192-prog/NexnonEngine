package com.nexnon.engine

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// Tab Statistik bergaya Pulse Monitor: kepala (judul), kartu Memori (RAM, ZRAM),
// lalu grid 2x2 Baterai / Jaringan / RAM / Penyimpanan. Isi menempel di bawah, wallpaper terlihat di atasnya.

// Kotak dalam: kaca gelap setengah tembus yang tetap (tidak ikut slider wallpaper)
private val StInner: Color get() = Color(0xFF1E1F26).copy(alpha = 0.30f)
private val StAccent = Color(0xFF3DF0FF)
private val StBat = Color(0xFF5BD68E)      // hijau
private val StNet = Color(0xFF6FA8FF)      // biru
private val StRam = Color(0xFFA78BFA)      // ungu
private val StSto = Color(0xFFE8B84A)      // kuning
private val StSwap = Color(0xFFF472B6)     // pink (ZRAM / swap)
private val StLabel = Color(0xFFA9ADBA)
private val StMono = FontFamily.Monospace
private val StShadow = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.6f), Offset(0f, 2f), 8f))

/** Latar ikon: warna aksen 16% di atas dasar gelap, tapi pekat (tidak tembus wallpaper). */
private fun stChipBg(c: Color, a: Float = 0.16f, base: Color = Color(0xFF1E1F26)) =
    Color(base.red + (c.red - base.red) * a, base.green + (c.green - base.green) * a, base.blue + (c.blue - base.blue) * a)

/** Warna batang beban: aksen saat normal, kuning mulai berat, merah hampir penuh. */
private fun stBarLoad(p: Int): Color = when { p < 60 -> StAccent; p < 85 -> Color(0xFFFFD866); else -> Color(0xFFFF6B6B) }

@Composable
fun StatsScreen() {
    val ctx = LocalContext.current
    val live = Access.status == 2

    // Memori (RAM + ZRAM) dan info perangkat dibaca tanpa Shizuku/Root
    val mem by produceState<MemInfo?>(null) {
        while (true) { value = withContext(Dispatchers.IO) { DeviceExtras.memInfo() }; delay(1500) }
    }
    val ex by produceState(Extras()) {
        while (true) { value = withContext(Dispatchers.IO) { DeviceExtras.read(ctx) }; delay(2000) }
    }

    var tools by remember { mutableStateOf(false) }
    var batDlg by remember { mutableStateOf(false) }
    var netDlg by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        // Kepala: judul, subjudul satu baris di bawahnya
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("STATISTIK", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium, fontFamily = StMono, letterSpacing = 0.8.sp,
                    style = StShadow, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            }
            Box(Modifier.fillMaxWidth().height(22.dp).padding(top = 2.dp)) {
                Text("Statistik memori, baterai & jaringan", color = Color(0xFFE6E6EE), fontSize = 14.sp, style = StShadow, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        // Panel menempel di bawah (di atas navigasi); kalau isinya lebih tinggi dari ruang yang ada, bisa digulir
        Box(Modifier.weight(1f).fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = NAV_SPACE), contentAlignment = Alignment.BottomCenter) {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (!live) Text("Belum ada akses. Pilih Shizuku atau Root di tab Settings.", color = Color(0xFFE0B040), fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth().background(Color(0x1FE0B040), RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 10.dp))

                MemoryPage(mem, onTools = { tools = true })

                DeviceGrid(ex, onBat = { batDlg = true }, onNet = { netDlg = true })
            }
        }
    }

    if (tools) StToolsDialog { tools = false }
    if (batDlg) StBatDialog { batDlg = false }
    if (netDlg) StNetDialog { netDlg = false }
}

/** Kartu judul Memori (ukuran RAM di kotak + tombol pengaturan), lalu RAM dan ZRAM / Swap masing-masing satu kartu. */
@Composable
private fun MemoryPage(m: MemInfo?, onTools: () -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth().background(StInner, RoundedCornerShape(20.dp)).padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("Memori", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            if (m != null && m.marketGb > 0) {
                Text("${m.marketGb} GB", color = Color.White, fontSize = 12.sp,
                    modifier = Modifier.padding(start = 10.dp).background(Color(0xFF1E1F26).copy(alpha = 0.35f), CircleShape).padding(horizontal = 10.dp, vertical = 3.dp))
            }
            Spacer(Modifier.weight(1f))
            Box(Modifier.size(32.dp).clip(CircleShape).background(Color(0xFF1E1F26).copy(alpha = 0.35f)).clickable { onTools() }, contentAlignment = Alignment.Center) {
                Text("⚙", color = Color.White, fontSize = 16.sp)
            }
        }
        val rowCard = Modifier.background(StInner, RoundedCornerShape(20.dp)).padding(horizontal = 14.dp, vertical = 4.dp)
        if (m == null) {
            Text("Memori belum terbaca", color = Color.White, fontSize = 13.sp, modifier = rowCard.fillMaxWidth().padding(vertical = 12.dp))
        } else {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                StMemRow("RAM", m.ramTotal, m.ramUsed, m.ramFree, stBarLoad(m.ramPct), swap = false, modifier = rowCard)
                if (m.swapTotal > 0f) StMemRow(if (m.zram) "ZRAM" else "Swap", m.swapTotal, m.swapUsed, m.swapFree, StSwap, swap = true, modifier = rowCard)
                if (m.extraTotal > 0f) StMemRow("Swap tambahan", m.extraTotal, m.extraUsed, (m.extraTotal - m.extraUsed).coerceAtLeast(0f), StSwap, swap = true, modifier = rowCard)
            }
        }
    }
}

/** Baris memori: chip ikon, label + persen, batang animasi, lalu terpakai dari total dan sisa bebas. */
@Composable
private fun StMemRow(label: String, total: Float, used: Float, free: Float, color: Color, swap: Boolean, modifier: Modifier = Modifier) {
    val frac = if (total > 0f) (used / total).coerceIn(0f, 1f) else 0f
    val anim by animateFloatAsState(frac, tween(600), label = "memFrac")
    Row(modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(Modifier.size(44.dp).background(stChipBg(color), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(22.dp)) {
                val w = size.width; val sw = w * 0.09f
                val st = Stroke(width = sw, cap = StrokeCap.Round)
                if (!swap) {
                    // ikon chip RAM: badan + kaki di atas dan bawah
                    drawRoundRect(color, Offset(w * 0.2f, w * 0.26f), Size(w * 0.6f, w * 0.48f), CornerRadius(w * 0.08f), style = st)
                    for (i in 0..2) {
                        val x = w * (0.34f + 0.16f * i)
                        drawLine(color, Offset(x, w * 0.1f), Offset(x, w * 0.26f), sw, StrokeCap.Round)
                        drawLine(color, Offset(x, w * 0.74f), Offset(x, w * 0.9f), sw, StrokeCap.Round)
                    }
                } else {
                    // ikon tumpukan lapisan untuk ZRAM / Swap
                    for (i in 0..2) {
                        drawRoundRect(color.copy(alpha = if (i == 2) 1f else 0.55f), Offset(w * 0.12f, w * (0.14f + 0.27f * i)),
                            Size(w * 0.76f, w * 0.18f), CornerRadius(w * 0.09f))
                    }
                }
            }
        }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, modifier = Modifier.weight(1f))
                Text(buildAnnotatedString {
                    withStyle(SpanStyle(fontSize = 13.sp, fontWeight = FontWeight.SemiBold)) { append("${Math.round(frac * 100)}") }
                    withStyle(SpanStyle(fontSize = 10.sp, fontWeight = FontWeight.Medium)) { append("%") }
                }, color = Color.White, maxLines = 1)
            }
            Box(Modifier.padding(top = 6.dp, bottom = 8.dp).fillMaxWidth().height(6.dp).clip(CircleShape).background(Color(0x1FFFFFFF))) {
                if (anim > 0f) Box(Modifier.fillMaxWidth(anim).fillMaxHeight().clip(CircleShape).background(color))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(buildAnnotatedString {
                    withStyle(SpanStyle(color = Color.White, fontWeight = FontWeight.SemiBold)) { append("%.1f".format(used)) }
                    append(" dari %.1f GB".format(total))
                }, color = Color.White, fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f))
                Text("Bebas %.1f GB".format(free), color = Color.White, fontSize = 12.sp, maxLines = 1)
            }
        }
    }
}

/** Grid 2 kolom: Baterai dan Jaringan. Tiap kotak berisi ikon + judul, angka besar, bilah tipis, dan keterangan kecil. */
@Composable
private fun DeviceGrid(ex: Extras, onBat: () -> Unit, onNet: () -> Unit) {
    val bat = ex.bat
    val net = ex.net
    val batSub = listOf(if (bat.tempC >= 0f) "${deg(bat.tempC)}C" else "", if (bat.remain.isNotBlank() && bat.remain != "-") bat.remain else bat.state)
        .filter { it.isNotBlank() && it != "-" }.joinToString(" · ")
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StTile(Modifier.weight(1f).fillMaxHeight(), StBat, "Baterai", if (bat.pct >= 0) "${bat.pct}" else "-", "%",
                if (bat.pct >= 0) bat.pct / 100f else 0f, batSub, onClick = onBat) {
                Canvas(Modifier.size(14.dp, 18.dp)) {
                    val sw = 1.6.dp.toPx()
                    drawRoundRect(StBat, Offset(sw / 2, 3.dp.toPx()), Size(size.width - sw, size.height - 3.dp.toPx() - sw / 2), CornerRadius(3.dp.toPx()), style = Stroke(sw))
                    drawRoundRect(StBat, Offset(size.width * 0.35f, 0f), Size(size.width * 0.3f, 2.2.dp.toPx()), CornerRadius(1.dp.toPx()))
                }
            }
            StTile(Modifier.weight(1f).fillMaxHeight(), StNet, "Jaringan", if (net.mbps > 0) "${net.mbps}" else net.type, if (net.mbps > 0) " Mbps" else "",
                if (net.sigPct >= 0) net.sigPct / 100f else 0f,
                if (net.sigPct >= 0) "${net.type} · ${net.dbm} dBm" else "", onClick = onNet) {
                StSignalBars(net.sigPct, StNet)
            }
        }
    }
}

/** Satu kotak grid: ikon berwarna + judul, angka utama besar (satuan kecil), bilah progres tipis, keterangan kecil. */
@Composable
private fun StTile(modifier: Modifier, color: Color, title: String, big: String, unit: String, frac: Float, sub: String,
                   onClick: (() -> Unit)? = null, icon: @Composable BoxScope.() -> Unit) {
    val anim by animateFloatAsState(frac.coerceIn(0f, 1f), tween(500), label = "tileFrac")
    Column(modifier.clip(RoundedCornerShape(20.dp)).background(StInner)
        .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier).padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(30.dp).background(stChipBg(color), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center, content = icon)
            Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(start = 8.dp))
        }
        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.Bottom) {
            Text(big, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, lineHeight = 26.sp)
            if (unit.isNotEmpty()) Text(unit, color = Color.White, fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(bottom = 3.dp))
        }
        Box(Modifier.padding(top = 6.dp).fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF2A2D38))) {
            Box(Modifier.fillMaxWidth(anim).fillMaxHeight().background(color, RoundedCornerShape(3.dp)))
        }
        Text(sub.ifEmpty { " " }, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
    }
}

/** Ikon sinyal 4 batang; batang yang menyala mengikuti kekuatan sinyal (persen), sisanya redup. */
@Composable
private fun StSignalBars(pct: Int, color: Color) {
    val lit = when { pct >= 80 -> 4; pct >= 55 -> 3; pct >= 30 -> 2; pct >= 1 -> 1; else -> 0 }
    Canvas(Modifier.size(width = 20.dp, height = 16.dp)) {
        val n = 4
        val gap = 2.dp.toPx()
        val bw = (size.width - gap * (n - 1)) / n
        val r = CornerRadius(1.5.dp.toPx())
        for (i in 0 until n) {
            val h = size.height * (i + 1) / n
            drawRoundRect(color = if (i < lit) color else color.copy(alpha = 0.25f), topLeft = Offset(i * (bw + gap), size.height - h),
                size = Size(bw, h), cornerRadius = r)
        }
    }
}

// ---------------------------------------------------------------- Dialog

/** Pengaturan di kartu Memori: pintu ke Kesehatan & log (diagnostik). */
@Composable
private fun StToolsDialog(onDismiss: () -> Unit) {
    TabDialog("Pengaturan Statistik", "Diagnostik", onDismiss) {
        SettingCard("Diagnostik") {
            Text("Cek fitur mana yang jalan dan mana yang tidak di HP ini, termasuk pembacaan suhu dan memori. Hasilnya bisa dikirim sebagai laporan.",
                color = Color.White, fontSize = 12.sp)
            PillButton("Buka Kesehatan & log") { onDismiss(); Store.health = true }
        }
    }
}

/** Ringkasan di dialog: persen besar di kiri, lencana di kanan, bilah di bawahnya. */
@Composable
private fun StSummaryBox(big: String, badge: String, badgeColor: Color, barColor: Color, frac: Float) {
    Column(Modifier.fillMaxWidth().background(cardBg, RoundedCornerShape(20.dp)).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), verticalAlignment = Alignment.Bottom) {
                Text(big, color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 44.sp)
                Text("%", color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(start = 2.dp, bottom = 6.dp))
            }
            Text(badge, color = badgeColor, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                modifier = Modifier.background(badgeColor.copy(alpha = 0.14f), CircleShape).padding(horizontal = 10.dp, vertical = 4.dp))
        }
        Box(Modifier.padding(top = 10.dp).fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF2A2D38))) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(barColor, RoundedCornerShape(4.dp)))
        }
    }
}

/** Kotak rincian dua kolom. Sel dengan nilai di daftar [bad] ditandai merah. */
@Composable
private fun StCellGrid(cells: List<Pair<String, String>>, bad: Set<String> = emptySet()) {
    cells.chunked(2).forEach { pair ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            pair.forEach { (label, value) ->
                Column(Modifier.weight(1f).background(cardBg, RoundedCornerShape(16.dp)).padding(horizontal = 12.dp, vertical = 10.dp)) {
                    Text(label, color = StLabel, fontSize = 12.sp, maxLines = 1)
                    Text(value, color = if (label in bad) Color(0xFFFF8A8A) else Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, modifier = Modifier.padding(top = 2.dp))
                }
            }
            if (pair.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

/** Dialog di kartu Baterai: ringkasan level + status di atas, lalu rincian dalam kotak kecil dua kolom. Diperbarui tiap 2 detik selama terbuka. */
@Composable
private fun StBatDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val d by produceState(BatDetail()) { while (true) { value = withContext(Dispatchers.IO) { DeviceExtras.batDetail(ctx) }; delay(2000) } }
    val lvlCol = when { d.pct in 0..15 -> Color(0xFFFF6B6B); d.pct in 0..30 -> Color(0xFFFFD866); else -> StBat }
    val anim by animateFloatAsState(if (d.pct >= 0) d.pct / 100f else 0f, tween(500), label = "batDlgFrac")
    val bc = if (d.charging) StBat else Color(0xFF9AA0A6)
    TabDialog("Baterai", "Level, kondisi, dan kapasitas", onDismiss) {
        StSummaryBox(if (d.pct >= 0) "${d.pct}" else "-", d.status, bc, lvlCol, anim)
        StCellGrid(listOf(
            "Suhu" to if (d.tempC >= 0f) "%.1f°C".format(d.tempC) else "-",
            "Tegangan" to if (d.volt > 0f) "%.3f V".format(d.volt) else "-",
            "Kondisi" to d.health,
            "Teknologi" to d.tech,
            "Kapasitas desain" to if (d.designMah > 0) "${d.designMah} mAh" else "-",
            "Muatan tersisa" to if (d.remainMah > 0) "${d.remainMah} mAh" else "-",
            "Arus" to if (d.currentMa != Int.MIN_VALUE) "${d.currentMa} mA" else "-",
            "Siklus" to if (d.cycles > 0) "${d.cycles}x" else "-"
        ), bad = if (d.healthGood) emptySet() else setOf("Kondisi"))
    }
}

/** Dialog di kartu Jaringan: tiga bagian (Wi-Fi, Seluler, SIM), tiap bagian satu kartu dengan lencana status dan baris rincian. */
@Composable
private fun StNetDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val d by produceState(NetDetail()) { while (true) { value = withContext(Dispatchers.IO) { DeviceExtras.netDetail(ctx) }; delay(2000) } }
    val wifiC = StNet; val mobC = StRam; val simC = StBat
    TabDialog("Jaringan", "Wi-Fi, seluler, dan SIM", onDismiss) {
        StNetSection(wifiC, "Wi-Fi", if (d.wifiOn) "Terhubung" else "Tidak terhubung", d.wifiOn, { StSignalBars(if (d.wifiOn) d.wifiPct else 0, wifiC) }) {
            if (d.wifiOn) {
                // Kekuatan sinyal sebagai bilah besar, rincian lain di bawahnya
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                    Text("${d.wifiPct}%", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text("  ${d.wifiDbm} dBm", color = StLabel, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp))
                }
                Box(Modifier.padding(top = 6.dp, bottom = 4.dp).fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF2A2D38))) {
                    Box(Modifier.fillMaxWidth((d.wifiPct / 100f).coerceIn(0f, 1f)).fillMaxHeight().background(wifiC, RoundedCornerShape(3.dp)))
                }
                StNetRow("Alamat IP", d.wifiIp.ifEmpty { "-" })
                StNetRow("Kecepatan link", if (d.wifiMbps > 0) "${d.wifiMbps} Mbps" else "-")
                if (d.wifiBand.isNotEmpty()) StNetRow("Pita", d.wifiBand)
            } else Text("Tidak tersambung ke Wi-Fi.", color = StLabel, fontSize = 13.sp)
        }
        StNetSection(mobC, "Seluler", if (d.mobileOn) "Terhubung" else "Tidak terhubung", d.mobileOn, {
            Canvas(Modifier.size(14.dp, 20.dp)) {
                val sw = 1.7.dp.toPx()
                drawRoundRect(mobC, Offset(sw / 2, sw / 2), Size(size.width - sw, size.height - sw), CornerRadius(3.dp.toPx()), style = Stroke(sw))
                drawCircle(mobC, 1.2.dp.toPx(), Offset(size.width / 2, size.height - 4.dp.toPx()))
            }
        }) {
            StNetRow("Tipe telepon", d.phoneType)
            StNetRow("Data seluler", if (d.mobileOn) "Aktif" else "Tidak aktif")
        }
        StNetSection(simC, "Kartu SIM", d.simState, d.simReady, {
            Canvas(Modifier.size(16.dp, 20.dp)) {
                val sw = 1.7.dp.toPx()
                drawRoundRect(simC, Offset(sw / 2, sw / 2), Size(size.width - sw, size.height - sw), CornerRadius(3.dp.toPx()), style = Stroke(sw))
                drawRoundRect(simC, Offset(size.width * 0.28f, size.height * 0.42f), Size(size.width * 0.44f, size.height * 0.34f), CornerRadius(1.5.dp.toPx()))
            }
        }) {
            StNetRow("Operator", d.operator)
        }
    }
}

/** Satu bagian dialog jaringan: ikon + judul + lencana status di kepala, rincian di bawahnya. */
@Composable
private fun StNetSection(color: Color, title: String, badge: String, on: Boolean, icon: @Composable BoxScope.() -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(cardBg, RoundedCornerShape(20.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(36.dp).background(stChipBg(color), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center, content = icon)
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f).padding(start = 12.dp))
            val bc = if (on) Color(0xFF5BD68E) else Color(0xFF9AA0A6)
            Text(badge, color = bc, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.background(bc.copy(alpha = 0.14f), CircleShape).padding(horizontal = 10.dp, vertical = 4.dp))
        }
        content()
    }
}

@Composable
private fun StNetRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = StLabel, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}
