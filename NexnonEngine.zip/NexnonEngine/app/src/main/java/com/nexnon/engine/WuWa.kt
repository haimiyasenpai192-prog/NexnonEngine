package com.nexnon.engine

import android.content.Context

/**
 * Pemasangan config Wuthering Waves (Unreal Engine) lewat Shizuku/Root.
 *  - Folder utama : Android/data/<paket>/files/UE4Game/Client/Client/Saved/Config/Android
 *  - Folder Engine: Android/data/<paket>/files/UE4Game/Client/Engine/Platforms/Android/Config
 *    (Engine.ini juga disalin ke sini sebagai AndroidEngine.ini; AndroidEngine.ini dari preset ditulis terakhir)
 */
object WuWa {
    val PACKAGES = listOf(
        "com.kurogame.wutheringwaves.global", "com.kurogame.wutheringwaves.bilibili", "com.kurogame.wutheringwaves.kuro",
        "com.kurogame.wutheringwaves.tw", "com.kurogame.wutheringwaves.jp", "com.kurogame.wutheringwaves.kr",
        "com.kurogame.wutheringwaves"
    )
    val ALL_FILES = listOf("Engine.ini", "DeviceProfiles.ini", "Scalability.ini", "GameUserSettings.ini", "AndroidEngine.ini")
    /** Yang dihapus tombol Hapus config: Engine.ini, DeviceProfiles.ini, dan AndroidEngine.ini. Scalability.ini & GameUserSettings.ini tidak ikut (milik game). */
    val REMOVABLE = listOf("Engine.ini", "DeviceProfiles.ini", "AndroidEngine.ini")
    /** Daftar file yang ditampilkan & dicek di UI: hanya Engine.ini dan DeviceProfiles.ini. */
    val SHOWN = listOf("Engine.ini", "DeviceProfiles.ini")
    private const val ENGINE_SRC = "Engine.ini"
    private const val ENGINE_DST = "AndroidEngine.ini"
    // Android 14+/HyperOS kadang menolak /storage/emulated/0; coba jalur lain ke penyimpanan yang sama.
    private val ROOTS = listOf("/storage/emulated/0", "/mnt/pass_through/0/emulated/0", "/mnt/user/0/emulated/0", "/data/media/0")
    @Volatile private var rootKey: String? = null
    @Volatile private var rootVal: String? = null

    fun installedPackage(ctx: Context): String? = PACKAGES.firstOrNull {
        runCatching { ctx.packageManager.getPackageInfo(it, 0); true }.getOrDefault(false)
    }

    private fun shown(n: String) = if (n.equals(ENGINE_DST, ignoreCase = true)) "File 3" else n
    private fun mask(s: String) = s.replace(ENGINE_DST, "File 3", ignoreCase = true)

    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    private fun rootFor(pkg: String): String {
        val key = "$pkg|${Shell.mode()}"
        if (rootKey == key) rootVal?.let { return it }
        val cmd = "for r in ${ROOTS.joinToString(" ")}; do if ls \"\$r/Android/data/$pkg\" >/dev/null 2>&1; then echo \"\$r\"; break; fi; done"
        val found = Shell.run(cmd).second.lines().firstOrNull()?.trim()?.takeIf { it.startsWith("/") }
        if (found != null) { rootKey = key; rootVal = found; return found }
        return ROOTS[0]
    }

    private fun dir(pkg: String) = "${rootFor(pkg)}/Android/data/$pkg/files/UE4Game/Client/Client/Saved/Config/Android"
    private fun engineDir(pkg: String) = "${rootFor(pkg)}/Android/data/$pkg/files/UE4Game/Client/Engine/Platforms/Android/Config"

    /** @return null jika sukses, atau pesan error */
    private fun write(pkg: String, name: String, text: String, dirOverride: String? = null): String? {
        val d = dirOverride ?: dir(pkg)
        val f = q("$d/$name")
        // Mode root: samakan pemilik/izin dengan folder induk agar game tetap bisa membaca file.
        val fix = if (Shell.mode() == "Root")
            " && { chown \$(stat -c %u:%g ${q(d)}) $f 2>/dev/null; chmod 660 $f 2>/dev/null; restorecon $f 2>/dev/null; true; }" else ""
        val (code, out) = Shell.run("mkdir -p ${q(d)} && cat > $f$fix", text.toByteArray())
        return if (code == 0) null else mask(out.ifBlank { "Gagal menulis ${shown(name)} (exit $code)" })
    }

    private fun read(path: String): String? = Shell.run("cat ${q(path)}").let { if (it.first == 0) it.second else null }

    private fun norm(s: String) = s.replace("\r\n", "\n").trim()

    /** Tulis lalu baca ulang untuk memastikan isinya sama. null = sukses. */
    fun writeVerified(pkg: String, name: String, text: String): String? {
        if (name.equals(ENGINE_DST, ignoreCase = true)) {
            val d = engineDir(pkg)
            write(pkg, ENGINE_DST, text, d)?.let { return "File 3: $it" }
            val b = read("$d/$ENGINE_DST") ?: return "File 3 tidak terbaca setelah ditulis"
            return if (norm(b) != norm(text)) "File 3 tidak sesuai setelah ditulis" else null
        }
        write(pkg, name, text)?.let { return "${shown(name)}: $it" }
        val back = read("${dir(pkg)}/$name") ?: return "${shown(name)} tidak terbaca setelah ditulis"
        if (norm(back) != norm(text)) return "${shown(name)} tidak sesuai setelah ditulis"
        if (name.equals(ENGINE_SRC, ignoreCase = true)) write(pkg, ENGINE_DST, text, engineDir(pkg))?.let { return "File 3: $it" }
        return null
    }

    /** Pasang semua file satu tingkat (urutan ALL_FILES, AndroidEngine.ini terakhir). null = semua sukses. */
    fun installFiles(pkg: String, files: Map<String, String>): String? {
        var err: String? = null
        for ((n, t) in files) err = writeVerified(pkg, n, t) ?: err
        return err
    }

    fun existing(pkg: String): List<String>? {
        val (code, out) = Shell.run("ls ${q(dir(pkg))} 2>/dev/null")
        if (code != 0) return null
        val have = out.lines().map { it.trim() }.toSet()
        return ALL_FILES.filter { f -> have.any { it.equals(f, ignoreCase = true) } }
    }

    fun delete(pkg: String, names: List<String>): String? {
        val d = dir(pkg)
        val e = engineDir(pkg)
        val cmds = names.map { "rm -f ${q("$d/$it")}" }.toMutableList()
        // AndroidEngine.ini ikut dihapus di semua lokasi (folder Engine, folder induknya, dan folder Saved), juga saat Engine.ini dihapus
        if (names.any { it.equals(ENGINE_SRC, ignoreCase = true) || it.equals(ENGINE_DST, ignoreCase = true) }) {
            cmds += "rm -f ${q("$e/$ENGINE_DST")} ${q("${e.removeSuffix("/Config")}/$ENGINE_DST")} ${q("$d/$ENGINE_DST")}"
        }
        val (code, out) = Shell.run(cmds.joinToString(" ; "))
        return if (code == 0) null else mask(out.ifBlank { "Gagal menghapus (exit $code)" })
    }

    /** Baca ulang file yang baru dipasang dari folder game dan bandingkan dengan isi aslinya. */
    fun verify(pkg: String, files: Map<String, String>): List<FileRow> {
        val rows = mutableListOf<FileRow>()
        fun check(label: String, path: String, expected: String?, hidden: Boolean = false) {
            val got = read(path)
            val row = when {
                got == null -> FileRow(label, 2, "tidak ada")
                got.isBlank() -> FileRow(label, 2, "kosong")
                expected != null && norm(got) != norm(expected) -> FileRow(label, 2, "isi berbeda")
                else -> FileRow(label, 1)
            }
            if (!(hidden && row.state == 1)) rows += row
        }
        for ((n, t) in files) {
            val path = if (n.equals(ENGINE_DST, ignoreCase = true)) "${engineDir(pkg)}/$ENGINE_DST" else "${dir(pkg)}/$n"
            val h = n.equals(ENGINE_DST, ignoreCase = true)
            check(if (h) "File 3" else n, path, t, h)
        }
        if (files.keys.any { it.equals(ENGINE_SRC, true) } && files.keys.none { it.equals(ENGINE_DST, true) })
            check("File 3", "${engineDir(pkg)}/$ENGINE_DST", files[ENGINE_SRC], true)
        return rows
    }

    /** Cek status semua file config di folder game. null = folder tidak bisa dibaca. */
    fun inspect(pkg: String): List<FileRow>? {
        val present = existing(pkg) ?: return null
        val rows = mutableListOf<FileRow>()
        for (n in SHOWN) {
            val isEng = n.equals(ENGINE_DST, ignoreCase = true)
            val has = isEng || present.any { it.equals(n, true) }
            val txt = if (has) read(if (isEng) "${engineDir(pkg)}/$n" else "${dir(pkg)}/$n") else null
            val required = n == "Engine.ini" || n == "DeviceProfiles.ini"
            rows += when {
                txt == null -> FileRow(n, if (required) 2 else 0, "tidak ada")
                txt.isBlank() -> FileRow(n, 2, "kosong")
                Regex("(?m)^\\s*\\[[^\\]]+\\]").containsMatchIn(txt) -> FileRow(n, 1, "VALID")
                else -> FileRow(n, 2, "tidak valid")
            }
        }
        return rows
    }

    // ---------- DEX2OAT ----------
    /** Mode kompilasi yang ditawarkan (juga dipakai memvalidasi argumen). */
    val DEX_MODES = listOf("speed-profile", "speed")

    /** Status kompilasi game saat ini (mis. "speed-profile", "verify"), atau null kalau tidak terbaca. */
    fun dexStatus(pkg: String): String? = runCatching {
        val (_, out) = Shell.run("dumpsys package dexopt | grep -A6 '\\[$pkg\\]'")
        Regex("status=([a-zA-Z0-9_-]+)").find(out)?.groupValues?.get(1)
    }.getOrNull()

    /**
     * Kompilasi ulang game dengan dex2oat. Langkah mengikuti versi Android:
     *  - Android 14+: bersihkan profil lama, compile penuh, lalu dexopt latar.
     *  - Android 12-13: compile, lalu secondary dex.
     *  - Android 11: compile biasa.
     * [mode] salah satu dari [DEX_MODES], atau null = reset ke bawaan sistem.
     * @return null jika sukses, atau pesan error. Bisa beberapa menit; panggil dari thread IO.
     */
    fun dexopt(pkg: String, mode: String?): String? {
        if (mode != null && mode !in DEX_MODES) return "Mode DEX2OAT tidak dikenal: $mode"
        val sdk = android.os.Build.VERSION.SDK_INT
        Report.addLog("DEX2OAT mulai: ${mode ?: "reset"} | $pkg | sdk=$sdk")
        fun step(label: String, cmd: String): Boolean {
            val (code, out) = Shell.run(cmd)
            if (code == 0) Report.addLog("DEX2OAT OK $label")
            else Report.addLog("DEX2OAT $label | exit=$code | ${out.lines().lastOrNull().orEmpty().take(160)}")
            return code == 0
        }
        if (mode == null) {
            val ok = step("reset", "cmd package compile --reset '$pkg'")
            if (sdk >= 34) { step("bersihkan profil", "cmd art clear-app-profiles '$pkg'"); step("cleanup", "cmd art cleanup '$pkg'") }
            return if (ok) null else "Reset DEX2OAT gagal. Buka Log untuk detail."
        }
        val ok: Boolean
        if (sdk >= 34) {
            step("verify awal", "cmd package compile -m verify -f '$pkg'")
            step("bersihkan profil", "cmd art clear-app-profiles '$pkg'")
            step("cleanup", "cmd art cleanup '$pkg'")
            ok = step("compile $mode", "cmd package compile -m $mode --full -f '$pkg'")
            if (ok) step("dexopt latar", "cmd art dexopt-packages -r bg-dexopt '$pkg'")
        } else {
            step("verify awal", "cmd package compile -m verify -f '$pkg'")
            ok = step("compile $mode", "cmd package compile -m $mode -f '$pkg'")
            if (ok && sdk >= 31) step("secondary dex", "cmd package compile -m $mode --secondary-dex '$pkg'")
        }
        if (!ok) return "Kompilasi $mode gagal. Buka Log untuk detail."
        Report.addLog("DEX2OAT selesai | status sekarang: ${dexStatus(pkg) ?: "tidak terbaca"}")
        return null
    }

    // ---------- Bersihkan ----------
    /**
     * Pembersih di folder data game. [what]: "shader" (cache pipeline/PSO) atau "junk" (laporan crash).
     * Pencarian dibatasi di folder Saved milik game dan tidak menyentuh folder Config.
     * @return (pesan error atau null, ringkasan seperti "12 file · 3,4 MB")
     */
    fun sweep(pkg: String, what: String): Pair<String?, String> = try {
        val saved = "${rootFor(pkg)}/Android/data/$pkg/files/UE4Game/Client/Client/Saved"
        val (match, act) = when (what) {
            "shader" -> "\\( -iname '*.upipelinecache' -o -iname '*pipelinecache*' -o -iname '*pso*' \\)" to "-exec rm -f {} +"
            "junk" -> "\\( -path '*/Crashes/*' -o -iname '*CrashClientReport*' \\)" to "-exec rm -rf {} +"
            else -> return "Aksi tidak dikenal: $what" to ""
        }
        val f = "find '$saved' -type f $match -not -path '*/Config/*'"
        val script = "n=\$($f 2>/dev/null | wc -l); k=\$($f -exec du -k {} + 2>/dev/null | awk '{s+=\$1} END{print s+0}'); $f $act 2>/dev/null; echo \"\$n \$k\""
        Report.addLog("Bersih mulai $what | $saved")
        val (code, out) = Shell.run(script)
        val last = out.lines().lastOrNull { it.matches(Regex("\\d+ \\d+")) }
        if (last == null) {
            Report.addLog("Bersih GAGAL $what | exit=$code | $out")
            "Gagal menjalankan pembersih. Buka Log untuk detail." to ""
        } else {
            val (n, kb) = last.split(" ").map { it.toLong() }
            val size = if (kb >= 1024) String.format(java.util.Locale.US, "%.1f MB", kb / 1024.0) else "$kb KB"
            val sum = if (n == 0L) "tidak ada file ditemukan" else "$n file \u00B7 $size"
            Report.addLog("Bersih OK $what | $sum")
            null to sum
        }
    } catch (e: Throwable) {
        Report.addLog("Bersih EXCEPTION ${e.javaClass.simpleName}: ${e.message}")
        (e.message ?: "Error") to ""
    }
}
