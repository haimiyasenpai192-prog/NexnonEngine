package com.nexnon.engine

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContract

/**
 * Pemilih file zip: selain pemilih sistem (Files/DocumentsUI), ikut tampil semua aplikasi file manager
 * yang terpasang dan mendukung "pilih file" (ACTION_GET_CONTENT), mis. MiXplorer, Material Files, Solid Explorer, dll.
 */
class PickZip : ActivityResultContract<Array<String>, Uri?>() {
    override fun createIntent(context: Context, input: Array<String>): Intent {
        val main = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*").putExtra(Intent.EXTRA_MIME_TYPES, input)
        val get = Intent(Intent.ACTION_GET_CONTENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*").putExtra(Intent.EXTRA_MIME_TYPES, input)
        val extras = runCatching { context.packageManager.queryIntentActivities(get, 0) }.getOrDefault(emptyList())
            .map { it.activityInfo }
            .filter { it.packageName != context.packageName && !it.packageName.contains("documentsui") }
            .distinctBy { it.packageName }
            .map { Intent(get).setClassName(it.packageName, it.name) }
        return Intent.createChooser(main, "Pilih file zip config")
            .putExtra(Intent.EXTRA_INITIAL_INTENTS, extras.toTypedArray())
    }

    override fun parseResult(resultCode: Int, intent: Intent?): Uri? =
        if (resultCode == Activity.RESULT_OK) intent?.data else null
}
