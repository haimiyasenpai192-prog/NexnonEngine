package com.nexnon.engine

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun QChip(label: String, sel: Boolean, onClick: () -> Unit) =
    Box(Modifier.clip(RoundedCornerShape(16.dp)).background(if (sel) VIOLET else Color(0xFF23252D)).clickable { onClick() }
        .padding(horizontal = 11.dp, vertical = 10.dp)) { T(label, 13, Color.White, true) }

@Composable
fun WuWaDetail(p: Preset) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var versions by remember { mutableStateOf(WuZip.versions(ctx)) }
    var showVer by remember { mutableStateOf(false) }
    var open by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var dexDlg by remember { mutableStateOf(false) }
    var cleanDlg by remember { mutableStateOf(false) }
    var dexNow by remember { mutableStateOf<String?>(null) }
    val sh = RoundedCornerShape(22.dp)
    val mimes = arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val r = withContext(Dispatchers.IO) { WuZip.importZip(ctx, uri) }
            versions = WuZip.versions(ctx)
            if (r.name != null) { Store.wuVersion = r.name; Store.wuTier = 0; msg = "Zip ${r.name} diimpor." } else msg = r.err ?: "Gagal impor."
        }
    }

    val ver = if (Store.wuVersion in versions) Store.wuVersion else versions.firstOrNull() ?: ""
    val parsed = if (ver.isEmpty()) null else WuZip.load(ctx, ver)
    val modes = parsed?.byMode?.keys?.sortedBy { if (it == "Flagship") 0 else if (it == "Balanced") 1 else 2 } ?: emptyList()
    val mode = if (Store.wuMode in modes) Store.wuMode else modes.firstOrNull() ?: ""
    val tiers = parsed?.byMode?.get(mode) ?: emptyList()
    val ti = Store.wuTier.coerceIn(0, maxOf(0, tiers.size - 1))
    val pkg = remember { WuWa.installedPackage(ctx) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = NAV_SPACE), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        T("‹ Kembali", 15, AC, true, Modifier.clickable { Store.game = null }.padding(vertical = 4.dp))
        T(p.name, 24, TX, true)
        // Versi config
        Row(Modifier.fillMaxWidth().background(cardBg, sh).border(1.dp, BD, sh).padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Ico(4, Color(0xFF4F8FE0))
            T(if (ver.isEmpty()) "Belum ada config" else ver, 14, TX, true, Modifier.weight(1f), 1)
            T(if (ver.isEmpty()) "Impor ›" else "Ganti ›", 14, PINK, true, Modifier.clickable { if (ver.isEmpty()) picker.launch(mimes) else showVer = true })
        }
        // Mode (Flagship / Balanced), hanya jika zip memilikinya
        if (modes.any { it.isNotEmpty() }) Row(Modifier.fillMaxWidth().background(cardBg, sh).border(1.dp, BD, sh).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Ico(1, AC); T("Mode", 14, TX, true); Spacer(Modifier.weight(1f))
            modes.filter { it.isNotEmpty() }.forEach { m -> QChip(m, m == mode) { Store.wuMode = m; Store.wuTier = 0 } }
        }
        // Kualitas (tingkat dari zip)
        Row(Modifier.fillMaxWidth().background(cardBg, sh).border(1.dp, BD, sh).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Ico(5, Color(0xFFE0B040)); T("Kualitas", 14, TX, true)
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End)) {
                if (tiers.isEmpty()) T("-", 14, MUT)
                tiers.forEachIndexed { i, t -> QChip(t.label, i == ti) { Store.wuTier = i } }
            }
        }
        // Install
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF5B9BDC), VIOLET, PINK)))
            .clickable {
                when {
                    Report.busy -> {}
                    tiers.isEmpty() -> Report.fail("Gagal memasang config", "Belum ada config. Ketuk Impor lalu pilih zip.")
                    pkg == null -> Report.fail("Gagal memasang config", "Wuthering Waves tidak ditemukan.")
                    Shell.mode() == "-" -> Report.fail("Gagal memasang config", "Akses belum aktif. Buka tab Settings lalu pilih Shizuku atau Root.")
                    else -> scope.launch {
                        val t = tiers[ti]
                        val label = listOf(ver, mode, t.label).filter { it.isNotEmpty() }.joinToString(" · ")
                        Report.begin("install", "Memasang config…", t.files.keys.filter { k -> WuWa.SHOWN.any { it.equals(k, true) } })
                        Report.addLog("Mulai pasang: $label | akses=${Shell.mode()} | paket=$pkg")
                        val err = withContext(Dispatchers.IO) { WuWa.installFiles(pkg, t.files) }
                        val rows = withContext(Dispatchers.IO) { WuWa.verify(pkg, t.files) }
                        rows.forEach { Report.addLog("${it.name}: ${if (it.state == 1) "OK" else it.note}") }
                        if (err != null) Report.addLog("GAGAL: $err")
                        val allOk = err == null && rows.all { it.state == 1 }
                        if (allOk) {
                            Store.configured[p.key] = label; Store.installs++; Store.last = "${p.name} · $label"
                            Report.end("install", true, "Config berhasil terpasang", label + " · " + Report.fmtTime(System.currentTimeMillis()), rows.filter { r -> WuWa.SHOWN.any { it.equals(r.name, true) } })
                        } else Report.end("install", false,
                            if (err != null) "Gagal memasang config" else "Config belum sepenuhnya terpasang",
                            err ?: "Ada file yang tidak sesuai di folder game.", rows.filter { r -> WuWa.SHOWN.any { it.equals(r.name, true) } }.ifEmpty { rows })
                    }
                }
            }.padding(vertical = 16.dp), contentAlignment = Alignment.Center) { T("Install", 20, Color.White, true) }
        ResultBox()
        if (msg.isNotEmpty()) T(msg, 13, MUT)
        T(if (open) "Detail ▾" else "Detail ›", 14, MUT, true, Modifier.clickable { open = !open }.padding(vertical = 8.dp))
        if (open) {
            T("Paket game: ${pkg ?: "tidak terdeteksi"}", 13, MUT)
            if (tiers.isNotEmpty()) T("File di tingkat ini: ${tiers[ti].files.keys.filter { k -> WuWa.SHOWN.any { it.equals(k, true) } }.joinToString(", ")}", 13, MUT)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).border(1.dp, BD, RoundedCornerShape(16.dp)).clickable {
                when {
                    Report.busy -> {}
                    pkg == null -> Report.fail("Gagal cek status", "Wuthering Waves tidak ditemukan.")
                    Shell.mode() == "-" -> Report.fail("Gagal cek status", "Akses belum aktif. Buka tab Settings.")
                    else -> scope.launch {
                        Report.begin("check", "Memeriksa file…", WuWa.SHOWN)
                        val rows = withContext(Dispatchers.IO) { WuWa.inspect(pkg) }
                        if (rows == null) Report.end("check", false, "Gagal membaca folder game", "Cek akses Shizuku atau Root.", emptyList())
                        else {
                            val good = rows.none { it.state == 2 }
                            rows.forEach { Report.addLog("Cek ${it.name}: ${it.note.ifEmpty { "OK" }}") }
                            Report.end("check", good, if (good) "Config terdeteksi" else "Config belum lengkap atau bermasalah", Report.fmtTime(System.currentTimeMillis()), rows)
                        }
                    }
                }
            }.padding(vertical = 12.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) { Ico(2, Color(0xFF5BD68E), 18.dp); Spacer(Modifier.width(8.dp)); T("Cek status", 14, TX, true) }
            Row(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).border(1.dp, BD, RoundedCornerShape(16.dp)).clickable {
                when {
                    Report.busy -> {}
                    pkg == null -> Report.fail("Gagal DEX2OAT", "Wuthering Waves tidak ditemukan.")
                    Shell.mode() == "-" -> Report.fail("Gagal DEX2OAT", "Akses belum aktif. Buka tab Settings.")
                    else -> {
                        dexNow = null; dexDlg = true
                        scope.launch { dexNow = withContext(Dispatchers.IO) { WuWa.dexStatus(pkg) } }
                    }
                }
            }.padding(vertical = 12.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Ico(8, Color(0xFFE0B040), 18.dp); Spacer(Modifier.width(8.dp)); T(if (Report.busy && Report.kind == "dex2oat") "Mengompilasi…" else "DEX2OAT", 14, TX, true)
            }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).border(1.dp, BD, RoundedCornerShape(16.dp)).clickable {
                when {
                    Report.busy -> {}
                    pkg == null -> Report.fail("Gagal membersihkan", "Wuthering Waves tidak ditemukan.")
                    Shell.mode() == "-" -> Report.fail("Gagal membersihkan", "Akses belum aktif. Buka tab Settings.")
                    else -> cleanDlg = true
                }
            }.padding(vertical = 12.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Ico(11, Color(0xFF5B9BE0), 18.dp); Spacer(Modifier.width(8.dp)); T("Bersihkan", 14, TX, true)
            }
            Row(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).border(1.dp, BD, RoundedCornerShape(16.dp)).clickable {
                when {
                    Report.busy -> {}
                    pkg == null -> Report.fail("Gagal menghapus config", "Wuthering Waves tidak ditemukan.")
                    Shell.mode() == "-" -> Report.fail("Gagal menghapus config", "Akses belum aktif. Buka tab Settings.")
                    else -> scope.launch {
                        Report.begin("delete", "Menghapus config…", WuWa.REMOVABLE)
                        val err = withContext(Dispatchers.IO) { WuWa.delete(pkg, WuWa.REMOVABLE) }
                        if (err == null) {
                            Store.configured.remove(p.key); Report.addLog("Config dihapus")
                            Report.end("delete", true, "Config dihapus", Report.fmtTime(System.currentTimeMillis()), WuWa.REMOVABLE.map { FileRow(it, 1) })
                        } else { Report.addLog("GAGAL hapus: $err"); Report.end("delete", false, "Gagal menghapus config", err, WuWa.REMOVABLE.map { FileRow(it, 2) }) }
                    }
                }
            }.padding(vertical = 12.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) { Ico(10, Color(0xFFE06070), 18.dp); Spacer(Modifier.width(8.dp)); T("Hapus config", 14, PINK, true) }
            }
        }
    }

    if (dexDlg) {
        val runDex: (String?, String) -> Unit = { m, label ->
            dexDlg = false
            if (pkg != null) scope.launch {
                Report.begin("dex2oat", "Mengompilasi DEX2OAT…", emptyList())
                Report.sub = "Jangan tutup aplikasi, bisa beberapa menit"
                val err = withContext(Dispatchers.IO) { WuWa.dexopt(pkg, m) }
                val st = withContext(Dispatchers.IO) { WuWa.dexStatus(pkg) }
                if (err == null) Report.end("dex2oat", true, "DEX2OAT selesai", "$label · status: ${st ?: "tidak terbaca"} · " + Report.fmtTime(System.currentTimeMillis()), emptyList())
                else Report.end("dex2oat", false, "DEX2OAT gagal", err, emptyList())
            }
        }
        AlertDialog(
            onDismissRequest = { dexDlg = false }, containerColor = Color.Black, shape = RoundedCornerShape(28.dp),
            title = { Text("DEX2OAT", color = TX, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    T("Kompilasi ulang game supaya loading dan performa lebih stabil. Prosesnya bisa beberapa menit, jangan tutup aplikasi.", 14, Color(0xFFC4CACE))
                    T("Status sekarang: ${dexNow ?: "tidak diketahui"}", 13, Color(0xFF5B9BE0), true)
                    ActOption("Speed-profile", "Seimbang, disarankan.", 8, Color(0xFF5BD68E), Color(0xFF0F1A14)) { runDex("speed-profile", "speed-profile") }
                    ActOption("Speed", "Kompilasi penuh, lebih lama dan memakai lebih banyak ruang.", 1, Color(0xFFE0B040), Color(0xFF17140C)) { runDex("speed", "speed") }
                    ActOption("Reset", "Hapus hasil kompilasi, kembali ke bawaan sistem.", 9, Color(0xFFFF6B6B), Color(0xFF1A1010)) { runDex(null, "reset") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { dexDlg = false }) { Text("Batal", color = VIOLET) } }
        )
    }
    if (cleanDlg) {
        val runClean: (String, String) -> Unit = { what, title ->
            cleanDlg = false
            if (pkg != null) scope.launch {
                Report.begin("bersih", "$title…", emptyList())
                Report.sub = "Sebentar…"
                val (err, sum) = withContext(Dispatchers.IO) { WuWa.sweep(pkg, what) }
                if (err == null) Report.end("bersih", true, "$title selesai", sum + " · " + Report.fmtTime(System.currentTimeMillis()), emptyList())
                else Report.end("bersih", false, "$title gagal", err, emptyList())
            }
        }
        AlertDialog(
            onDismissRequest = { cleanDlg = false }, containerColor = Color.Black, shape = RoundedCornerShape(28.dp),
            title = { Text("Bersihkan", color = TX, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    T("Pembersih ini hanya menyentuh folder data game dan tidak menghapus config.", 14, Color(0xFFC4CACE))
                    ActOption("Hapus shader", "Hapus cache shader. Dibuat ulang otomatis saat game dibuka.", 10, Color(0xFF5B9BE0), Color(0xFF0F1420)) { runClean("shader", "Hapus shader") }
                    ActOption("Hapus laporan crash", "Hapus file laporan crash game untuk melegakan ruang.", 11, Color(0xFFE0B040), Color(0xFF17140C)) { runClean("junk", "Hapus laporan crash") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { cleanDlg = false }) { Text("Batal", color = VIOLET) } }
        )
    }

    if (showVer) AlertDialog(
        onDismissRequest = { showVer = false }, containerColor = CARD,
        title = { Text("Versi config", color = TX) },
        text = {
            Column {
                versions.forEach { v ->
                    Row(Modifier.fillMaxWidth().clickable { Store.wuVersion = v; Store.wuTier = 0; showVer = false }.padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween) {
                        T(v, 15, if (v == ver) AC else TX, true)
                        T("Hapus", 13, PINK, false, Modifier.clickable { WuZip.delete(ctx, v); versions = WuZip.versions(ctx) })
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showVer = false; picker.launch(mimes) }) { Text("Impor zip") } },
        dismissButton = { TextButton(onClick = { showVer = false }) { Text("Tutup") } }
    )
}

/** Pilihan di dialog (ikon + judul berwarna + keterangan), seperti di dialog DEX2OAT / Bersihkan. */
@Composable
fun ActOption(title: String, desc: String, icon: Int, tint: Color, bg: Color, onClick: () -> Unit) {
    val sh = RoundedCornerShape(22.dp)
    Row(Modifier.fillMaxWidth().clip(sh).background(bg).border(1.dp, tint.copy(alpha = 0.45f), sh).clickable { onClick() }
        .padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Ico(icon, tint, 28.dp)
        Column(Modifier.weight(1f)) { T(title, 17, tint, true); T(desc, 14, Color(0xFFD5D9DD)) }
    }
}
