package com.nexnon.engine

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun QChip(label: String, sel: Boolean, onClick: () -> Unit) =
    Box(Modifier.clip(RoundedCornerShape(16.dp)).background(if (sel) VIOLET else Color(0xFF23252D)).clickable { onClick() }
        .padding(horizontal = 11.dp, vertical = 10.dp)) { T(label, 13, Color.White, true) }

@Composable
fun WuWaDetail(p: Preset) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var versions by remember { mutableStateOf(WuZip.versions(ctx)) }
    var showVer by remember { mutableStateOf(false) }
    var open by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val sh = RoundedCornerShape(22.dp)
    val mimes = arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val r = withContext(Dispatchers.IO) { WuZip.importZip(ctx, uri) }
            versions = WuZip.versions(ctx)
            if (r.name != null) { Store.wuVersion = r.name; Store.wuTier = 0; msg = "Zip ${r.name} diimpor." } else msg = r.err ?: "Gagal impor."
        }
    }

    val ver = if (Store.wuVersion in versions) Store.wuVersion else versions.firstOrNull() ?: ""
    val parsed = if (ver.isEmpty()) null else WuZip.load(ctx, ver)
    val modes = parsed?.byMode?.keys?.sortedBy { if (it == "Flagship") 0 else if (it == "Balanced") 1 else 2 } ?: emptyList()
    val mode = if (Store.wuMode in modes) Store.wuMode else modes.firstOrNull() ?: ""
    val tiers = parsed?.byMode?.get(mode) ?: emptyList()
    val ti = Store.wuTier.coerceIn(0, maxOf(0, tiers.size - 1))
    val pkg = remember { WuWa.installedPackage(ctx) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        T("‹ Kembali", 15, AC, true, Modifier.clickable { Store.game = null }.padding(vertical = 4.dp))
        T(p.name, 24, TX, true)
        // Versi config
        Row(Modifier.fillMaxWidth().background(CARD, sh).border(1.dp, BD, sh).padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Ico(4, Color(0xFF4F8FE0))
            T(if (ver.isEmpty()) "Belum ada config" else ver, 14, TX, true, Modifier.weight(1f), 1)
            T(if (ver.isEmpty()) "Impor ›" else "Ganti ›", 14, PINK, true, Modifier.clickable { if (ver.isEmpty()) picker.launch(mimes) else showVer = true })
        }
        // Mode (Flagship / Balanced), hanya jika zip memilikinya
        if (modes.any { it.isNotEmpty() }) Row(Modifier.fillMaxWidth().background(CARD, sh).border(1.dp, BD, sh).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Ico(1, AC); T("Mode", 14, TX, true); Spacer(Modifier.weight(1f))
            modes.filter { it.isNotEmpty() }.forEach { m -> QChip(m, m == mode) { Store.wuMode = m; Store.wuTier = 0 } }
        }
        // Kualitas (tingkat dari zip)
        Row(Modifier.fillMaxWidth().background(CARD, sh).border(1.dp, BD, sh).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Ico(5, Color(0xFFE0B040)); T("Kualitas", 14, TX, true)
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End)) {
                if (tiers.isEmpty()) T("-", 14, MUT)
                tiers.forEachIndexed { i, t -> QChip(t.label, i == ti) { Store.wuTier = i } }
            }
        }
        // Install
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF5B9BDC), VIOLET, PINK)))
            .clickable {
                when {
                    Report.busy -> {}
                    tiers.isEmpty() -> Report.fail("Gagal memasang config", "Belum ada config. Ketuk Impor lalu pilih zip.")
                    pkg == null -> Report.fail("Gagal memasang config", "Wuthering Waves tidak ditemukan.")
                    Shell.mode() == "-" -> Report.fail("Gagal memasang config", "Akses belum aktif. Buka tab Settings lalu pilih Shizuku atau Root.")
                    else -> scope.launch {
                        val t = tiers[ti]
                        val label = listOf(ver, mode, t.label).filter { it.isNotEmpty() }.joinToString(" · ")
                        Report.begin("install", "Memasang config…", t.files.keys.filter { !it.equals("AndroidEngine.ini", true) })
                        Report.addLog("Mulai pasang: $label | akses=${Shell.mode()} | paket=$pkg")
                        val err = withContext(Dispatchers.IO) { WuWa.installFiles(pkg, t.files) }
                        val rows = withContext(Dispatchers.IO) { WuWa.verify(pkg, t.files) }
                        rows.forEach { Report.addLog("${it.name}: ${if (it.state == 1) "OK" else it.note}") }
                        if (err != null) Report.addLog("GAGAL: $err")
                        val allOk = err == null && rows.all { it.state == 1 }
                        if (allOk) {
                            Store.configured[p.key] = label; Store.installs++; Store.last = "${p.name} · $label"
                            Report.end("install", true, "Config berhasil terpasang", label + " · " + Report.fmtTime(System.currentTimeMillis()), rows)
                        } else Report.end("install", false,
                            if (err != null) "Gagal memasang config" else "Config belum sepenuhnya terpasang",
                            err ?: "Ada file yang tidak sesuai di folder game.", rows)
                    }
                }
            }.padding(vertical = 16.dp), contentAlignment = Alignment.Center) { T("Install", 20, Color.White, true) }
        ResultBox()
        if (msg.isNotEmpty()) T(msg, 13, MUT)
        T(if (open) "Detail ▾" else "Detail ›", 14, MUT, true, Modifier.clickable { open = !open }.padding(vertical = 8.dp))
        if (open) {
            T("Paket game: ${pkg ?: "tidak terdeteksi"}", 13, MUT)
            if (tiers.isNotEmpty()) T("File di tingkat ini: ${tiers[ti].files.keys.filter { !it.equals("AndroidEngine.ini", true) }.joinToString(", ")}", 13, MUT)
            Box(Modifier.fillMaxWidth().border(1.dp, BD, RoundedCornerShape(16.dp)).clickable {
                when {
                    Report.busy -> {}
                    pkg == null -> Report.fail("Gagal cek status", "Wuthering Waves tidak ditemukan.")
                    Shell.mode() == "-" -> Report.fail("Gagal cek status", "Akses belum aktif. Buka tab Settings.")
                    else -> scope.launch {
                        Report.begin("check", "Memeriksa file…", WuWa.SHOWN)
                        val rows = withContext(Dispatchers.IO) { WuWa.inspect(pkg) }
                        if (rows == null) Report.end("check", false, "Gagal membaca folder game", "Cek akses Shizuku atau Root.", emptyList())
                        else {
                            val good = rows.none { it.state == 2 }
                            rows.forEach { Report.addLog("Cek ${it.name}: ${it.note.ifEmpty { "OK" }}") }
                            Report.end("check", good, if (good) "Config terdeteksi" else "Config belum lengkap atau bermasalah", Report.fmtTime(System.currentTimeMillis()), rows)
                        }
                    }
                }
            }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) { T("Cek status", 14, TX, true) }
            Box(Modifier.fillMaxWidth().border(1.dp, BD, RoundedCornerShape(16.dp)).clickable {
                when {
                    Report.busy -> {}
                    pkg == null -> Report.fail("Gagal menghapus config", "Wuthering Waves tidak ditemukan.")
                    Shell.mode() == "-" -> Report.fail("Gagal menghapus config", "Akses belum aktif. Buka tab Settings.")
                    else -> scope.launch {
                        Report.begin("delete", "Menghapus config…", WuWa.REMOVABLE)
                        val err = withContext(Dispatchers.IO) { WuWa.delete(pkg, WuWa.REMOVABLE) }
                        if (err == null) {
                            Store.configured.remove(p.key); Report.addLog("Config dihapus")
                            Report.end("delete", true, "Config dihapus", Report.fmtTime(System.currentTimeMillis()), WuWa.REMOVABLE.map { FileRow(it, 1) })
                        } else { Report.addLog("GAGAL hapus: $err"); Report.end("delete", false, "Gagal menghapus config", err, WuWa.REMOVABLE.map { FileRow(it, 2) }) }
                    }
                }
            }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) { T("Hapus config", 14, PINK, true) }
        }
    }

    if (showVer) AlertDialog(
        onDismissRequest = { showVer = false }, containerColor = CARD,
        title = { Text("Versi config", color = TX) },
        text = {
            Column {
                versions.forEach { v ->
                    Row(Modifier.fillMaxWidth().clickable { Store.wuVersion = v; Store.wuTier = 0; showVer = false }.padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween) {
                        T(v, 15, if (v == ver) AC else TX, true)
                        T("Hapus", 13, PINK, false, Modifier.clickable { WuZip.delete(ctx, v); versions = WuZip.versions(ctx) })
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showVer = false; picker.launch(mimes) }) { Text("Impor zip") } },
        dismissButton = { TextButton(onClick = { showVer = false }) { Text("Tutup") } }
    )
}
