package com.nexnon.engine

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.SystemClock
import java.io.File

/** Satu pembacaan baterai langsung. Nilai yang tidak terbaca = -1. [src] menjelaskan dari mana arus dan tegangan dibaca. */
class BatLive(
    val pct: Int, val plugged: Boolean, val charging: Boolean, val full: Boolean,
    val mA: Float, val mV: Float, val watt: Float, val tempC: Float, val src: String
) {
    val statusText: String get() = when {
        !plugged -> "Tidak mengisi"
        full -> "Penuh"
        charging -> "Mengisi daya"
        else -> "Terhubung, tidak mengisi"
    }
}

/**
 * Pembacaan baterai realtime untuk tab Baterai.
 *  - Level: properti CAPACITY dari BatteryManager (dibaca langsung dari layanan baterai), broadcast hanya cadangan.
 *  - Arus, tegangan, suhu: file `uevent` baterai dibaca langsung (satu pembacaan = arus dan tegangan dari saat yang sama,
 *    seperti Scene), lalu file tunggal (current_now / voltage_now) sebagai cadangan. Bila tidak boleh dibaca aplikasi biasa,
 *    dibaca lewat Shizuku/root di thread terpisah, dan terakhir BatteryManager.
 *  - Satuan arus (uA atau mA) ditebak dari besarnya, lalu dikunci begitu terbukti uA supaya arus kecil
 *    (mis. 15.000 uA = 15 mA saat layar mati) tidak salah terbaca sebagai 15.000 mA.
 *  - Jalur langsung yang gagal dicoba lagi tiap 10 detik (bukan dimatikan selamanya).
 * Tidak ada perataan: angka yang tampil adalah pembacaan saat itu, dan tanda arus ditentukan dari status mengisi
 * (tanda positif/negatif di sysfs berbeda-beda antar HP).
 */
object BatteryLive {
    private val CUR = listOf("/sys/class/power_supply/battery/current_now", "/sys/class/power_supply/bms/current_now")
    private val VOL = listOf(
        "/sys/class/power_supply/battery/voltage_now", "/sys/class/power_supply/bms/voltage_now",
        "/sys/devices/platform/soc/soc:oplus,mms_gauge/oplus_mms/gauge/battery/voltage_now"   // OPlus/Realme/OnePlus (sama seperti Scene)
    )
    private val UEV = listOf("/sys/class/power_supply/battery/uevent", "/sys/class/power_supply/bms/uevent")

    // Cadangan lewat Shizuku/root: dibaca di thread lain, hasilnya dipakai pada pembacaan berikutnya
    @Volatile private var shCur = Long.MIN_VALUE
    @Volatile private var shVol = 0L
    @Volatile private var shAt = -100_000L
    @Volatile private var shBusy = false
    private var directOk = true
    private var directFailAt = -100_000L
    // Satuan arus terkunci ke uA setelah pernah terlihat nilai di atas 20.000 (terpisah untuk file sistem dan API)
    @Volatile private var microSys = false
    @Volatile private var microApi = false

    private fun readLong(path: String): Long? = runCatching { File(path).readText().trim().toLong() }.getOrNull()

    /** Isi file uevent -> peta KUNCI (tanpa awalan POWER_SUPPLY_) ke angka. Baris non-angka dilewati. */
    internal fun parseUevent(text: String): Map<String, Long> {
        val m = HashMap<String, Long>()
        for (l in text.lineSequence()) {
            val k = l.substringBefore('=', "").trim()
            if (k.isEmpty()) continue
            val v = l.substringAfter('=', "").trim().toLongOrNull() ?: continue
            m.putIfAbsent(k.removePrefix("POWER_SUPPLY_"), v)
        }
        return m
    }

    private fun readUevent(): Map<String, Long> {
        val m = HashMap<String, Long>()
        for (p in UEV) runCatching { File(p).readText() }.getOrNull()?.let { t -> parseUevent(t).forEach { (k, v) -> m.putIfAbsent(k, v) } }
        return m
    }

    /** Arus (mA, selalu positif) dari mentahan: di atas 20.000 dianggap uA (dan dikunci), selain itu mA. */
    private fun toMa(raw: Long, api: Boolean): Float {
        val a = Math.abs(raw)
        if (a > 20_000L) { if (api) microApi = true else microSys = true }
        return if (if (api) microApi else microSys) a / 1000f else a.toFloat()
    }

    /** Tegangan (mV) dari mentahan sysfs: di atas 100.000 dianggap uV, selain itu mV. */
    private fun toMv(raw: Long): Float = if (raw > 100_000L) raw / 1000f else raw.toFloat()

    private fun shellRefresh() {
        val now = SystemClock.elapsedRealtime()
        if (shBusy || now - shAt < 1000L) return
        if (runCatching { Shell.mode() }.getOrDefault("-") == "-") return
        shBusy = true; shAt = now
        Thread {
            try {
                // Pemisah "|" (bukan ":") karena salah satu jalur memuat tanda ":" (soc:oplus,mms_gauge)
                val cmd = "for f in ${CUR.joinToString(" ")} ${VOL.joinToString(" ")}; do echo \"\$f|\$(cat \$f 2>/dev/null)\"; done; " +
                    "cat ${UEV.joinToString(" ")} 2>/dev/null"
                val out = Shell.exec(cmd)
                val m = HashMap<String, Long>()
                for (l in out.lines()) {
                    if (!l.contains('|')) continue
                    val v = l.substringAfter('|', "").trim().toLongOrNull() ?: continue
                    m[l.substringBefore('|').trim()] = v
                }
                val ev = parseUevent(out)
                shCur = CUR.firstNotNullOfOrNull { m[it] } ?: ev["CURRENT_NOW"] ?: Long.MIN_VALUE
                shVol = VOL.firstNotNullOfOrNull { m[it]?.takeIf { v -> v > 0L } } ?: ev["VOLTAGE_NOW"]?.takeIf { it > 0L } ?: 0L
            } catch (_: Throwable) {
            } finally { shBusy = false }
        }.apply { name = "bat-live-sh"; isDaemon = true }.start()
    }

    fun read(c: Context): BatLive {
        val ctx = c.applicationContext
        val i = runCatching { ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) }.getOrNull()
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager

        // Level: langsung dari layanan baterai
        val apiPct = runCatching { bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) }.getOrNull() ?: -1
        val pct = if (apiPct in 0..100) apiPct else {
            val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            if (l >= 0 && sc > 0) Math.round(l * 100f / sc) else -1
        }
        val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN) ?: BatteryManager.BATTERY_STATUS_UNKNOWN
        val plugged = (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        val charging = plugged && st == BatteryManager.BATTERY_STATUS_CHARGING
        val full = plugged && st == BatteryManager.BATTERY_STATUS_FULL

        // Arus dan tegangan
        var mA = -1f; var mV = -1f; var src = "-"
        var tUev = -1f
        val nowMs = SystemClock.elapsedRealtime()
        if (directOk || nowMs - directFailAt >= 10_000L) {
            val ev = readUevent()
            val cur = ev["CURRENT_NOW"] ?: CUR.firstNotNullOfOrNull { readLong(it) }
            val vol = ev["VOLTAGE_NOW"]?.takeIf { it > 0L } ?: VOL.firstNotNullOfOrNull { readLong(it)?.takeIf { v -> v > 0L } }
            if (cur != null) { mA = toMa(cur, false); src = "sysfs"; directOk = true } else { directOk = false; directFailAt = nowMs }
            if (vol != null) mV = toMv(vol)
            ev["TEMP"]?.let { t -> tUev = Math.floor(t / 10.0).toFloat().takeIf { it in 1f..100f } ?: -1f }
        }
        if (src == "-") {
            shellRefresh()
            if (shCur != Long.MIN_VALUE) { mA = toMa(shCur, false); src = "shell"; if (shVol > 0L) mV = toMv(shVol) }
        }
        if (src == "-") {
            val raw = runCatching { bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) }.getOrNull() ?: 0
            if (raw != 0 && raw != Int.MIN_VALUE) { mA = toMa(raw.toLong(), true); src = "api" }
        }
        if (mV <= 0f) mV = (i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0).toFloat().takeIf { it > 0f } ?: -1f
        val watt = if (mA >= 0f && mV > 0f) (mA * mV / 1e6f).takeIf { it in 0f..300f } ?: -1f else -1f

        // Suhu: file sistem (segar) dulu, lalu uevent, broadcast sebagai cadangan terakhir
        val tRaw = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val tIntent = if (tRaw != Int.MIN_VALUE) (tRaw / 10).toFloat() else -1f
        val temp = BatteryStats.freshTemp().takeIf { it > 0f } ?: tUev.takeIf { it > 0f } ?: tIntent.takeIf { it in 1f..100f } ?: -1f

        return BatLive(pct, plugged, charging, full, mA, mV, watt, temp, src)
    }
}


/** Kesehatan baterai: [pct] = kapasitas penuh dibanding desain (-1 bila tidak terbaca), [cycles] = jumlah siklus (-1 bila tidak terbaca). */
class BatHealth(val pct: Float, val fullMah: Float, val designMah: Float, val cycles: Int, val estimated: Boolean = false) {
    val hasHealth: Boolean get() = pct >= 0f
}

/**
 * Pembacaan kesehatan dan siklus baterai, sumbernya sama seperti Scene: `uevent` (CHARGE_FULL, CHARGE_FULL_DESIGN,
 * CYCLE_COUNT), lalu file tunggal dan jalur vendor (MTK, Qualcomm, OPlus). Bila aplikasi biasa tidak boleh membaca,
 * dibaca lewat Shizuku/root. Berubah sangat pelan, jadi cukup dibaca tiap puluhan detik.
 */
object BatteryHealthReader {
    private val UEV = listOf("/sys/class/power_supply/battery/uevent", "/sys/class/power_supply/bms/uevent")
    private val FULL = listOf("/sys/class/power_supply/battery/charge_full", "/sys/class/power_supply/bms/charge_full")
    private val DESIGN = listOf("/sys/class/power_supply/battery/charge_full_design", "/sys/class/power_supply/bms/charge_full_design")
    private val CYC = listOf(
        "/sys/class/power_supply/battery/cycle_count", "/sys/class/power_supply/bms/cycle_count",
        "/sys/class/power_supply/mtk-battery/cycle_count", "/sys/class/qcom-battery/fg1_cycle",
        "/sys/class/oplus_chg/battery/battery_cc"
    )

    /** Mentahan di atas 100.000 dianggap uAh, selain itu mAh. */
    private fun mah(raw: Long): Float = if (raw > 100_000L) raw / 1000f else raw.toFloat()

    private fun readLong(path: String): Long? = runCatching { java.io.File(path).readText().trim().toLong() }.getOrNull()

    private fun build(full: Long?, design: Long?, cyc: Long?): BatHealth {
        val f = full?.takeIf { it > 0L }?.let { mah(it) } ?: -1f
        val d = design?.takeIf { it > 0L }?.let { mah(it) } ?: -1f
        val pct = if (f > 0f && d > 0f) (f / d * 100f).takeIf { it in 30f..130f }?.coerceAtMost(100f) ?: -1f else -1f
        return BatHealth(pct, f, d, cyc?.takeIf { it in 0L..20_000L }?.toInt() ?: -1)
    }

    @Volatile private var profileMah = Float.NaN

    /** Kapasitas desain (mAh) dari profil daya Android (dibaca lewat refleksi; -1 bila diblokir). */
    private fun profileDesignMah(ctx: Context): Float {
        if (!profileMah.isNaN()) return profileMah
        profileMah = runCatching {
            val cls = Class.forName("com.android.internal.os.PowerProfile")
            val o = cls.getConstructor(Context::class.java).newInstance(ctx)
            (cls.getMethod("getBatteryCapacity").invoke(o) as Number).toFloat().takeIf { it > 500f } ?: -1f
        }.getOrDefault(-1f)
        return profileMah
    }

    fun read(c: Context): BatHealth {
        val ctx = c.applicationContext
        val ev = HashMap<String, Long>()
        for (p in UEV) runCatching { java.io.File(p).readText() }.getOrNull()?.let { t ->
            BatteryLive.parseUevent(t).forEach { (k, v) -> ev.putIfAbsent(k, v) }
        }
        var full = ev["CHARGE_FULL"] ?: FULL.firstNotNullOfOrNull { readLong(it) }
        var design = ev["CHARGE_FULL_DESIGN"] ?: DESIGN.firstNotNullOfOrNull { readLong(it) }
        var cyc = ev["CYCLE_COUNT"] ?: CYC.firstNotNullOfOrNull { readLong(it) }
        if ((full == null || design == null || cyc == null) && runCatching { Shell.mode() }.getOrDefault("-") != "-") {
            runCatching {
                val out = Shell.exec("cat ${UEV.joinToString(" ")} 2>/dev/null; for f in ${(FULL + DESIGN + CYC).joinToString(" ")}; do echo \"\$f|\$(cat \$f 2>/dev/null)\"; done")
                val m = HashMap<String, Long>()
                for (l in out.lines()) {
                    if (!l.contains('|')) continue
                    val v = l.substringAfter('|', "").trim().toLongOrNull() ?: continue
                    m[l.substringBefore('|').trim()] = v
                }
                val e2 = BatteryLive.parseUevent(out)
                if (full == null) full = e2["CHARGE_FULL"] ?: FULL.firstNotNullOfOrNull { m[it] }
                if (design == null) design = e2["CHARGE_FULL_DESIGN"] ?: DESIGN.firstNotNullOfOrNull { m[it] }
                if (cyc == null) cyc = e2["CYCLE_COUNT"] ?: CYC.firstNotNullOfOrNull { m[it] }
            }
        }

        // Cadangan dari Android sendiri, supaya HP yang file sistemnya terkunci tetap terbaca
        val intent = runCatching { ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) }.getOrNull()
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val sdk = android.os.Build.VERSION.SDK_INT
        if (cyc == null && sdk >= 34) {
            val v = intent?.getIntExtra("android.os.extra.CYCLE_COUNT", -1) ?: -1   // EXTRA_CYCLE_COUNT (Android 14+)
            if (v >= 0) cyc = v.toLong()
        }
        if (cyc == null && runCatching { Shell.mode() }.getOrDefault("-") != "-") {
            cyc = runCatching {
                Regex("cycle[ _]?count\\D{0,6}(\\d+)", RegexOption.IGNORE_CASE).find(Shell.exec("dumpsys battery"))?.groupValues?.get(1)?.toLong()
            }.getOrNull()
        }
        val h = build(full, design, cyc)
        if (h.hasHealth) return h

        if (sdk >= 34) {
            val soh = runCatching { bm?.getIntProperty(10) }.getOrNull() ?: 0   // BATTERY_PROPERTY_STATE_OF_HEALTH (Android 14+)
            if (soh in 1..100) return BatHealth(soh.toFloat(), h.fullMah, h.designMah, h.cycles)
        }
        // Perkiraan: kapasitas penuh dari charge counter dan level, dibanding kapasitas desain
        val designEst = h.designMah.takeIf { it > 0f } ?: profileDesignMah(ctx)
        val counter = runCatching { bm?.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) }.getOrNull() ?: 0L
        val level = runCatching { bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) }.getOrNull() ?: -1
        if (designEst > 0f && counter > 0L && counter != Long.MIN_VALUE && level in 30..100) {
            val fullEst = counter / 1000f * 100f / level
            val pct = (fullEst / designEst * 100f).takeIf { it in 40f..110f }?.coerceAtMost(100f)
            if (pct != null) return BatHealth(pct, fullEst, designEst, h.cycles, estimated = true)
        }
        return h
    }
}
