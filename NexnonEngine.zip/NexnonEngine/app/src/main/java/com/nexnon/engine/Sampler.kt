package com.nexnon.engine

import android.content.Context
import android.os.SystemClock
import kotlinx.coroutines.*

/** Satu pembacaan (kira-kira per detik). ftN/ftMaxMs/jank/bigJank/ftTop berasal dari timestamp frame asli (--latency), hanya terisi saat merekam. */
class Snap(
    val fps: Float, val pkg: String,
    val ftN: Int = 0, val ftMaxMs: Float = 0f, val jank: Int = 0, val bigJank: Int = 0, val ftTop: List<Float> = emptyList()
)

/**
 * Pengukur FPS game sungguhan (bukan layar app ini), diambil dari Pulse Monitor dan diringkas:
 *  1. Paket di depan: riwayat penggunaan (cepat) atau dumpsys window.
 *  2. FPS: TaskFps (Android 14+, daemon hak shell) -> cadangan SurfaceFlinger timestats -> cadangan --latency.
 *  3. Frametime asli per frame (--latency) saat merekam, untuk 5% / 1% low, Jank, BigJank.
 * Butuh Shizuku atau Root.
 */
object Sampler {
    private val TRANSIENT_PKGS = setOf("com.android.systemui", "android", "com.miui.screenrecorder", "com.miui.securitycenter", "com.miui.gamebooster")
    // Aplikasi live streaming: widget mengambangnya bisa merebut fokus dari game yang sedang disiarkan
    private val STREAM_PKGS = setOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.ss.android.ugc.aweme",
        "tv.twitch.android.app", "com.facebook.gamingvideo", "com.streamlabs.goliveandroid", "com.kick.mobile")
    private val SKIP_PKGS = TRANSIENT_PKGS + STREAM_PKGS

    /** Bukan target pengukuran: SystemUI, keyboard, perekam layar, Game Turbo, app ini sendiri. */
    fun isIgnoredPkg(p: String, own: String) = p.isEmpty() || p == own || p in SKIP_PKGS ||
        p.contains("inputmethod") || p.contains("screenrecord") || p.contains("gamebooster") ||
        p.startsWith("com.ss.android.ugc.") || p.contains("tiktok", ignoreCase = true)

    /** Khusus nama di notifikasi: hanya jendela sementara yang dilewati. */
    fun isTransientPkg(p: String, own: String) = p.isEmpty() || p == own || p in TRANSIENT_PKGS ||
        p.contains("inputmethod") || p.contains("screenrecord") || p.contains("gamebooster")

    @Volatile private var appCtx: Context? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null

    /** Paket yang dikunci selama merekam. */
    @Volatile var pinPkg: String? = null
    @Volatile var fpsDbg = ""
    @Volatile private var lastGame = ""
    private var lastGameAt = 0L
    private var pinZero = 0

    fun lastGamePkg(): String = lastGame
    fun fpsDiag(): String = "paket terkunci: ${pinPkg ?: "-"} | $fpsDbg | ${TaskFps.diag()}"

    fun running() = job?.isActive == true

    fun start(ctx: Context) {
        appCtx = ctx.applicationContext
        if (job?.isActive == true) return
        TaskFps.start(ctx)
        job = scope.launch {
            while (isActive) {
                // Jadwal tetap ~1 detik: lama tick dikurangkan dari jeda supaya sampel tidak melambat
                val t0 = SystemClock.elapsedRealtime()
                runCatching { tick() }.onFailure { AppLog.w("Sampler", "tick gagal: ${it.javaClass.simpleName} ${it.message}") }
                delay((1000L - (SystemClock.elapsedRealtime() - t0)).coerceAtLeast(200L))
            }
        }
    }

    fun stop() {
        job?.cancel(); job = null
        TaskFps.stop()
        tsReady = false; tsWin.clear(); ftReset()
        pinPkg = null; pinZero = 0
    }

    /** Dipanggil tepat sebelum Recorder.start(): baca ulang fokus supaya game langsung terkunci. */
    fun onRecordStart() { focusAt = -10_000L; pinPkg = null; pinZero = 0; ftReset() }

    // ---------- Paket di depan ----------
    private var focusCache = ""; private var focusAt = -10_000L
    private val FOCUS_RX = Regex("u\\d+ ([\\w.]+)/")

    private fun pkgsIn(out: String, only: String? = null): List<String> =
        out.lines().filter { !it.contains("=null") && (only == null || it.contains(only)) }
            .mapNotNull { FOCUS_RX.find(it)?.groupValues?.get(1) }

    /** Paket di depan lewat dumpsys (lambat, panggil dari thread latar). forLabel: untuk nama di notifikasi. */
    private fun focusPkg(forLabel: Boolean = false): String? {
        val own = if (forLabel) "" else (appCtx?.packageName ?: "")
        val win = Shell.execLimited("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -8", 2500L)
        val cand = if (forLabel) pkgsIn(win, "mFocusedApp") + pkgsIn(win, "mCurrentFocus") else pkgsIn(win)
        val skip: (String) -> Boolean = if (forLabel) { p -> isTransientPkg(p, own) } else { p -> isIgnoredPkg(p, own) }
        cand.firstOrNull { !skip(it) }?.let { return it }
        val act = pkgsIn(Shell.execLimited("dumpsys activity activities | grep -E 'topResumedActivity|ResumedActivity' | head -4", 2500L))
        act.firstOrNull { !skip(it) }?.let { return it }
        return cand.firstOrNull() ?: act.firstOrNull()
    }

    /** Nama paket untuk notifikasi: riwayat penggunaan bila izin ada, kalau tidak dumpsys. Thread latar. */
    fun foregroundPkg(): String {
        val c = appCtx
        if (c != null && Foreground.hasAccess(c)) Foreground.top(c)?.let { return it }
        return focusPkg(forLabel = true).orEmpty()
    }

    private fun quickTop(): String? {
        val c = appCtx
        if (c != null && Foreground.hasAccess(c)) Foreground.top(c)?.let { return it }
        return focusPkg()
    }

    /** Paket yang diukur. Fokus sementara (SystemUI / keyboard / app ini) diabaikan 20 detik setelah game terakhir di depan; saat merekam dikunci. */
    private fun targetPkg(): String? {
        pinPkg?.let { lastGame = it; return it }
        val now = SystemClock.elapsedRealtime()
        if (now - focusAt >= 2000L) { focusCache = quickTop() ?: ""; focusAt = now }
        val p = focusCache
        if (!isIgnoredPkg(p, appCtx?.packageName ?: "")) { lastGame = p; lastGameAt = now; return p }
        if (lastGame.isNotEmpty() && now - lastGameAt < 20_000L) return lastGame
        return p.ifEmpty { null }
    }

    // ---------- Tick ----------
    private fun tick() {
        if (Shell.mode() == "-") { fpsDbg = "tidak ada akses Shizuku/Root"; return }
        val own = appCtx?.packageName ?: ""
        val pkg = targetPkg()
        if (pkg == null || isIgnoredPkg(pkg, own)) { fpsDbg = "aplikasi fokus tidak terbaca"; return }
        TaskFps.track(pkg)
        val sys = TaskFps.read(pkg)
        val fps: Float = when {
            sys == null -> legacy(pkg)
            sys < 0.5f -> legacy(pkg).let { if (it >= 5f) it else sys }   // sistem melapor 0 tapi timestats melihat game menggambar
            else -> sys
        }
        if (fps < 0f) return    // gagal ukur sesaat bukan 0 FPS

        val rec = Recorder.active
        if (rec && pinPkg == null && fps > 0f) pinPkg = pkg
        if (rec && pinPkg != null) {
            // Terkunci ke paket yang terus 0 FPS ~8 detik (salah kunci di awal): lepas, deteksi ulang
            if (fps > 0f) pinZero = 0 else if (++pinZero >= 8) { pinZero = 0; pinPkg = null; focusAt = -10_000L; ftReset() }
        }
        val ft = if (rec) runCatching { frameStats(pkg) }.getOrNull() else null
        val snap = Snap(fps, pkg, ft?.n ?: 0, ft?.maxMs ?: 0f, ft?.jank ?: 0, ft?.bigJank ?: 0, ft?.top ?: emptyList())
        Recorder.onSample(snap)
    }

    // ---------- Cadangan: SurfaceFlinger timestats ----------
    private class Ts(val at: Long, val total: Map<String, Long>, val queued: Map<String, Long>)
    private val tsWin = ArrayDeque<Ts>()
    private var tsReady = false
    private var tsEmpty = 0
    private var tsClearAt = -100_000L
    private const val TS_SOFT_LIMIT = 150

    private fun timestats(): Ts {
        if (!tsReady) {
            Shell.exec("dumpsys SurfaceFlinger --timestats -clear -enable"); tsReady = true; tsWin.clear()
            tsClearAt = SystemClock.elapsedRealtime()
        }
        val t0 = SystemClock.elapsedRealtime()
        val txt = Shell.exec("dumpsys SurfaceFlinger --timestats -dump")
        val at = (t0 + SystemClock.elapsedRealtime()) / 2
        val total = HashMap<String, Long>(); val queued = HashMap<String, Long>()
        var name: String? = null
        var nLayers = 0
        for (l in txt.lines()) {
            val t = l.trim()
            val v = t.substringAfter('=', "").trim().toLongOrNull()
            when {
                t.startsWith("layerName") -> { name = t.substringAfter('=').trim(); nLayers++ }
                name != null && v != null && t.startsWith("totalFrames") -> { total[name!!] = v; queued[name!!] = (queued[name!!] ?: 0L) + v }
                name != null && v != null && t.startsWith("droppedFrames") -> queued[name!!] = (queued[name!!] ?: 0L) + v
            }
        }
        if (total.isEmpty()) { if (++tsEmpty >= 3) { tsReady = false; tsEmpty = 0 } } else tsEmpty = 0
        // Tabel timestats ~200 layer: reset sebelum penuh supaya layer game yang dibuat ulang tetap tercatat
        if (nLayers >= TS_SOFT_LIMIT && SystemClock.elapsedRealtime() - tsClearAt > 20_000L) tsReady = false
        return Ts(at, total, queued)
    }

    /** FPS = frame yang benar-benar tampil (totalFrames) dari layer [pkg], jendela ~2,5 detik. -1 = gagal ukur. */
    private fun legacy(pkg: String): Float {
        val cur = timestats()
        if (cur.total.isEmpty() && tsWin.isNotEmpty()) { fpsDbg = "dump timestats kosong"; return -1f }
        tsWin.addLast(cur)
        while (tsWin.size > 1 && cur.at - tsWin.first().at > 2500L) tsWin.removeFirst()
        val cand = cur.total.keys.filter { it.contains(pkg) }
        if (cand.isEmpty()) {
            val lat = fpsLatency(pkg)
            fpsDbg = "timestats: $pkg tidak ada -> latency: $fpsDbg"
            return if (lat > 0f) lat else -1f
        }
        var bestP = 0f; var bestQ = 0f; var valid = false; var reset = false; var pending = false
        for (k in cand) {
            val p1 = cur.total[k] ?: continue; val q1 = cur.queued[k] ?: continue
            // Pembanding PER LAYER: sampel tertua di jendela yang sudah memuat layer ini
            var b: Ts? = null
            for (w in tsWin) if (w !== cur && w.total.containsKey(k) && w.queued.containsKey(k)) { b = w; break }
            val d = if (b == null) 0f else (cur.at - b.at) / 1000f
            if (b == null || d < 0.8f) { pending = true; continue }
            val p0 = b.total[k] ?: continue; val q0 = b.queued[k] ?: continue
            if (p1 >= p0 && q1 >= q0) { valid = true; bestP = maxOf(bestP, (p1 - p0) / d); bestQ = maxOf(bestQ, (q1 - q0) / d) }
            else reset = true
        }
        if (reset) { tsWin.clear(); tsWin.addLast(cur) }
        fpsDbg = "$pkg | ${cand.size} layer | tampil %.0f, diserahkan %.0f".format(bestP, bestQ)
        if (!valid) return -1f
        if (bestQ < 0.5f && (pending || reset)) return -1f
        if (bestP < 0.5f && bestQ >= 5f) return bestQ   // Android 16: frame dihitung sebagai dropped
        if (bestQ < 0.5f) {
            val now = fpsLatency(pkg)
            if (now > 0f) return now
        }
        return minOf(bestP, bestQ)
    }

    // ---------- Layer SurfaceFlinger + frametime asli (--latency) ----------
    /** Android 15/16 mencetak `--list` sebagai "RequestedLayerState{nama#id ...}"; namanya diambil sampai "#id". */
    private val LAYER_LINE = Regex("^RequestedLayerState\\{(.*?#\\d+)(?=[ }]|$)")
    private fun liveLayers(pkg: String): List<String> =
        Shell.exec("dumpsys SurfaceFlinger --list").lines().mapNotNull { raw ->
            val l = raw.trim()
            if (!l.contains(pkg)) return@mapNotNull null
            val n: String? = if (l.startsWith("RequestedLayerState{")) LAYER_LINE.find(l)?.groupValues?.get(1) else l
            n?.takeIf { !it.startsWith("Background") && !it.startsWith("ActivityRecord{") && !it.startsWith("Task=") }
        }.distinct()

    private fun fpsLatency(pkg: String): Float {
        val all = liveLayers(pkg)
        if (all.isEmpty()) { fpsDbg = "$pkg: layer tidak ditemukan"; return 0f }
        val ordered = all.sortedByDescending { (if (it.contains("SurfaceView")) 2 else 0) + (if (it.contains("BLAST")) 1 else 0) }
        for (layer in ordered.take(4)) {
            val rows = Shell.exec("dumpsys SurfaceFlinger --latency '$layer'").lines().drop(1).map { it.trim().split(Regex("\\s+")) }
            for (col in intArrayOf(1, 2)) {
                val ts = rows.mapNotNull { it.getOrNull(col)?.toLongOrNull() }.filter { it in 1 until Long.MAX_VALUE / 2 }.sorted()
                if (ts.size < 3) continue
                val recent = ts.filter { it >= ts.last() - 1_000_000_000L }
                if (recent.size < 2 || recent.last() == recent.first()) continue
                fpsDbg = "$pkg | ${layer.take(36)} | ${ts.size} frame, kolom $col"
                return ((recent.size - 1) * 1e9 / (recent.last() - recent.first())).toFloat()
            }
        }
        fpsDbg = "$pkg: ${ordered.size} layer, data latency kosong"
        return 0f
    }

    private class Ft(val n: Int, val maxMs: Float, val jank: Int, val bigJank: Int, val top: List<Float>)
    private var ftLayer = ""; private var ftLayerLast = ""; private var ftPkg = ""; private var ftLayerAt = -100_000L
    private var ftLastTs = 0L
    private val ftPrev = ArrayDeque<Float>()
    private fun ftReset() { ftLayer = ""; ftLayerLast = ""; ftPkg = ""; ftLastTs = 0L; ftPrev.clear() }

    /**
     * Frametime tiap frame BARU sejak tick sebelumnya. Hasil: jumlah frame, frametime terburuk (12 teratas, untuk 5% / 1% low sungguhan),
     * Jank = frametime > 2x rata-rata 3 frame sebelumnya DAN > 83,3 ms; BigJank = > 3x DAN > 125 ms (definisi PerfDog).
     */
    private fun frameStats(pkg: String): Ft? {
        val now = SystemClock.elapsedRealtime()
        if (pkg != ftPkg) { ftReset(); ftPkg = pkg }
        if (ftLayer.isEmpty() && now - ftLayerAt > 3000L) {
            ftLayerAt = now
            val l = liveLayers(pkg).sortedByDescending { (if (it.contains("SurfaceView")) 2 else 0) + (if (it.contains("BLAST")) 1 else 0) }.firstOrNull() ?: ""
            if (l != ftLayerLast) { ftLastTs = 0L; ftPrev.clear() }
            ftLayer = l; ftLayerLast = l
        }
        if (ftLayer.isEmpty()) return null
        val rows = Shell.exec("dumpsys SurfaceFlinger --latency '$ftLayer'").lines().drop(1).map { it.trim().split(Regex("\\s+")) }
        fun col(c: Int) = rows.mapNotNull { it.getOrNull(c)?.toLongOrNull() }.filter { it in 1 until Long.MAX_VALUE / 2 }.sorted()
        var ts = col(1)
        if (ts.size < 3) ts = col(2)
        if (ts.isEmpty()) { ftLayer = ""; return null }
        if (ftLastTs == 0L) { ftLastTs = ts.last(); return null }
        val fresh = ts.filter { it > ftLastTs }
        if (fresh.isEmpty()) return Ft(0, 0f, 0, 0, emptyList())
        val seq = ArrayList<Long>(fresh.size + 1); seq.add(ftLastTs); seq.addAll(fresh)
        ftLastTs = fresh.last()
        var jank = 0; var big = 0; var mx = 0f; var n = 0
        val d = ArrayList<Float>()
        for (i in 1 until seq.size) {
            val ms = (seq[i] - seq[i - 1]) / 1e6f
            if (ms <= 0f) continue
            if (ms > 2000f) { ftPrev.clear(); continue }   // jeda > 2 detik = loading / layar diam, bukan lag
            n++; d.add(ms); mx = maxOf(mx, ms)
            if (ftPrev.size == 3) {
                val avgPrev = ftPrev.average().toFloat()
                if (ms > 125f && ms > 3f * avgPrev) big++
                else if (ms > 83.33f && ms > 2f * avgPrev) jank++
            }
            ftPrev.addLast(ms); if (ftPrev.size > 3) ftPrev.removeFirst()
        }
        return Ft(n, mx, jank, big, d.sortedDescending().take(12))
    }
}
