package com.nexnon.engine

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.SystemClock
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

/** Satu pembacaan (kira-kira per detik). ftN/ftMaxMs/jank/bigJank/ftTop berasal dari timestamp frame asli (--latency), hanya terisi saat merekam. */
class Snap(
    val fps: Float, val pkg: String,
    val ftN: Int = 0, val ftMaxMs: Float = 0f, val jank: Int = 0, val bigJank: Int = 0, val ftTop: List<Float> = emptyList(),
    // Sensor (Sensors.read), -1 = tidak terbaca
    val cpu: Int = -1, val gpu: Int = -1, val ramPct: Int = -1,
    val tCpu: Float = -1f, val tGpu: Float = -1f, val tBat: Float = -1f, val tSkin: Float = -1f,
    val watt: Float = -1f, val batPct: Int = -1, val gpuMhz: Int = -1, val ddrMhz: Int = -1,
    val coreMhz: List<Int> = emptyList(),                       // frekuensi tiap inti (MHz), -1 = mati / tidak terbaca
    val clusterCpu: List<Pair<Int, Int>> = emptyList()          // beban per cluster: (inti pertama cluster, persen)
)

/**
 * Pengukur FPS game sungguhan (bukan layar app ini), diambil dari Pulse Monitor dan diringkas:
 *  1. Paket di depan: riwayat penggunaan (cepat) atau dumpsys window.
 *  2. FPS: TaskFps (Android 14+, daemon hak shell) -> cadangan SurfaceFlinger timestats -> cadangan --latency.
 *  3. Frametime asli per frame (--latency) saat merekam, untuk 5% / 1% low, Jank, BigJank.
 * Butuh Shizuku atau Root.
 */
object Sampler {
    private val TRANSIENT_PKGS = setOf("com.android.systemui", "android", "com.miui.screenrecorder", "com.miui.securitycenter", "com.miui.gamebooster")
    // Aplikasi live streaming: widget mengambangnya bisa merebut fokus dari game yang sedang disiarkan
    private val STREAM_PKGS = setOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.ss.android.ugc.aweme",
        "tv.twitch.android.app", "com.facebook.gamingvideo", "com.streamlabs.goliveandroid", "com.kick.mobile")
    private val SKIP_PKGS = TRANSIENT_PKGS + STREAM_PKGS

    /** Bukan target pengukuran: SystemUI, keyboard, perekam layar, Game Turbo, app ini sendiri. */
    fun isIgnoredPkg(p: String, own: String) = p.isEmpty() || p == own || p in SKIP_PKGS ||
        p.contains("inputmethod") || p.contains("screenrecord") || p.contains("gamebooster") ||
        p.startsWith("com.ss.android.ugc.") || p.contains("tiktok", ignoreCase = true)

    /** Khusus nama di notifikasi: hanya jendela sementara yang dilewati. */
    fun isTransientPkg(p: String, own: String) = p.isEmpty() || p == own || p in TRANSIENT_PKGS ||
        p.contains("inputmethod") || p.contains("screenrecord") || p.contains("gamebooster")

    @Volatile private var appCtx: Context? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null

    /** Pembacaan terbaru untuk overlay (FPS + sensor). Terisi selama overlay menyala atau saat merekam. */
    private val _live = MutableStateFlow<OvSnap?>(null)
    val live: StateFlow<OvSnap?> = _live
    /** true selama OverlayService hidup: sensor ikut dibaca walau tidak merekam. */
    @Volatile var overlayWanted = false

    /** Pembacaan sensor terakhir saat merekam (null sebelum rekaman pertama). */
    @Volatile var lastSensors: Sensors.Data? = null

    /** Paket yang dikunci selama merekam. */
    @Volatile var pinPkg: String? = null
    @Volatile var fpsDbg = ""
    @Volatile private var lastGame = ""
    private var lastGameAt = 0L
    private var pinZero = 0

    fun lastGamePkg(): String = lastGame
    fun fpsDiag(): String = "paket terkunci: ${pinPkg ?: "-"} | $fpsDbg | ${TaskFps.diag()}"

    fun running() = job?.isActive == true

    // Status pengukuran yang dibawa antar tick (disamakan dengan PulseMonitor)
    @Volatile private var curPkg = ""                 // paket yang SEDANG diukur tick ini (bisa beda dari fokus jendela)
    private var lastFps = 0; private var lastFpsPkg = ""; private var zeroTicks = 0
    private const val HOLD_TICKS = 3                  // 0 FPS sungguhan: tahan nilai terakhir sebentar (adegan statis)
    private const val UNKNOWN_HOLD_TICKS = 6          // gagal ukur: tahan lebih lama sebelum jatuh ke 0
    private const val IDLE_FPS = 15                   // di bawah ini pada aplikasi non-game = layar statis, bukan FPS rendah
    private const val FAST_MS = 1000L
    @Volatile private var surfaceApp = false          // layer SurfaceView = game / video, menggambar terus-menerus

    /** Semua perintah shell Sampler dibatasi waktu, supaya satu perintah macet tidak menahan putaran selamanya. */
    private fun sh(cmd: String): String = Shell.execLimited(cmd, 3500L)

    private fun displayHz(): Int = runCatching {
        appCtx?.getSystemService(DisplayManager::class.java)?.getDisplay(0)?.refreshRate?.let { Math.round(it) }
    }.getOrNull() ?: -1

    private var fastJob: Job? = null

    fun start(ctx: Context) {
        appCtx = ctx.applicationContext
        if (job?.isActive != true) {
            TaskFps.start(ctx)
            job = scope.launch {
                while (isActive) {
                    // Jadwal tetap ~1 detik: lama tick dikurangkan dari jeda supaya sampel tidak melambat
                    val t0 = SystemClock.elapsedRealtime()
                    runCatching { tick() }.onFailure { AppLog.w("Sampler", "tick gagal: ${it.javaClass.simpleName} ${it.message}") }
                    delay((1000L - (SystemClock.elapsedRealtime() - t0)).coerceAtLeast(200L))
                }
            }
        }
        // Jalur cepat FPS / CPU / GPU untuk overlay, terpisah dari tick berat (seperti PulseMonitor)
        if (fastJob?.isActive != true) fastJob = scope.launch {
            while (isActive) {
                val t0 = SystemClock.elapsedRealtime()
                runCatching { fastTick() }.onFailure { AppLog.w("Sampler", "jalur cepat gagal: ${it.javaClass.simpleName} ${it.message}") }
                delay((FAST_MS - (SystemClock.elapsedRealtime() - t0)).coerceAtLeast(80L))
            }
        }
    }

    fun stop() {
        job?.cancel(); job = null
        fastJob?.cancel(); fastJob = null; fast = null
        fPrevTotal = 0L; fPrevIdle = 0L; fLayer = ""; fLayerPkg = ""; fLastFps = 0
        TaskFps.stop()
        tsReady = false; tsWin.clear(); ftReset()
        pinPkg = null; pinZero = 0
        curPkg = ""; lastFps = 0; lastFpsPkg = ""; zeroTicks = 0
        _live.value = null
    }

    /** Dipanggil tepat sebelum Recorder.start(): baca ulang fokus supaya game langsung terkunci. */
    fun onRecordStart() { focusAt = -10_000L; pinPkg = null; pinZero = 0; ftReset() }

    // ---------- Paket di depan ----------
    private var focusCache = ""; private var focusAt = -10_000L
    private val FOCUS_RX = Regex("u\\d+ ([\\w.]+)/")

    private fun pkgsIn(out: String, only: String? = null): List<String> =
        out.lines().filter { !it.contains("=null") && (only == null || it.contains(only)) }
            .mapNotNull { FOCUS_RX.find(it)?.groupValues?.get(1) }

    /** Ringkasan pembacaan terakhir untuk nama di notifikasi (kandidat jendela/aktivitas dan yang dipilih); dipakai log. */
    @Volatile var focusDiag = ""

    /**
     * Paket di depan lewat dumpsys (lambat, panggil dari thread latar). Semua kandidat dikumpulkan dan yang pertama BUKAN jendela
     * sementara dipakai. forLabel: mFocusedApp (aplikasinya) didahulukan dari mCurrentFocus (jendelanya), karena jendela fokus bisa basi.
     */
    private fun focusPkg(forLabel: Boolean = false): String? {
        val own = if (forLabel) "" else (appCtx?.packageName ?: "")
        val win = Shell.execLimited("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -8", 2500L)
        val cand = if (forLabel) pkgsIn(win, "mFocusedApp") + pkgsIn(win, "mCurrentFocus") else pkgsIn(win)
        val skip: (String) -> Boolean = if (forLabel) { p -> isTransientPkg(p, own) } else { p -> isIgnoredPkg(p, own) }
        cand.firstOrNull { !skip(it) }?.let { if (forLabel) focusDiag = "jendela [${cand.joinToString(",")}] -> $it"; return it }
        val act = pkgsIn(Shell.execLimited("dumpsys activity activities | grep -E 'topResumedActivity|ResumedActivity' | head -4", 2500L))
        act.firstOrNull { !skip(it) }?.let { if (forLabel) focusDiag = "jendela [${cand.joinToString(",")}] aktivitas [${act.joinToString(",")}] -> $it"; return it }
        val r = cand.firstOrNull() ?: act.firstOrNull()
        if (forLabel) focusDiag = "semua sementara/kosong: jendela [${cand.joinToString(",")}] aktivitas [${act.joinToString(",")}] -> ${r ?: "-"}"
        return r
    }

    /**
     * Nama paket untuk notifikasi: HANYA dumpsys (fokus jendela sebenarnya), sama seperti PulseMonitor. Riwayat penggunaan tidak dipakai di sini
     * karena hanya mencatat aktivitas yang baru dibuka/dilanjutkan; ia basi bila aplikasi dibawa ke depan tanpa kejadian baru (jendela
     * mengambang/PiP, atau >3 menit tanpa kejadian) sehingga nama tertinggal di "POCO Launcher". Penyelarasan dengan riwayat ada di RecService.
     */
    fun foregroundPkg(): String = focusPkg(forLabel = true).orEmpty()

    /** Pembacaan fokus untuk pengukuran: dumpsys saja (disamakan dengan PulseMonitor; riwayat penggunaan bisa basi). */
    private fun quickTop(): String? = focusPkg()

    /** Paket yang diukur. Fokus sementara (SystemUI / keyboard / app ini) diabaikan 20 detik setelah game terakhir di depan; saat merekam dikunci. */
    private fun targetPkg(): String? {
        pinPkg?.let { lastGame = it; return it }
        val now = SystemClock.elapsedRealtime()
        if (now - focusAt >= 2000L) { focusCache = quickTop() ?: ""; focusAt = now }
        val p = focusCache
        if (!isIgnoredPkg(p, appCtx?.packageName ?: "")) { lastGame = p; lastGameAt = now; return p }
        if (lastGame.isNotEmpty() && now - lastGameAt < 20_000L) return lastGame
        return p.ifEmpty { null }
    }

    // ---------- Tick ----------
    private fun tick() {
        if (Shell.mode() == "-") { fpsDbg = "tidak ada akses Shizuku/Root"; return }
        val own = appCtx?.packageName ?: ""
        val rec = Recorder.active
        // Sensor dibaca DULU dan SELALU. Dulu tick keluar lebih awal (aplikasi fokus diabaikan / gagal ukur) sebelum sampai ke sini,
        // sehingga overlay tidak pernah diperbarui dan FPS / CPU / GPU membeku di angka terakhir (mis. FPS 0, 622 MHz, 337 MHz).
        val sn = if (rec || overlayWanted) appCtx?.let { c -> runCatching { Sensors.read(c) }.getOrNull() } else null
        if (sn != null) lastSensors = sn   // dipakai tab Statistik saat merekam, supaya tidak membaca sensor dobel

        val f = runCatching { measure() }.onFailure { AppLog.w("Sampler", "ukur FPS gagal: ${it.javaClass.simpleName} ${it.message}") }.getOrDefault(-1)
        val pkg = curPkg
        // Jalur cepat (frame 1 dtk terakhir) dipakai bila segar dan untuk paket yang sama; jalur lama tetap penentu paket dan cadangan
        val fa = fastFresh()?.takeIf { it.fpsRaw >= 0 && it.pkg == pkg && pkg.isNotEmpty() }
        val fps = fa?.fpsRaw ?: f
        val unknown = fps < 0      // gagal ukur sesaat (statistik ter-reset, layer baru, dumpsys lambat) BUKAN 0 FPS

        if (rec && pinPkg == null && fps > 0 && pkg.isNotEmpty() && !isIgnoredPkg(pkg, own)) pinPkg = pkg
        if (rec && pinPkg != null && !unknown) {
            // Terkunci ke paket yang terus 0 FPS ~8 detik (salah kunci di awal): lepas, deteksi ulang
            if (fps > 0) pinZero = 0 else if (++pinZero >= 8) { pinZero = 0; pinPkg = null; focusAt = -10_000L; ftReset() }
        }

        // Tahan nilai terakhir: layar diam / adegan statis tidak menyerahkan frame baru. Gagal ukur ditahan lebih lama,
        // dan tetap ditahan walau fokus sesaat pindah ke SystemUI / app ini.
        var shown = maxOf(fps, 0)
        if (fps > 0) { lastFps = fps; lastFpsPkg = pkg; zeroTicks = 0 }
        else {
            val samePkg = lastFpsPkg == pkg || pkg.isEmpty() || isIgnoredPkg(pkg, own)
            val limit = if (unknown) UNKNOWN_HOLD_TICKS else HOLD_TICKS
            val hold = samePkg || (unknown && zeroTicks < HOLD_TICKS)
            if (lastFps > 0 && hold && zeroTicks < limit) { zeroTicks++; shown = lastFps } else lastFps = 0
        }
        val rawOut = if (unknown) lastFps else fps    // untuk rekaman: nilai yang ditahan, bukan angka negatif
        // Aplikasi biasa (tanpa SurfaceView) hanya menggambar saat ada perubahan: layar diam = 0-5 FPS itu normal, bukan lag.
        // Tampilkan refresh rate layar alih-alih angka kecil itu.
        if (shown < IDLE_FPS && !surfaceApp && pkg.isNotEmpty()) { val hz = displayHz(); if (hz > 0) shown = hz }

        if (rec && pkg.isNotEmpty() && !isIgnoredPkg(pkg, own)) {
            val ft = runCatching { frameStats(pkg) }.getOrNull()
            Recorder.onSample(Snap(rawOut.toFloat(), pkg, ft?.n ?: 0, ft?.maxMs ?: 0f, ft?.jank ?: 0, ft?.bigJank ?: 0, ft?.top ?: emptyList(),
                cpu = sn?.cpu ?: -1, gpu = sn?.gpu ?: -1, ramPct = sn?.ramPct ?: -1,
                tCpu = sn?.tCpu ?: -1f, tGpu = sn?.tGpu ?: -1f, tBat = sn?.tBat ?: -1f, tSkin = sn?.tSkin ?: -1f,
                watt = sn?.watt ?: -1f, batPct = sn?.batPct ?: -1, gpuMhz = sn?.gpuMhz ?: -1, ddrMhz = sn?.ddrMhz ?: -1,
                coreMhz = sn?.coreMhz ?: emptyList(), clusterCpu = sn?.clusterCpu ?: emptyList()))
        } else if (!rec) ftReset()

        // Overlay SELALU diperbarui tiap tick (juga saat fokus diabaikan / gagal ukur). Nilai yang gagal dibaca memakai nilai sebelumnya.
        if (overlayWanted) {
            val fz = fastFresh()
            _live.update { old ->
                val o = old ?: OvSnap()
                OvSnap(
                    fps = shown,
                    cpu = fz?.cpu?.takeIf { it >= 0 } ?: sn?.cpu ?: o.cpu,
                    gpu = fz?.gpu?.takeIf { it >= 0 } ?: sn?.gpu ?: o.gpu,
                    ramPct = sn?.ramPct ?: o.ramPct,
                    cpuMhz = fz?.cpuMhz?.takeIf { it > 0 } ?: sn?.coreMhz?.filter { it > 0 }?.maxOrNull() ?: o.cpuMhz,
                    gpuMhz = fz?.gpuMhz?.takeIf { it > 0 } ?: sn?.gpuMhz?.takeIf { it > 0 } ?: o.gpuMhz,
                    batPct = sn?.batPct ?: o.batPct,
                    tCpu = sn?.tCpu ?: o.tCpu, tGpu = sn?.tGpu ?: o.tGpu, tBat = sn?.tBat ?: o.tBat, watt = sn?.watt ?: o.watt,
                    ftMs = o.ftMs
                )
            }
        }
    }

    /** FPS paket yang sedang diukur (TaskFps bila ada, kalau tidak timestats / latency). -1 = gagal ukur sesaat. curPkg ikut diisi. */
    private fun measure(): Int {
        val base = measureLegacy()
        val pkg = curPkg
        if (pkg.isEmpty()) return base
        TaskFps.track(pkg)
        val t = TaskFps.read(pkg)
        if (t == null) { fpsDbg += " | ${TaskFps.diag()}"; return base }
        // Sistem melapor 0 tapi timestats melihat game menggambar: jangan percaya 0 itu (counter belum siap), pakai jalur lama
        if (t < 0.5f && base >= 5) { fpsDbg += " | TaskFps 0, timestats $base dipakai"; return base }
        fpsDbg = "TaskFps %.1f | %s".format(t, fpsDbg)
        return Math.round(t)
    }

    // ---------- Cadangan: SurfaceFlinger timestats ----------
    private class Ts(val at: Long, val total: Map<String, Long>, val queued: Map<String, Long>)
    private val tsWin = ArrayDeque<Ts>()
    private var tsReady = false
    private var tsEmpty = 0
    private var tsClearAt = -100_000L
    private const val TS_SOFT_LIMIT = 150

    private fun timestats(): Ts {
        if (!tsReady) {
            sh("dumpsys SurfaceFlinger --timestats -clear -enable"); tsReady = true; tsWin.clear()
            tsClearAt = SystemClock.elapsedRealtime()
        }
        val t0 = SystemClock.elapsedRealtime()
        val txt = sh("dumpsys SurfaceFlinger --timestats -dump")
        val at = (t0 + SystemClock.elapsedRealtime()) / 2
        val total = HashMap<String, Long>(); val queued = HashMap<String, Long>()
        var name: String? = null
        var nLayers = 0
        for (l in txt.lines()) {
            val t = l.trim()
            val v = t.substringAfter('=', "").trim().toLongOrNull()
            when {
                t.startsWith("layerName") -> { name = t.substringAfter('=').trim(); nLayers++ }
                name != null && v != null && t.startsWith("totalFrames") -> { total[name!!] = v; queued[name!!] = (queued[name!!] ?: 0L) + v }
                name != null && v != null && t.startsWith("droppedFrames") -> queued[name!!] = (queued[name!!] ?: 0L) + v
            }
        }
        if (total.isEmpty()) { if (++tsEmpty >= 3) { tsReady = false; tsEmpty = 0 } } else tsEmpty = 0
        // Tabel timestats ~200 layer: reset sebelum penuh supaya layer game yang dibuat ulang tetap tercatat
        if (nLayers >= TS_SOFT_LIMIT && SystemClock.elapsedRealtime() - tsClearAt > 20_000L) tsReady = false
        return Ts(at, total, queued)
    }

    /**
     * FPS = frame yang benar-benar tampil (totalFrames) dari layer paket yang diukur, jendela ~2,5 detik. -1 = gagal ukur sesaat.
     * Fokus yang diabaikan (SystemUI / app ini / TikTok) tidak lagi menghentikan pengukuran: dipakai layer paling aktif,
     * dan bila tidak ada, fokus tetap diukur (aplikasi biasa -> tampil refresh rate layar saat diam).
     */
    private fun measureLegacy(): Int {
        val focus = targetPkg()
        val own = appCtx?.packageName ?: ""
        val cur = timestats()
        // Dump kosong sesaat: pertahankan jendela lama, anggap gagal ukur (bukan 0 FPS)
        if (cur.total.isEmpty() && tsWin.isNotEmpty()) { fpsDbg = "dump timestats kosong, nilai ditahan"; return -1 }
        tsWin.addLast(cur)
        while (tsWin.size > 1 && cur.at - tsWin.first().at > 2500L) tsWin.removeFirst()
        // Fokus jatuh ke SystemUI / app ini / aplikasi yang diabaikan: game di belakangnya tetap menggambar, pakai layer paling aktif
        var found: String? = null
        if (focus == null || isIgnoredPkg(focus, own)) {
            found = busiestLayerPkg(cur, own)
            if (found != null && Recorder.active && pinPkg == null) pinPkg = found
        }
        var pkg0: String? = found ?: focus
        // Fokus dipegang aplikasi lain yang tidak menggambar sementara game jalan di belakangnya: ukur aplikasi yang menggambar >= 20 fps
        if (found == null && pkg0 != null) {
            val fp: String = pkg0
            val base0 = tsWin.first(); val dt0 = (cur.at - base0.at) / 1000f
            if (dt0 >= 0.3f) {
                var rate = 0f
                for (k in cur.queued.keys) if (k.contains(fp)) {
                    val q0 = base0.queued[k] ?: continue; val q1 = cur.queued[k] ?: continue
                    if (q1 >= q0) rate = maxOf(rate, (q1 - q0) / dt0)
                }
                if (rate < 5f) { val alt = busiestLayerPkg(cur, own, 20f); if (alt != null && alt != fp) pkg0 = alt }
            }
        }
        // Paket terpilih bisa tidak punya layer sama sekali (widget mengambang, game sudah ditutup): pindah ke layer paling aktif
        var pkgSel: String? = pkg0
        var swNote = ""
        if (pkgSel != null) {
            val p0: String = pkgSel
            if (cur.total.keys.none { it.contains(p0) }) {
                val alt = busiestLayerPkg(cur, own, 5f)
                if (alt != null && alt != p0) { pkgSel = alt; swNote = " | $p0 tanpa layer, pindah ke $alt" }
            }
        }
        val pkg: String? = pkgSel
        curPkg = pkg ?: ""
        if (pkg == null) { fpsDbg = "aplikasi fokus tidak terbaca"; surfaceApp = false; return -1 }

        val cand = cur.total.keys.filter { it.contains(pkg) }
        val base = tsWin.first()
        val dt = (cur.at - base.at) / 1000f
        var bestQ = 0f; var bestP = 0f
        var valid = false; var reset = false
        var pending = false   // ada layer yang belum punya pembanding (layer baru): lajunya belum diketahui
        if (dt >= 0.3f) for (k in cand) {
            val p1 = cur.total[k] ?: continue; val q1 = cur.queued[k] ?: continue
            // Pembanding PER LAYER: sampel tertua di jendela yang sudah memuat layer ini
            var b: Ts? = null
            for (w in tsWin) if (w !== cur && w.total.containsKey(k) && w.queued.containsKey(k)) { b = w; break }
            val d = if (b == null) 0f else (cur.at - b.at) / 1000f
            // Jendela < 0,8 dtk terlalu berisik: anggap "belum tahu", bukan angka
            if (b == null || d < 0.8f) { pending = true; continue }
            val p0 = b.total[k] ?: continue; val q0 = b.queued[k] ?: continue
            if (p1 >= p0 && q1 >= q0) { valid = true; bestP = maxOf(bestP, (p1 - p0) / d); bestQ = maxOf(bestQ, (q1 - q0) / d) }
            else reset = true   // penghitung turun: statistik di-reset
        }
        if (reset) { tsWin.clear(); tsWin.addLast(cur) }
        surfaceApp = cand.any { it.contains("SurfaceView[") }
        if (cand.isNotEmpty()) {
            fpsDbg = "$pkg | ${cand.size} layer${if (surfaceApp) " (SurfaceView)" else ""} | tampil %.0f, diserahkan %.0f | layar %d Hz%s".format(
                bestP, bestQ, displayHz(), if (pinPkg != null) " | terkunci" else "") + swNote
            if (!valid) return -1
            // 0 dari layer lama yang diam TIDAK boleh dipercaya selama ada layer baru / statistik baru di-reset
            if (bestQ < 0.5f && (pending || reset)) { fpsDbg += " | layer baru/reset, ditahan"; return -1 }
            // Android 16: layer SurfaceView menyerahkan frame tapi totalFrames tidak naik (dihitung dropped): ukur lewat --latency
            if (bestP < 0.5f && bestQ >= 5f) {
                val live = runCatching { liveLayers(pkg) }.getOrDefault(emptyList())
                val now = runCatching { fpsNow(live) }.getOrDefault(-1f)
                val est = if (now >= 1f) now else bestQ
                fpsDbg += if (now >= 1f) " | tampil 0, latency %.0f".format(now) else " | tampil 0, pakai laju diserahkan %.0f".format(bestQ)
                return Math.round(est)
            }
            if (bestQ < 0.5f) {
                val live = runCatching { liveLayers(pkg) }.getOrDefault(emptyList())
                // Layer SurfaceView hidup tapi tidak ada di tabel timestats (tabel penuh / layer dibuat ulang): bukan 0 FPS
                val missing = live.any { it.contains("SurfaceView[") && !cur.total.containsKey(it) }
                if (missing && SystemClock.elapsedRealtime() - tsClearAt > 20_000L) {
                    AppLog.i("FPS", "layer game hidup tidak ada di timestats (${cur.total.size} layer), tabel direset")
                    tsReady = false
                }
                val now = runCatching { fpsNow(live) }.getOrDefault(-1f)
                if (now > 0f) { fpsDbg += " | timestats 0, latency %.0f".format(now); return Math.round(now) }
                if (missing) { fpsDbg += " | layer game belum tercatat timestats, ditahan"; return -1 }
            }
            return Math.round(minOf(bestP, bestQ))
        }
        surfaceApp = false
        val lat = fpsLatency(pkg)
        fpsDbg = "timestats: $pkg tidak ada (${cur.total.size} layer) -> latency: $fpsDbg$swNote"
        return if (lat > 0f) Math.round(lat) else -1
    }

    /** Paket (bukan app ini / SystemUI / keyboard) dengan frame paling banyak diserahkan dalam jendela terakhir; null bila tidak ada yang aktif. */
    private fun busiestLayerPkg(cur: Ts, own: String, minRate: Float = 5f): String? {
        val base = tsWin.first()
        val dt = (cur.at - base.at) / 1000f
        if (dt < 0.3f) return null
        val rx = Regex("([A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z0-9_]+)+)/")
        var best: String? = null; var bestRate = 0f
        for ((k, q1) in cur.queued) {
            val q0 = base.queued[k] ?: continue
            if (q1 < q0) continue
            val pk = rx.find(k)?.groupValues?.get(1) ?: continue
            if (isIgnoredPkg(pk, own)) continue
            var rate = (q1 - q0) / dt
            if (k.contains("SurfaceView[")) rate += 1f   // lapisan game (SurfaceView) menang bila seri dengan UI biasa
            if (rate > bestRate) { bestRate = rate; best = pk }
        }
        return best?.takeIf { bestRate >= minRate }
    }

    /**
     * FPS 1,5 detik terakhir dari timestamp frame asli (--latency), dihitung mundur dari waktu sekarang (bukan dari frame terakhir),
     * jadi game yang macet tidak dikira masih 60. -1 bila tidak ada data.
     */
    private fun fpsNow(live: List<String>): Float {
        val layers = live.sortedByDescending { (if (it.contains("SurfaceView")) 2 else 0) + (if (it.contains("BLAST")) 1 else 0) }
        if (layers.isEmpty()) return -1f
        var best = -1f
        for (layer in layers.take(3)) {
            val rows = sh("dumpsys SurfaceFlinger --latency '$layer'").lines().drop(1).map { it.trim().split(Regex("\\s+")) }
            val now = System.nanoTime()
            // Kolom 1 = waktu frame tampil, kolom 2 = waktu frame siap: pakai yang menghasilkan laju terbesar
            for (col in intArrayOf(1, 2)) {
                val ts = rows.mapNotNull { it.getOrNull(col)?.toLongOrNull() }.filter { it in 1 until Long.MAX_VALUE / 2 && it <= now }
                if (ts.size < 2) continue
                best = maxOf(best, ts.count { it > now - 1_500_000_000L } / 1.5f)
            }
        }
        return best
    }

    // ---------- Jalur cepat FPS / CPU / GPU (1 proses shell per detik, langsung ke overlay) ----------
    private class Fast(val at: Long, val pkg: String, val fpsRaw: Int, val cpu: Int, val gpu: Int, val cpuMhz: Int, val gpuMhz: Int, val ftMs: Float = -1f)
    @Volatile private var fast: Fast? = null
    private var fLayer = ""; private var fLayerPkg = ""; private var fLayerAt = -100_000L
    private var fPrevTotal = 0L; private var fPrevIdle = 0L
    private var fLastFps = 0; private var fLastFpsAt = 0L

    private fun fastFresh(): Fast? = fast?.takeIf { SystemClock.elapsedRealtime() - it.at < 1500L }

    /** Jumlah frame tampil dalam [windowNs] terakhir dihitung mundur dari [nowNs] (kolom 1 = waktu tampil, cadangan kolom 2). -1 = tidak ada data. */
    private fun framesIn(text: String, nowNs: Long, windowNs: Long): Int {
        val rows = text.lines().drop(1).map { it.trim().split(Regex("\\s+")) }
        for (col in intArrayOf(1, 2)) {
            val ts = rows.mapNotNull { it.getOrNull(col)?.toLongOrNull() }.filter { it in 1 until Long.MAX_VALUE / 2 && it <= nowNs }
            if (ts.size < 3) continue
            return ts.count { it > nowNs - windowNs }
        }
        return -1
    }

    /** Frametime (ms) = rata-rata selisih waktu 5 frame tampil terakhir (kolom 1, cadangan kolom 2). -1 = data kurang / layar diam. */
    private fun lastFrameMs(text: String, nowNs: Long): Float {
        val rows = text.lines().drop(1).map { it.trim().split(Regex("\\s+")) }
        for (col in intArrayOf(1, 2)) {
            val ts = rows.mapNotNull { it.getOrNull(col)?.toLongOrNull() }.filter { it in 1 until Long.MAX_VALUE / 2 && it <= nowNs }.sorted()
            if (ts.size < 3) continue
            val tail = ts.takeLast(6)
            val d = (1 until tail.size).map { (tail[it] - tail[it - 1]) / 1e6f }.filter { it > 0.5f && it < 500f }
            if (d.isNotEmpty()) return d.average().toFloat()
        }
        return -1f
    }

    private fun gpuRawToMhz(path: String, raw: String): Int {
        val nums = Regex("\\d+").findAll(raw).mapNotNull { it.value.toLongOrNull() }.toList()
        if (nums.isEmpty()) return -1
        val v = if (path.endsWith("current_freqency")) nums.max() else nums[0]
        return when {
            path.endsWith("gpu_clock") || path.endsWith("clock_mhz") -> v
            v >= 10_000_000L -> v / 1_000_000
            v >= 10_000L -> v / 1000
            else -> v
        }.toInt().takeIf { it in 100..3500 } ?: -1
    }

    /** Pilih layer dengan laju frame tertinggi milik [pkg] (SurfaceView / BLAST didahulukan). Dipanggil jarang (tiap ~3 dtk). */
    private fun fastPickLayer(pkg: String) {
        fLayerAt = SystemClock.elapsedRealtime(); fLayerPkg = pkg
        val layers = liveLayers(pkg).sortedByDescending { (if (it.contains("SurfaceView")) 2 else 0) + (if (it.contains("BLAST")) 1 else 0) }.take(3)
        var best = ""; var bestN = -1
        for (l in layers) {
            val t0 = System.nanoTime(); val txt = sh("dumpsys SurfaceFlinger --latency '$l'"); val t1 = System.nanoTime()
            val n = framesIn(txt, (t0 + t1) / 2, 1_000_000_000L)
            if (n > bestN) { bestN = n; best = l }
        }
        fLayer = best
    }

    private fun fastTick() {
        if (Shell.mode() == "-") { fast = null; return }
        if (!overlayWanted && !Recorder.active) return
        val pkg = curPkg
        val now = SystemClock.elapsedRealtime()
        if (pkg.isEmpty()) { fLayer = ""; fLayerPkg = "" }
        else if (pkg != fLayerPkg || fLayer.isEmpty() || now - fLayerAt > 3000L) fastPickLayer(pkg)
        val layer = fLayer
        val gPath = Sensors.gpuLoadPath?.takeIf { it.startsWith("/") }
        val fPath = Sensors.gpuPickPath?.takeIf { it.startsWith("/") }
        val cmd = StringBuilder("head -n1 /proc/stat; echo ==; ")
        if (gPath != null) cmd.append("cat ").append(gPath).append(" 2>/dev/null; ")
        cmd.append("echo ==; ")
        if (fPath != null) cmd.append("cat ").append(fPath).append(" 2>/dev/null | tr '\\n' ' '; ")
        cmd.append("echo ==; for d in /sys/devices/system/cpu/cpu[0-9]*; do [ -r \$d/cpufreq/scaling_cur_freq ] && echo \"\${d##*/}:\$(cat \$d/cpufreq/scaling_cur_freq 2>/dev/null):\"; done")
        if (layer.isNotEmpty()) cmd.append("; echo ==; dumpsys SurfaceFlinger --latency '").append(layer).append("'")
        val t0 = System.nanoTime()
        val out = sh(cmd.toString()).split("==")
        val t1 = System.nanoTime()
        if (out.size < 4) return
        // CPU: selisih /proc/stat sejak putaran sebelumnya
        var cpu = -1
        val c = out[0].trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (c.size >= 5) {
            val total = c.take(8).sum(); val idle = c[3] + c[4]
            if (fPrevTotal > 0 && total > fPrevTotal) cpu = (100 * ((total - fPrevTotal) - (idle - fPrevIdle)) / (total - fPrevTotal)).toInt().coerceIn(0, 100)
            fPrevTotal = total; fPrevIdle = idle
        }
        // GPU: beban sesaat
        var gpu = -1
        if (gPath != null) {
            val nums = Regex("\\d+").findAll(out[1]).mapNotNull { it.value.toLongOrNull() }.toList()
            gpu = when {
                nums.isEmpty() -> null
                gPath.endsWith("gpubusy") -> nums.getOrNull(1)?.takeIf { it > 0 }?.let { (100 * nums[0] / it).toInt().coerceIn(0, 100) }
                else -> nums[0].toInt().takeIf { it in 0..100 }
            } ?: -1
        }
        val gpuMhz = if (fPath != null) gpuRawToMhz(fPath, out[2]) else -1
        val cpuMhz = out[3].lines().mapNotNull { l ->
            val f = l.trim().split(':'); if (f.size < 2 || !f[0].startsWith("cpu")) null else f[1].trim().toLongOrNull()?.takeIf { it > 0 }?.let { (it / 1000).toInt() }
        }.filter { it in 100..5000 }.maxOrNull() ?: -1
        // FPS: frame tampil dalam 1 dtk terakhir; waktu pembacaan = titik tengah eksekusi dumpsys
        var raw = -1
        if (layer.isNotEmpty() && out.size >= 5) raw = framesIn(out[4], (t0 + t1) / 2, 1_000_000_000L)
        val at = SystemClock.elapsedRealtime()
        val ftMs = if (layer.isNotEmpty() && out.size >= 5 && raw > 0) lastFrameMs(out[4], (t0 + t1) / 2) else -1f
        fast = Fast(at, pkg, raw, cpu, gpu, cpuMhz, gpuMhz, ftMs)
        // Publikasikan langsung ke overlay; aturan tahan nilai / layar diam sama dengan tick
        if (!overlayWanted) return
        var shown = -1
        if (raw >= 0) {
            if (raw > 0) { fLastFps = raw; fLastFpsAt = at }
            shown = if (raw > 0) raw else if (fLastFps > 0 && at - fLastFpsAt < 3000L) fLastFps else 0
            if (shown < IDLE_FPS && !surfaceApp && pkg.isNotEmpty()) { val hz = displayHz(); if (hz > 0) shown = hz }
        }
        _live.update { o0 ->
            val o = o0 ?: OvSnap()
            o.copy(
                fps = if (shown >= 0) shown else o.fps,
                cpu = if (cpu >= 0) cpu else o.cpu,
                gpu = if (gpu >= 0) gpu else o.gpu,
                cpuMhz = if (cpuMhz > 0) cpuMhz else o.cpuMhz,
                gpuMhz = if (gpuMhz > 0) gpuMhz else o.gpuMhz,
                ftMs = if (ftMs > 0f) ftMs else if (shown == 0) -1f else o.ftMs
            )
        }
    }

    // ---------- Layer SurfaceFlinger + frametime asli (--latency) ----------
    /** Android 15/16 mencetak `--list` sebagai "RequestedLayerState{nama#id ...}"; namanya diambil sampai "#id". */
    private val LAYER_LINE = Regex("^RequestedLayerState\\{(.*?#\\d+)(?=[ }]|$)")
    private fun liveLayers(pkg: String): List<String> =
        sh("dumpsys SurfaceFlinger --list").lines().mapNotNull { raw ->
            val l = raw.trim()
            if (!l.contains(pkg)) return@mapNotNull null
            val n: String? = if (l.startsWith("RequestedLayerState{")) LAYER_LINE.find(l)?.groupValues?.get(1) else l
            n?.takeIf { !it.startsWith("Background") && !it.startsWith("ActivityRecord{") && !it.startsWith("Task=") }
        }.distinct()

    private fun fpsLatency(pkg: String): Float {
        val all = liveLayers(pkg)
        if (all.isEmpty()) { fpsDbg = "$pkg: layer tidak ditemukan"; return 0f }
        val ordered = all.sortedByDescending { (if (it.contains("SurfaceView")) 2 else 0) + (if (it.contains("BLAST")) 1 else 0) }
        for (layer in ordered.take(4)) {
            val rows = sh("dumpsys SurfaceFlinger --latency '$layer'").lines().drop(1).map { it.trim().split(Regex("\\s+")) }
            for (col in intArrayOf(1, 2)) {
                val ts = rows.mapNotNull { it.getOrNull(col)?.toLongOrNull() }.filter { it in 1 until Long.MAX_VALUE / 2 }.sorted()
                if (ts.size < 3) continue
                val recent = ts.filter { it >= ts.last() - 1_000_000_000L }
                if (recent.size < 2 || recent.last() == recent.first()) continue
                fpsDbg = "$pkg | ${layer.take(36)} | ${ts.size} frame, kolom $col"
                return ((recent.size - 1) * 1e9 / (recent.last() - recent.first())).toFloat()
            }
        }
        fpsDbg = "$pkg: ${ordered.size} layer, data latency kosong"
        return 0f
    }

    private class Ft(val n: Int, val maxMs: Float, val jank: Int, val bigJank: Int, val top: List<Float>)
    private var ftLayer = ""; private var ftLayerLast = ""; private var ftPkg = ""; private var ftLayerAt = -100_000L
    private var ftLastTs = 0L
    private val ftPrev = ArrayDeque<Float>()
    private fun ftReset() { ftLayer = ""; ftLayerLast = ""; ftPkg = ""; ftLastTs = 0L; ftPrev.clear() }

    /**
     * Frametime tiap frame BARU sejak tick sebelumnya. Hasil: jumlah frame, frametime terburuk (12 teratas, untuk 5% / 1% low sungguhan),
     * Jank = frametime > 2x rata-rata 3 frame sebelumnya DAN > 83,3 ms; BigJank = > 3x DAN > 125 ms (definisi PerfDog).
     */
    private fun frameStats(pkg: String): Ft? {
        val now = SystemClock.elapsedRealtime()
        if (pkg != ftPkg) { ftReset(); ftPkg = pkg }
        // Pakai layer yang SAMA dengan penghitung FPS (layer paling aktif), supaya FPS, frametime, 1% / 5% low dan Jank berasal dari
        // satu sumber (satu pembacaan --latency per detik). Dulu layer dipilih sendiri hanya dari nama (SurfaceView / BLAST),
        // bisa jatuh ke layer lain yang tidak menggambar 60 FPS dan memberi frametime macet palsu.
        val shared = if (fLayerPkg == pkg) fLayer else ""
        if (shared.isNotEmpty()) {
            if (shared != ftLayer) {
                ftLayer = shared
                if (shared != ftLayerLast) { ftLastTs = 0L; ftPrev.clear() }
                ftLayerLast = shared
            }
        } else if (ftLayer.isEmpty() && now - ftLayerAt > 3000L) {
            ftLayerAt = now
            val l = liveLayers(pkg).sortedByDescending { (if (it.contains("SurfaceView")) 2 else 0) + (if (it.contains("BLAST")) 1 else 0) }.firstOrNull() ?: ""
            if (l != ftLayerLast) { ftLastTs = 0L; ftPrev.clear() }
            ftLayer = l; ftLayerLast = l
        }
        if (ftLayer.isEmpty()) return null
        val rows = sh("dumpsys SurfaceFlinger --latency '$ftLayer'").lines().drop(1).map { it.trim().split(Regex("\\s+")) }
        fun col(c: Int) = rows.mapNotNull { it.getOrNull(c)?.toLongOrNull() }.filter { it in 1 until Long.MAX_VALUE / 2 }.sorted()
        var ts = col(1)
        if (ts.size < 3) ts = col(2)
        if (ts.isEmpty()) { ftLayer = ""; return null }
        if (ftLastTs == 0L) { ftLastTs = ts.last(); return null }
        val fresh = ts.filter { it > ftLastTs }
        if (fresh.isEmpty()) return Ft(0, 0f, 0, 0, emptyList())
        val seq = ArrayList<Long>(fresh.size + 1); seq.add(ftLastTs); seq.addAll(fresh)
        ftLastTs = fresh.last()
        var jank = 0; var big = 0; var mx = 0f; var n = 0
        val d = ArrayList<Float>()
        for (i in 1 until seq.size) {
            val ms = (seq[i] - seq[i - 1]) / 1e6f
            if (ms <= 0f) continue
            if (ms > 2000f) { ftPrev.clear(); continue }   // jeda > 2 detik = loading / layar diam, bukan lag
            n++; d.add(ms); mx = maxOf(mx, ms)
            if (ftPrev.size == 3) {
                val avgPrev = ftPrev.average().toFloat()
                if (ms > 125f && ms > 3f * avgPrev) big++
                else if (ms > 83.33f && ms > 2f * avgPrev) jank++
            }
            ftPrev.addLast(ms); if (ftPrev.size > 3) ftPrev.removeFirst()
        }
        return Ft(n, mx, jank, big, d.sortedDescending().take(12))
    }
}
