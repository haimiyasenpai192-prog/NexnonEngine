package com.nexnon.engine

import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

/** Aksi laporan rekaman (sama seperti PulseMonitor): Bagikan = dua gambar PNG + ringkasan teks, Simpan = satu gambar ringkas ke galeri, CSV ke Download. */
object ReportShare {
    private val main = Handler(Looper.getMainLooper())
    private fun toast(c: Context, msg: String, long: Boolean = false) =
        main.post { Toast.makeText(c, msg, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show() }

    private fun chooser(c: Context, i: Intent) =
        c.startActivity(Intent.createChooser(i, "Bagikan laporan").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    private fun shareSummary(c: Context, s: Session) {
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, Recorder.summary(s)) }
        chooser(c, i)
    }

    /** Bagikan laporan sebagai dua gambar PNG (halaman 1 + grafik, halaman 2) supaya bisa digeser di chat. Gagal membuat gambar -> kirim teks saja. */
    fun share(ctx: Context, s: Session) {
        val c = ctx.applicationContext
        toast(c, "Membuat gambar...")
        Thread {
            val uris = runCatching {
                val dir = File(c.cacheDir, "share").apply { mkdirs() }
                dir.listFiles()?.forEach { it.delete() }
                (0..1).map { part ->
                    val bmp = ShareImage.render(c, s, part)
                    val f = File(dir, "NexnonEngine_${s.id}_${part + 1}.png")
                    f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    FileProvider.getUriForFile(c, "${c.packageName}.files", f)
                }
            }.getOrNull()
            main.post {
                if (uris == null) { runCatching { shareSummary(c, s) }; return@post }
                val i = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = "image/png"
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
                    putExtra(Intent.EXTRA_TEXT, Recorder.summary(s))
                    clipData = ClipData.newRawUri("", uris[0]).also { cd -> uris.drop(1).forEach { cd.addItem(ClipData.Item(it)) } }
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                runCatching { chooser(c, i) }
            }
        }.start()
    }

    /** Simpan laporan sebagai satu gambar PNG ke galeri (Pictures/NexnonEngine), tanpa izin storage. Isinya ringkas: header, statistik, grafik FPS dan Suhu. */
    fun save(ctx: Context, s: Session) {
        val c = ctx.applicationContext
        toast(c, "Menyimpan gambar...")
        Thread {
            val ok = runCatching {
                val bmp = ShareImage.render(c, s, 0, maxCharts = 2)
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, "NexnonEngine_${s.id}_1.png")
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/NexnonEngine")
                }
                val uri = c.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
                c.contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            }.isSuccess
            toast(c, if (ok) "Gambar tersimpan di Pictures/NexnonEngine" else "Gagal menyimpan gambar")
        }.start()
    }

    fun csv(ctx: Context, s: Session) {
        val c = ctx.applicationContext
        Thread {
            val ok = Recorder.exportCsv(c, s)
            toast(c, if (ok) "CSV tersimpan di folder Download" else "Gagal menyimpan CSV")
        }.start()
    }
}
