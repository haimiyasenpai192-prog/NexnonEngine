package com.nexnon.engine

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

/**
 * Gamebar: sidebar melayang di tepi layar saat game di depan (seperti Eternity Engine). Isinya jalan pintas:
 * Overlay FPS, Rekam FPS, Tangkapan layar, Tutup.
 * Layanannya ada di GamebarService; objek ini menyimpan pengaturan dan status "game di depan" dari RecService.
 */
object Gamebar {
    var on by mutableStateOf(false)
    var side by mutableIntStateOf(1)            // 0 = kiri, 1 = kanan
    var gameOnly by mutableStateOf(true)        // hanya tampil saat game di depan
    /** Diisi RecService tiap putaran (paket di depan). */
    @Volatile var inGame = false
    @Volatile private var loaded = false

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences("gamebar", Context.MODE_PRIVATE)

    fun load(c: Context) {
        if (loaded) return
        val p = prefs(c)
        on = p.getBoolean("on", false); side = p.getInt("side", 1).coerceIn(0, 1); gameOnly = p.getBoolean("gameOnly", true)
        loaded = true
    }

    fun save(c: Context) { prefs(c).edit().putBoolean("on", on).putInt("side", side).putBoolean("gameOnly", gameOnly).apply() }

    /** Paket kosong = tidak diketahui, status tidak diubah. */
    fun onForeground(pkg: String) { if (pkg.isNotEmpty()) inGame = pkg in WuWa.PACKAGES }

    /** Nyalakan atau matikan layanan sesuai [on] dan izin "Tampil di atas aplikasi lain". */
    fun sync(ctx: Context) {
        val app = ctx.applicationContext
        load(app)
        val i = Intent(app, GamebarService::class.java)
        if (on && Settings.canDrawOverlays(app)) runCatching { app.startService(i) }
        else app.stopService(i)
    }
}

/** Kartu GAMEBAR di Beranda: status OFF / ON besar, "Sidebar melayang", tombol aktifkan. Tombol i membuka pengaturan. */
@Composable
fun GamebarCard(mod: Modifier) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { Gamebar.load(ctx) }
    var info by remember { mutableStateOf(false) }
    val on = Gamebar.on

    fun flip() {
        if (!Gamebar.on && !Settings.canDrawOverlays(ctx)) { OverlayService.openPermission(ctx); return }
        Gamebar.on = !Gamebar.on; Gamebar.save(ctx); Gamebar.sync(ctx)
        if (Gamebar.on) RecService.ensureRunning(ctx)
    }

    Card2(mod) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Ico(5, if (on) CYAN else MUT, 20.dp)
            Spacer(Modifier.width(8.dp))
            T("GAMEBAR", 15, TX, true, Modifier.weight(1f), 1)
            Box(Modifier.size(28.dp).clip(CircleShape).background(Color(0xFF1B2540)).clickable { info = true }, contentAlignment = Alignment.Center) {
                T("i", 14, Color(0xFF6FA8FF), true)
            }
        }
        Sp(6)
        T(if (on) "ON" else "OFF", 40, if (on) PINK_LT else Color.White, true)
        T("Sidebar melayang", 13, MUT, maxLines = 1)
        Sp(12)
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF23252D))
            .clickable { flip() }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
            T(if (on) "MATIKAN" else "AKTIFKAN", 13, Color.White, true)
        }
    }

    if (info) TabDialog("Gamebar", "Sidebar melayang di atas game", { info = false }) {
        SettingCard("Tampil") {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("Hanya saat di game", 14, Color.White, true)
                    T("Sembunyi di aplikasi lain. Pendeteksi game ada di Notifikasi pantauan, jadi nyalakan itu juga.", 12, Color.White)
                }
                Toggle(Gamebar.gameOnly) { v -> Gamebar.gameOnly = v; Gamebar.save(ctx) }
            }
        }
        SettingCard("Sisi layar") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QChip("Kiri", Gamebar.side == 0) { Gamebar.side = 0; Gamebar.save(ctx) }
                QChip("Kanan", Gamebar.side == 1) { Gamebar.side = 1; Gamebar.save(ctx) }
            }
        }
        SettingCard("Isi sidebar") {
            T("Overlay FPS, Rekam FPS, Tangkapan layar, dan Tutup.", 12, Color.White)
            T("Ketuk pegangan di tepi layar untuk membuka. Geser pegangan untuk memindah; saat dilepas ia menempel ke sisi terdekat.", 12, Color.White)
        }
    }
}
