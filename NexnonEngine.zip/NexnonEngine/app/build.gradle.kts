plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.nexnon.engine"
    compileSdk = 34
    defaultConfig { applicationId = "com.nexnon.engine"; minSdk = 29; targetSdk = 34; versionCode = 1; versionName = "0.1" }
    buildTypes {
        release {
            // Tanpa R8/minify: Shell memanggil Shizuku.newProcess lewat refleksi, bisa rusak kalau namanya diacak
            isMinifyEnabled = false
            isDebuggable = false
            // Sama seperti Pulse Monitor: ditandatangani kunci debug supaya APK release bisa langsung dipasang
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    buildFeatures { compose = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
