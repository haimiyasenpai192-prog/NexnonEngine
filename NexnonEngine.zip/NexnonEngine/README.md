# Nexnon Engine (Android)

Build lewat GitHub: push folder ini, lalu jalankan workflow *Build APK* di tab Actions.

- Akses: Shizuku atau Root (Settings > Akses). Dipakai untuk menulis config ke folder game.
- Beranda: kartu perangkat, target FPS, grafik FPS layar app ini, **Rekam FPS game** (daftar Rekaman + laporan).
- Statistik: gaya Pulse Monitor. Kartu Memori (RAM + ZRAM, ukuran RAM di kotak) yang bisa digeser ke Status CPU (frekuensi tiap inti, beban, governor, grafik), lalu grid Baterai / Jaringan / RAM / Penyimpanan; ketuk kotak untuk rincian. Memori, baterai, jaringan, dan penyimpanan dibaca tanpa Shizuku/Root; Status CPU butuh akses (atau ikut pembacaan perekam saat merekam).
- Config: daftar game, panel Kualitas (Ultra/High/Medium) dan tombol Install (backup otomatis ke .bak).
- Ganti NAMA.PAKET di Detail config dengan nama paket game sebelum Install.

## Wuthering Waves
- Config diimpor dari zip di HP (kartu Wuthering Waves > Impor / Ganti). Satu zip = satu versi (nama file = nama versi, mis. v1.0.zip).
- Susunan zip: `[ 1 ] Flagship/`, `Balanced/[ 1 ] High/`, `Balanced/[ 2 ] Medium/`, atau langsung `ultra/ high/ medium/`, atau file .ini di root.
- File yang dikenali: Engine.ini, DeviceProfiles.ini, Scalability.ini, GameUserSettings.ini (satu file tambahan dari zip ikut dipasang otomatis dan tidak ditampilkan di daftar).
- Tujuan: Android/data/<paket>/files/UE4Game/Client/Client/Saved/Config/Android, ditambah satu folder Engine game untuk file tambahan.
- Setiap file ditulis lewat Shizuku/Root lalu dibaca ulang untuk verifikasi.

### Kotak hasil
Di halaman Wuthering Waves, kotak di bawah tombol Install terisi otomatis: spinner saat memasang, lalu centang/silang per file setelah dibaca ulang dari folder game (OK, tidak ada, kosong, atau isi berbeda). Cek status dan Hapus config juga memakai kotak ini. Kalau gagal, tombol Log menampilkan riwayat dan bisa disalin.

## Rekam FPS game + notifikasi pantauan (dari Pulse Monitor)
- **Rekam FPS**: kartu di Beranda atau tombol **Rekam** di Gamebar. Buka game, FPS game itu yang diukur (bukan layar app ini). Butuh Shizuku atau Root.
- Sumber FPS: TaskFps (daemon hak shell, Android 14+) -> cadangan SurfaceFlinger timestats -> cadangan `--latency`. Frametime asli per frame dipakai untuk 5% / 1% low, Jank, BigJank (definisi PerfDog).
- **Rekaman** (ikon daftar di kartu): ikon game, nama, tanggal, rata-rata FPS, durasi, grafik mini, chip Min / 5% low / Maks. Ketuk untuk laporan: statistik, grafik, catatan, Bagikan, Simpan CSV (Download), Hapus. Data di `filesDir/records/*.json`.
- **Notifikasi pantauan**: ringkas (persen, nama app di depan + status, arus, daya, suhu) dan diperluas (bilah, Layar Nyala / Mati / Tidur lelap, laju kuras Aktif / Diam). Atur di Settings > Notifikasi pantauan.
- Izin: notifikasi (Android 13+), dan opsional "Tampil di atas aplikasi lain" (jangkar 1x1 agar HyperOS tidak membekukan proses). Izin akses penggunaan diberikan otomatis lewat Shizuku/Root.
- Belum dibawa dari Pulse Monitor: overlay FPS di atas game, kolom resolusi game, suhu/CPU/GPU di rekaman, gambar laporan, penjaga di luar proses (Watchdog).

## Perbaikan: FPS / CPU / GPU overlay tidak lagi beku (disamakan dengan Pulse Monitor)
- Penyebab (dari video): tick Sampler keluar lebih awal bila aplikasi fokus diabaikan (TikTok, SystemUI) atau pengukuran gagal sesaat, sebelum overlay diperbarui. Akibatnya FPS 0 dan angka CPU / GPU menempel.
- Sekarang sensor selalu dibaca dan overlay selalu diperbarui tiap tick. Fokus yang diabaikan tidak menghentikan pengukuran: dipakai layer paling aktif (busiestLayerPkg), atau fokus tetap diukur.
- Gagal ukur bukan 0 FPS: nilai terakhir ditahan (3 tick untuk 0 sungguhan, 6 tick untuk gagal ukur). Aplikasi non-game yang diam menampilkan refresh rate layar, bukan 0.
- Jalur cepat (Sampler.fastTick, 1 proses shell per detik) untuk FPS / CPU / GPU dan frekuensinya, langsung ke overlay, seperti Pulse Monitor.
- Semua perintah shell Sampler dibatasi waktu (3,5 dtk, maks 4 menggantung) lewat Shell.execLimited, supaya dumpsys macet tidak membekukan putaran.
- Belum dikompilasi / diuji di perangkat; cek hasil build GitHub.

## Gamebar (menggantikan kartu Cuaca di Beranda)
- Beranda: kartu **GAMEBAR** (status OFF / ON, "Sidebar melayang", tombol Aktifkan / Matikan) di samping kartu Suhu. Tombol **i** membuka pengaturan: Hanya saat di game, sisi layar (kiri / kanan).
- Aktif = pegangan tipis di tepi layar. Ketuk untuk membuka kolom tombol; geser untuk memindah (menempel ke sisi terdekat); ketuk di luar untuk menutup.
- Tombol: **Overlay** (nyala / mati overlay FPS), **Rekam** (mulai / berhenti rekam FPS), **Layar** (tangkapan layar sistem lewat `input keyevent 120`, kolom ditutup dulu supaya tidak ikut terfoto), **Tutup** (matikan Gamebar).
- Bawaan hanya tampil saat Wuthering Waves di depan. Pendeteksi game memakai putaran RecService, jadi Notifikasi pantauan harus aktif; bila layanan itu mati, sidebar tetap tampil supaya tidak hilang tanpa sebab.
- Butuh izin "Tampil di atas aplikasi lain" (diminta saat pertama diaktifkan). Layanan baru: GamebarService (tanpa notifikasi sendiri; prosesnya dijaga notifikasi pantauan), hidup lagi setelah HP menyala.
- Kartu Cuaca dan pemanggilnya dihapus dari Beranda. Weather.kt dan izin lokasi / internet masih ada di proyek tapi tidak dipakai; aman dihapus kalau mau.
- Belum dikompilasi / diuji di perangkat. Tombol tangkapan layar bergantung pada ROM (HyperOS umumnya mengenali keyevent 120).
