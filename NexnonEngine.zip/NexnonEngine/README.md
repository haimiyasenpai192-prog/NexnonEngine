# Nexnon Engine (Android)

Build lewat GitHub: push folder ini, lalu jalankan workflow *Build APK* di tab Actions.

- Akses: Shizuku atau Root (Settings > Akses). Dipakai untuk menulis config ke folder game.
- Beranda: kartu perangkat, target FPS, grafik FPS layar app ini, rekam FPS.
- Config: daftar game, panel Kualitas (Ultra/High/Medium) dan tombol Install (backup otomatis ke .bak).
- Ganti NAMA.PAKET di Detail config dengan nama paket game sebelum Install.

## Wuthering Waves
- Config diimpor dari zip di HP (kartu Wuthering Waves > Impor / Ganti). Satu zip = satu versi (nama file = nama versi, mis. v1.0.zip).
- Susunan zip: `[ 1 ] Flagship/`, `Balanced/[ 1 ] High/`, `Balanced/[ 2 ] Medium/`, atau langsung `ultra/ high/ medium/`, atau file .ini di root.
- File yang dikenali: Engine.ini, DeviceProfiles.ini, Scalability.ini, GameUserSettings.ini (satu file tambahan dari zip ikut dipasang otomatis dan tidak ditampilkan di daftar).
- Tujuan: Android/data/<paket>/files/UE4Game/Client/Client/Saved/Config/Android, ditambah satu folder Engine game untuk file tambahan.
- Setiap file ditulis lewat Shizuku/Root lalu dibaca ulang untuk verifikasi.

### Kotak hasil
Di halaman Wuthering Waves, kotak di bawah tombol Install terisi otomatis: spinner saat memasang, lalu centang/silang per file setelah dibaca ulang dari folder game (OK, tidak ada, kosong, atau isi berbeda). Cek status dan Hapus config juga memakai kotak ini. Kalau gagal, tombol Log menampilkan riwayat dan bisa disalin.
