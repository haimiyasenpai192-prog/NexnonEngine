package com.nexnon.engine

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.RemoteViews
import kotlinx.coroutines.*

/**
 * Layanan latar depan: notifikasi baterai (ringkas + diperluas),
 * seperti Pulse Monitor. Ringkas: persen, status, arus, daya, suhu. Diperluas: bilah, Layar Nyala / Mati / Tidur lelap, laju kuras.
 */
class RecService : Service() {
    companion object {
        const val ACTION_REC = "com.nexnon.engine.REC"
        const val ACTION_PANEL = "com.nexnon.engine.PANEL"
        const val ACTION_COLLAPSE = "com.nexnon.engine.COLLAPSE"
        const val ACTION_RESTORE = "com.nexnon.engine.RESTORE"
        const val ACTION_FG = "com.nexnon.engine.FG"
        private const val CH = "monitor2"   // channel baru: HyperOS menyimpan icon notifikasi lama (N) per channel/id
        private const val NID = 11

        @Volatile var alive = false
        /** Nama aplikasi yang sedang tampil di notifikasi (untuk pemeriksaan kesehatan). */
        @Volatile var fgShown = ""

        /** Alarm sekali untuk menghidupkan layanan lagi bila proses dimatikan sistem. Gagal = diabaikan (START_STICKY tetap cadangan). */
        fun scheduleRestore(ctx: Context, delayMs: Long) {
            runCatching {
                val app = ctx.applicationContext
                val pi = PendingIntent.getForegroundService(app, 77, Intent(app, RecService::class.java).setAction(ACTION_RESTORE),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                val am = app.getSystemService(AlarmManager::class.java)
                val at = SystemClock.elapsedRealtime() + delayMs
                // Alarm tidak tepat di Android 12+ tidak boleh memulai layanan latar depan; alarm tepat boleh.
                runCatching { am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi) }
                    .onFailure { am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi) }
            }
        }

        /** Dipanggil saat aplikasi dibuka atau HP menyala: bila notifikasi pantauan nyala, hidupkan (atau pasang ulang) layanan. */
        fun ensureRunning(ctx: Context) {
            runCatching {
                val app = ctx.applicationContext
                MonitorPrefs.load(app)
                if (MonitorPrefs.notifOn) {
                    app.startForegroundService(Intent(app, RecService::class.java).setAction(ACTION_RESTORE))
                    Watchdog.sync(app, true)   // penjaga di luar proses: menghidupkan notifikasi lagi + membangunkan nama aplikasi
                }
            }.onFailure { AppLog.w("Layanan", "ensureRunning gagal: ${it.javaClass.simpleName} ${it.message}") }
        }

        fun stop(ctx: Context) {
            runCatching { Watchdog.sync(ctx, false) }
            runCatching { ctx.applicationContext.stopService(Intent(ctx.applicationContext, RecService::class.java)) }
        }
    }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob() + CoroutineExceptionHandler { _, e ->
        AppLog.w("Layanan", "coroutine gagal: ${e.javaClass.simpleName} ${e.message}")
    })
    private var screenRx: BroadcastReceiver? = null
    private var batteryRx: BroadcastReceiver? = null
    private var loopJob: Job? = null
    private var anchor: View? = null
    private var anchorFailed = false

    @Volatile private var fgLabel = ""
    private var fgPkg = ""
    private val labelCache = HashMap<String, String>()
    private fun labelOf(pkg: String): String = labelCache.getOrPut(pkg) {
        runCatching { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
    }

    /**
     * Bolak-balik antara dua layout kembar tiap pembaruan. Di HyperOS, pembaruan RemoteViews dengan layout yang SAMA tidak tampil
     * di shade (angka beku); layout beda id memaksa pemasangan ulang tampilan.
     */
    private var notifFlip = false

    override fun onBind(i: Intent?): IBinder? = null

    // ---------- Notifikasi ----------
    private fun pi(code: Int, action: String) = PendingIntent.getService(this, code, Intent(this, RecService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun immediate(nb: Notification.Builder) {
        if (Build.VERSION.SDK_INT >= 31) nb.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
    }

    /** Notifikasi paling sederhana, dipakai untuk startForeground supaya tidak pernah gagal. */
    private fun safeNotif(): Notification {
        val nb = Notification.Builder(this, CH).setSmallIcon(R.drawable.ic_stat_nexnon)
            .setContentTitle("Astra Engine").setContentText("Berjalan di latar belakang")
            .setOnlyAlertOnce(true).setShowWhen(false).setOngoing(true)
        immediate(nb)
        return nb.build()
    }

    private fun buildNotif(): Notification {
        val rec = Recorder.active
        // Ketuk notifikasi: panel kecil melayang (Overlay + Rekam FPS). Tanpa izin overlay, buka aplikasi seperti biasa.
        val tap = if (Settings.canDrawOverlays(this)) pi(6, ACTION_PANEL)
            else PendingIntent.getActivity(this, 2, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)   // panel butuh izin Tampil di atas aplikasi lain
        val b = runCatching { BatteryStats.tick() }.getOrNull()
        val head = if (rec) "● Merekam FPS" else "Astra Engine"
        val nb = Notification.Builder(this, CH).setSmallIcon(R.drawable.ic_stat_nexnon).setColor(0xFFFFFFFF.toInt())
            .setContentTitle(head).setContentText(b?.line2 ?: "Berjalan di latar belakang")   // cadangan untuk tampilan tanpa layout kustom
            .setOnlyAlertOnce(true).setShowWhen(false).setContentIntent(tap).setOngoing(true)
        immediate(nb)
        if (b != null) {
            val pctTxt = if (b.pct >= 0) "${b.pct}%" else "-"
            // Nama aplikasi + status dalam satu teks yang boleh turun ke baris kedua ("Claude  Tidak mengisi daya")
            val app = if (MonitorPrefs.notifApp) fgLabel else ""
            val statusLine = (if (rec) "● Merekam FPS • " else "") + (if (app.isEmpty()) "" else "$app  ") + b.status
            val subLine = (if (rec && Recorder.lastFps > 0) listOf("${Recorder.lastFps} FPS") else emptyList<String>())
                .plus(listOf(b.current, b.power, b.temp).filter { it != "-" }).joinToString(" • ").ifEmpty { "-" }
            val small = RemoteViews(packageName, if (notifFlip) R.layout.notif_collapsed_b else R.layout.notif_collapsed).apply {
                setTextViewText(R.id.n_pct, pctTxt)
                setTextViewText(R.id.n_title, statusLine)
                setTextViewText(R.id.n_sub, subLine)
            }
            val big = RemoteViews(packageName, if (notifFlip) R.layout.notif_expanded_b else R.layout.notif_expanded).apply {
                setTextViewText(R.id.n_pct, pctTxt)
                setTextViewText(R.id.n_title, statusLine)
                setProgressBar(R.id.n_bar, 100, b.pct.coerceAtLeast(0), false)
                setTextViewText(R.id.n_cur, b.current); setTextViewText(R.id.n_pow, b.power); setTextViewText(R.id.n_tmp, b.temp)
                setTextViewText(R.id.n_on, b.screenOn); setTextViewText(R.id.n_on_d, b.screenOnDetail)
                setTextViewText(R.id.n_off, b.screenOff); setTextViewText(R.id.n_off_d, b.screenOffDetail)
                setTextViewText(R.id.n_deep, b.deep); setTextViewText(R.id.n_awake, "Terjaga ${b.awake}")
                setTextViewText(R.id.n_act, b.activeRate); setTextViewText(R.id.n_idle, b.idleRate)
                setOnClickPendingIntent(R.id.n_chev, pi(3, ACTION_COLLAPSE))   // panah: kembali ke tampilan ringkas
            }
            nb.setStyle(Notification.DecoratedCustomViewStyle())
            nb.setCustomContentView(small).setCustomBigContentView(big)
        }
        return nb.build()
    }

    private fun fg(n: Notification) {
        if (Build.VERSION.SDK_INT >= 34) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(NID, n)
    }

    /** Pembaruan lewat startForeground() id sama (di HyperOS notify() biasa untuk notifikasi layanan tidak ikut tampil); notify() hanya cadangan. */
    private fun refreshNotif() {
        if (!alive) return
        notifFlip = !notifFlip
        val n = runCatching { buildNotif() }.getOrElse { AppLog.w("Notifikasi", "buildNotif gagal: ${it.message}"); return }
        val ok = runCatching { fg(n) }.isSuccess
        if (!ok) runCatching { getSystemService(NotificationManager::class.java).notify(NID, n) }
    }

    /** Ciutkan notifikasi: dilepas lalu dipasang ulang, entri baru selalu mulai ringkas. */
    private fun collapseNotif() {
        if (!alive) return
        runCatching { stopForeground(Service.STOP_FOREGROUND_REMOVE) }
        scope.launch { delay(120L); refreshNotif() }
    }

    // ---------- Panel kontrol melayang ----------
    private var panel: View? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun hidePanel() {
        panel?.let { v -> runCatching { getSystemService(WindowManager::class.java).removeView(v) } }
        panel = null
    }

    /** Panel kontrol melayang bergaya kaca: FPS langsung, tombol geser Overlay, dan Rekam FPS. Ketuk di luar atau X untuk menutup. */
    private fun showPanel() {
        if (!Settings.canDrawOverlays(this)) { AppLog.w("Layanan", "panel tidak tampil: izin Tampil di atas aplikasi lain belum ada"); return }
        panel?.let { v ->
            if (v.isAttachedToWindow) return          // sudah tampil
            panel = null                              // panel basi (dilepas sistem): buat ulang
        }
        OverlayPrefs.load(this)
        val white = 0xFFFFFFFF.toInt(); val dim = 0xFFB4B8C2.toInt()
        val violet = 0xFF8B7BE8.toInt(); val pink = 0xFFD66FC8.toInt(); val red = 0xFFE5484D.toInt(); val redLt = 0xFFF2788A.toInt()
        fun shape(c: Int, r: Int, stroke: Int = 0) = android.graphics.drawable.GradientDrawable().apply {
            setColor(c); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
        }
        fun grad(a: Int, b: Int, r: Int) = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(a, b)).apply { cornerRadius = dp(r).toFloat() }
        fun lp(w: Int, h: Int, wt: Float = 0f) = android.widget.LinearLayout.LayoutParams(w, h, wt)
        fun tv(t: String, sz: Float, c: Int, bold: Boolean = false) = android.widget.TextView(this).apply {
            text = t; textSize = sz; setTextColor(c); if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

        val root = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = shape(0x6617181E.toInt(), 28, 0x40FFFFFF)   // latar transparan (kaca), tepi tipis
            elevation = dp(16).toFloat()
        }

        // Kepala: logo A, judul + keterangan, chip FPS langsung, tombol tutup
        val head = android.widget.LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("A", 18f, white, true).apply { gravity = Gravity.CENTER; background = grad(violet, pink, 12) }, lp(dp(40), dp(40)))
        val titles = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        titles.addView(tv("Astra Engine", 16f, white, true))
        titles.addView(tv("Kontrol cepat", 12f, dim))
        head.addView(titles, lp(0, -2, 1f))
        val fpsChip = tv("-- FPS", 12f, white, true).apply { setPadding(dp(10), dp(5), dp(10), dp(5)); background = shape(0x26FFFFFF, 14) }
        head.addView(fpsChip, lp(-2, -2).apply { marginEnd = dp(8) })
        head.addView(tv("\u2715", 15f, white).apply { gravity = Gravity.CENTER; background = shape(0x26FFFFFF, 18); setOnClickListener { hidePanel() } }, lp(dp(36), dp(36)))
        root.addView(head)

        // Kartu Overlay
        val card = android.widget.LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12)); background = shape(0x14FFFFFF, 18, 0x1AFFFFFF) }
        val ovTxt = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL }
        ovTxt.addView(tv("Overlay FPS", 14f, white, true))
        ovTxt.addView(tv("Tampil di atas game", 12f, dim))
        card.addView(ovTxt, lp(0, -2, 1f))
        val sw = android.widget.Switch(this).apply {
            isChecked = OverlayPrefs.on
            val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            thumbTintList = android.content.res.ColorStateList(st, intArrayOf(white, 0xFFD0D3D8.toInt()))
            trackTintList = android.content.res.ColorStateList(st, intArrayOf(violet, 0xFF4A4C54.toInt()))
        }
        sw.setOnCheckedChangeListener { b, on ->
            if (on && !Settings.canDrawOverlays(this)) { b.isChecked = false; return@setOnCheckedChangeListener }
            if (OverlayPrefs.on != on) { OverlayPrefs.on = on; OverlayPrefs.save(this); OverlayService.sync(this) }
        }
        card.addView(sw)
        root.addView(card, lp(-1, -2).apply { topMargin = dp(14) })

        // Tombol rekam: gradasi ungu-pink saat siap, merah saat merekam
        val rec = tv("", 15f, white, true).apply { gravity = Gravity.CENTER }
        fun paintRec() {
            val on = Recorder.active
            rec.text = if (on) "\u25A0  Stop rekam" else "\u25CF  Rekam FPS"
            rec.background = if (on) grad(red, redLt, 18) else grad(violet, pink, 18)
        }
        paintRec()
        rec.setOnClickListener {
            val wasActive = Recorder.active
            RecCtl.toggle(this)
            if (!wasActive) hidePanel()   // mulai rekam: panel ditutup supaya game kembali bersih di depan
            else scope.launch { delay(400L); paintRec(); delay(1200L); paintRec() }
        }
        root.addView(rec, lp(-1, dp(50)).apply { topMargin = dp(12) })

        root.setOnTouchListener { _, e -> if (e.action == android.view.MotionEvent.ACTION_OUTSIDE) hidePanel(); false }
        val wlp = WindowManager.LayoutParams(dp(320), WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER }
        // Android 12+: buramkan isi di belakang panel (efek kaca) bila perangkat mendukung; kalau tidak, diabaikan
        if (Build.VERSION.SDK_INT >= 31) { wlp.flags = wlp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND; wlp.blurBehindRadius = dp(24) }
        runCatching {
            getSystemService(WindowManager::class.java).addView(root, wlp); panel = root
            AppLog.i("Layanan", "panel ditampilkan")
            // Muncul halus, dan angka FPS diperbarui tiap detik selama panel terbuka
            root.alpha = 0f; root.scaleX = 0.92f; root.scaleY = 0.92f
            root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180L).start()
            scope.launch { while (panel === root) { val f = Sampler.live.value?.fps ?: 0; fpsChip.text = if (f > 0) "$f FPS" else "-- FPS"; delay(1000L) } }
        }.onFailure { AppLog.w("Layanan", "panel gagal: ${it.javaClass.simpleName} ${it.message}") }
    }

    // ---------- Jangkar jendela 1x1 ----------
    /**
     * Proses yang punya jendela overlay terlihat dinilai sistem sebagai "terlihat", bukan proses latar belakang, jadi tidak dibekukan
     * HyperOS saat aplikasi lain di depan (penyebab nama aplikasi di notifikasi diam). Hanya bila izin "tampil di atas aplikasi lain" ada.
     */
    private fun syncAnchor() {
        val want = MonitorPrefs.notifApp && Settings.canDrawOverlays(this)
        if (!want) { anchorFailed = false; removeAnchor(); return }
        if (anchor != null || anchorFailed) return
        runCatching {
            val v = View(this)
            val lp = WindowManager.LayoutParams(1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
            getSystemService(WindowManager::class.java).addView(v, lp)
            anchor = v
        }.onFailure { anchorFailed = true; AppLog.w("Layanan", "jangkar jendela gagal: ${it.javaClass.simpleName} ${it.message}") }
    }

    private fun removeAnchor() {
        anchor?.let { v -> runCatching { getSystemService(WindowManager::class.java).removeView(v) } }
        anchor = null
    }

    // ---------- Pemantau latar ----------
    // Koreksi yang berbeda dari riwayat penggunaan (dari dumpsys): berlaku sampai ada kejadian riwayat baru
    @Volatile private var ovFor = ""
    @Volatile private var ovPkg = ""

    /** Nama aplikasi di depan dari penjaga di luar proses (kandidat dipisah koma; yang pertama bukan jendela sementara dipakai). */
    private fun applyFgFromShell(pkgs: String) {
        if (!MonitorPrefs.notifApp) return
        val p = pkgs.split(",").firstOrNull { it.isNotEmpty() && !Sampler.isTransientPkg(it, "") } ?: return
        if (p == fgPkg) return
        val u = if (Foreground.hasAccess(this)) Foreground.top(this).orEmpty() else ""
        if (u.isNotEmpty() && u != p) { ovFor = u; ovPkg = p }     // supaya putaran dalam proses tidak mengembalikannya ke nama lama
        fgPkg = p; fgLabel = labelOf(p); fgShown = fgLabel
        AppLog.i("AppDepan", "dari penjaga luar: \"$fgLabel\" ($p)")
    }
    private var lastDump = 0L
    private var lastDiag = ""

    /**
     * Paket di depan untuk nama di notifikasi (logika disamakan dengan PulseMonitor). Riwayat penggunaan cepat (milidetik) tapi hanya mencatat
     * aktivitas yang baru dibuka/dilanjutkan; aplikasi yang dibawa ke depan tanpa kejadian baru (jendela mengambang/PiP, atau >3 menit
     * sejak kejadian terakhir) tidak terbaca dan nama tertinggal di "POCO Launcher". Maka dumpsys (fokus jendela sebenarnya) tetap dicek
     * tiap 3 detik sebagai penentu. Koreksi dumpsys bertahan sampai riwayat melaporkan kejadian baru. Panggil dari thread latar.
     */
    private fun readForeground(): String {
        val fast = Foreground.ensureAccess(this)
        val u = if (fast) Foreground.top(this).orEmpty() else ""
        if (ovFor.isNotEmpty() && u != ovFor) { ovFor = ""; ovPkg = "" }     // ada kejadian baru: riwayat penggunaan dipercaya lagi
        var p = if (ovFor.isNotEmpty()) ovPkg else u
        var d = if (ovFor.isNotEmpty()) "dumpsys -> $ovPkg (riwayat penggunaan masih: $u)" else if (u.isNotEmpty()) "riwayat penggunaan -> $u" else ""
        val now = SystemClock.elapsedRealtime()
        if (Shell.mode() != "-" && (!fast || u.isEmpty() || now - lastDump >= 3_000L)) {
            lastDump = now
            val w = runCatching { Sampler.foregroundPkg() }.getOrDefault("")
            val u2 = if (fast) Foreground.top(this).orEmpty() else ""
            if (w.isNotEmpty() && !Sampler.isTransientPkg(w, "") && u2 == u) {   // u2 != u: ada kejadian baru selama dumpsys berjalan, hasilnya basi
                if (w != u && u.isNotEmpty()) { ovFor = u; ovPkg = w; d = "dumpsys -> $w (riwayat penggunaan: $u) ${Sampler.focusDiag}" }
                else { ovFor = ""; ovPkg = ""; if (u.isEmpty()) d = Sampler.focusDiag }
                p = w
            }
        }
        if (d.isNotEmpty() && d != lastDiag) { lastDiag = d; AppLog.i("AppDepan", d) }
        return p
    }

    private fun startHousekeeping() {
        val rx = object : BroadcastReceiver() {
            override fun onReceive(c: Context, intent: Intent) {
                if (intent.action != Intent.ACTION_USER_PRESENT) runCatching { BatteryStats.setScreen(intent.action == Intent.ACTION_SCREEN_ON) }
                refreshNotif()
                // Data baterai dari sistem sering baru terbarui beberapa saat setelah layar menyala: segarkan lagi
                if (intent.action != Intent.ACTION_SCREEN_OFF) scope.launch { delay(500L); refreshNotif(); delay(1500L); refreshNotif() }
            }
        }
        registerReceiver(rx, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_USER_PRESENT)
        })
        screenRx = rx

        // Persen / status / charger / suhu berubah: perbarui seketika. Perubahan kecil dibatasi 2 detik, dengan satu pembaruan tertunda
        val brx = object : BroadcastReceiver() {
            private var lastKey = ""; private var lastAt = 0L; private var pending: Job? = null
            override fun onReceive(c: Context, intent: Intent) {
                val key = "${intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)}|${intent.getIntExtra(BatteryManager.EXTRA_STATUS, 0)}|" +
                    "${intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)}|${intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)}"
                val now = SystemClock.elapsedRealtime()
                val screenOn = BatteryStats.isScreenOn()
                if (key != lastKey || (screenOn && now - lastAt > 2000L)) {
                    lastKey = key; lastAt = now; pending?.cancel(); pending = null; refreshNotif()
                } else if (screenOn && pending?.isActive != true) {
                    val wait = (2000L - (now - lastAt)).coerceAtLeast(100L)
                    pending = scope.launch { delay(wait); lastAt = SystemClock.elapsedRealtime(); refreshNotif() }
                }
            }
        }
        registerReceiver(brx, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        batteryRx = brx

        // Penyegaran berkala (layar nyala 2 dtk, mati 30 dtk), seperti Pulse Monitor
        scope.launch {
            while (isActive) {
                syncAnchor()
                val on = BatteryStats.isScreenOn()
                if (on) refreshNotif() else runCatching { BatteryStats.tick() }
                delay(if (on) 2000L else 30_000L)
            }
        }

        // Nama aplikasi di depan + keadaan rekam: dibaca tiap ~1,5 detik di thread latar, hanya saat layar nyala.
        // Notifikasi hanya dipasang ulang bila ada yang berubah.
        loopJob = scope.launch {
            var shown = "\u0000"; var lastRec = Recorder.active; var lastSec = -1
            while (isActive) {
                if (BatteryStats.isScreenOn()) {
                    if (MonitorPrefs.notifApp) {
                        if (Recorder.active) {
                            // Saat merekam Sampler sudah membaca paket di depan; jangan jalankan dumpsys dua kali
                            val g = Sampler.lastGamePkg(); if (g.isNotEmpty()) { fgLabel = labelOf(g) }
                        } else if (Shell.mode() != "-" || Foreground.hasAccess(this@RecService)) {
                            val p = withContext(Dispatchers.IO) { readForeground() }
                            if (p.isNotEmpty() && !Sampler.isTransientPkg(p, "")) { fgPkg = p; fgLabel = labelOf(p) }
                        }
                    } else fgLabel = ""
                    val rec = Recorder.active
                    val sec = if (rec) Recorder.count else -1
                    if (fgLabel != shown || rec != lastRec || sec != lastSec) {
                        shown = fgLabel; lastRec = rec; lastSec = sec; fgShown = fgLabel
                        refreshNotif()
                    }
                }
                delay(if (!Recorder.active && Foreground.hasAccess(this@RecService)) 700L else 1500L)
            }
        }
    }

    // ---------- Siklus hidup ----------
    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        val act = i?.action
        if (act == ACTION_COLLAPSE && alive) { collapseNotif(); return START_STICKY }
        // 1) Channel + startForeground SEGERA dengan notifikasi sederhana (batas waktu sistem ~10 detik)
        runCatching {
            getSystemService(NotificationManager::class.java)
                .apply {
                    runCatching { deleteNotificationChannel("monitor"); cancel(1) }   // buang channel dan notifikasi lama
                    createNotificationChannel(NotificationChannel(CH, "Pantauan", NotificationManager.IMPORTANCE_LOW))
                }
        }
        runCatching { fg(safeNotif()) }.onFailure { AppLog.w("Layanan", "startForeground gagal: ${it.javaClass.simpleName} ${it.message}") }
        MonitorPrefs.load(this)
        if (!MonitorPrefs.notifOn) { stopSelf(); return START_NOT_STICKY }
        Access.init(this)
        BatteryStats.init(this)
        if (!alive) {
            alive = true
            startHousekeeping()
            AppLog.i("Layanan", "notifikasi pantauan dimulai")
        }
        syncAnchor()
        if (act == ACTION_PANEL) showPanel()
        if (act == ACTION_FG) applyFgFromShell(i?.getStringExtra("pkgs").orEmpty())
        // 2) Ganti dengan versi lengkap (bila gagal, yang sederhana tetap tampil)
        refreshNotif()
        if (act == ACTION_REC) RecCtl.toggle(this)
        scope.launch { delay(300L); refreshNotif(); if (act == ACTION_REC) { delay(1200L); refreshNotif() } }
        return START_STICKY
    }

    /** Aplikasi di-swipe dari recents: sebagian ROM (MIUI / HyperOS) mematikan layanan juga; jadwalkan alarm pulih. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        MonitorPrefs.load(this)
        if (MonitorPrefs.notifOn) scheduleRestore(this, 1500L)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        AppLog.i("Layanan", "berhenti (onDestroy)")
        hidePanel(); removeAnchor()
        screenRx?.let { runCatching { unregisterReceiver(it) } }; screenRx = null
        batteryRx?.let { runCatching { unregisterReceiver(it) } }; batteryRx = null
        loopJob?.cancel()
        scope.cancel()
        alive = false
        super.onDestroy()
    }
}
