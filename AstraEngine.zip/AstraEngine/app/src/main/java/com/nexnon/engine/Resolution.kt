package com.nexnon.engine

import android.content.Context
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.view.Display
import kotlin.math.max
import kotlin.math.min

/**
 * Resolusi untuk header laporan ("1080x2336"): RESOLUSI RENDER GAME, bukan ukuran layar HP. Caranya sama dengan PulseMonitor:
 * ukuran buffer layer game di `dumpsys SurfaceFlinger` dibaca berkali-kali selama rekaman, lalu yang paling sering terbaca dipakai.
 * Ukuran layar HP TIDAK dipakai sebagai cadangan: bila resolusi game tidak terbaca, kolom resolusi dikosongkan
 * (daripada menampilkan resolusi layar yang menyesatkan). Butuh Shizuku / Root. Format selalu sisi pendek x sisi panjang (1080x2336).
 */
object Resolution {
    /** Layer milik paket game yang BUKAN layar render game: latar, splash, letterbox, dim. Ukurannya memenuhi layar HP. */
    private val SKIP_LAYER = Regex("""Background for|Splash Screen|Letterbox|Dim Layer|Starting """)
    /** Header layer format Android 14+/16: "Layer [id] nama", boleh berindentasi / diawali "+ " atau "* ". */
    private val LAYER_HDR = Regex("""^\s*(?:[+*]\s+)?Layer \[\d+]""")
    private val SRC_CROP_RE = Regex("""sourceCrop=\[\s*(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s*]""")
    private val BUF_RE = Regex("""activeBuffer=\[\s*(\d+)\s*x\s*(\d+)""")
    private val BUF_RE2 = Regex("""(?i)buffer\w*[ =:\[(]+\s*(\d{3,5})\s*[x\u00d7]\s*(\d{3,5})""")

    private fun fmt(p: Pair<Int, Int>) = "${min(p.first, p.second)}x${max(p.first, p.second)}"

    /** Ubah teks resolusi lama ("1080x2336") ke format baru sisi pendek x sisi panjang ("1080x2336"). */
    fun normalizeText(s: String): String {
        val m = Regex("""^\s*(\d+)\s*[x\u00d7]\s*(\d+)\s*$""").find(s) ?: return s
        val a = m.groupValues[1].toIntOrNull() ?: return s; val b = m.groupValues[2].toIntOrNull() ?: return s
        return "${min(a, b)}x${max(a, b)}"
    }

    /** Ukuran layar asli HP (hanya untuk membandingkan, bukan untuk ditampilkan). */
    fun realScreen(ctx: Context): Pair<Int, Int>? = runCatching {
        val d = ctx.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        val p = Point()
        @Suppress("DEPRECATION") d.getRealSize(p)
        if (p.x > 0 && p.y > 0) p.x to p.y else null
    }.getOrNull()

    // ---- Pembacaan selama rekaman ----
    private val cache = java.util.concurrent.ConcurrentHashMap<String, Pair<Int, Int>>()   // hasil baca terakhir per paket
    private val recCount = HashMap<String, Int>()                                           // resolusi -> jumlah pembacaan, rekaman ini
    private val probing = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var lastTry = -100_000L
    @Volatile private var dbg = "-"

    /** Dipanggil Recorder.start(): mulai hitungan baru. */
    fun resetRec() { synchronized(recCount) { recCount.clear() }; lastTry = -100_000L }

    private fun onRes(r: Pair<Int, Int>) { synchronized(recCount) { val k = fmt(r); recCount[k] = (recCount[k] ?: 0) + 1 } }
    private fun recBest(): String? = synchronized(recCount) { recCount.maxByOrNull { it.value }?.key }
    private fun hasRec(): Boolean = synchronized(recCount) { recCount.isNotEmpty() }

    /**
     * Dipanggil Sampler selama rekaman (game masih di depan): baca resolusi game di thread latar. Tiap ~3 dtk selama belum ada hasil,
     * lalu tiap ~8 dtk; tiap hasil dihitung, dan yang paling sering terbaca dipakai di laporan.
     * Baru dibaca di akhir rekaman terlalu telat: layer game sudah hilang.
     */
    fun probeAsync(ctx: Context, pkg: String) {
        if (pkg.isBlank() || Shell.mode() == "-") return
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastTry < (if (hasRec()) 8_000L else 3_000L)) return
        if (!probing.compareAndSet(false, true)) return
        lastTry = now
        val app = ctx.applicationContext
        Thread {
            try {
                val r = parseGameRes(app, Shell.execLimited("dumpsys SurfaceFlinger", 12000L), pkg)
                if (r != null) { cache[pkg] = r; onRes(r) }
            } catch (_: Throwable) {
            } finally { probing.set(false) }
        }.apply { isDaemon = true; name = "res-probe"; start() }
    }

    /**
     * Resolusi game untuk laporan. Urutan: pembacaan terbanyak selama rekaman -> baca ulang sekarang -> cache terakhir
     * -> GameUserSettings.ini (hanya bila BEDA dari ukuran layar HP) -> kosong. Panggil dari thread latar.
     */
    fun game(ctx: Context, pkg: String): String {
        if (pkg.isBlank()) return ""
        recBest()?.let { return it }
        if (Shell.mode() == "-") return cache[pkg]?.let { fmt(it) }.orEmpty()
        val scr = realScreen(ctx)?.let { fmt(it) }
        val now = runCatching { parseGameRes(ctx, Shell.execLimited("dumpsys SurfaceFlinger", 12000L), pkg, normalize = false) }.getOrNull()
        return (now ?: cache[pkg] ?: iniRes(pkg)?.takeIf { fmt(it) != scr })?.let { fmt(it) }.also {
            if (it == null) AppLog.w("Res", "resolusi game tidak terbaca ($pkg): $dbg")
        }.orEmpty()
    }

    /** Resolusi yang diset game sendiri (game Unreal Engine: GameUserSettings.ini, ResolutionSizeX/Y). */
    private fun iniRes(pkg: String): Pair<Int, Int>? = runCatching {
        val txt = Shell.exec("cat /sdcard/Android/data/$pkg/files/UnrealEngine/Saved/Config/Android/GameUserSettings.ini")
        fun v(k: String) = Regex("(?m)^" + k + "=(\\d+)").find(txt)?.groupValues?.get(1)?.toIntOrNull()
        val w = v("ResolutionSizeX"); val h = v("ResolutionSizeY")
        if (w != null && h != null && w >= 100 && h >= 100) w to h else null
    }.getOrNull()

    /** Cari layer milik paket game (utamakan SurfaceView), ambil ukuran buffernya; beberapa format dump dicoba berurutan. */
    private fun parseGameRes(ctx: Context, txt: String, pkg: String, normalize: Boolean = true): Pair<Int, Int>? {
        if (txt.isEmpty()) return null
        var best: Pair<Int, Int>? = null; var bestScore = -1L
        var header: String? = null; var found: Pair<Int, Int>? = null
        fun flush() {
            val h = header ?: return; val f = found ?: return
            if (!h.contains(pkg) || SKIP_LAYER.containsMatchIn(h)) return
            val score = (if (h.contains("SurfaceView")) 1L shl 40 else 0L) + f.first.toLong() * f.second
            if (score > bestScore) { bestScore = score; best = f }
        }
        for (l in txt.lineSequence()) {
            if (l.startsWith("+ ") || l.startsWith("* ")) { flush(); header = l; found = null; continue }
            if (header == null || found != null) continue
            val m = BUF_RE.find(l) ?: BUF_RE2.find(l) ?: continue
            val w = m.groupValues[1].toIntOrNull() ?: continue; val h2 = m.groupValues[2].toIntOrNull() ?: continue
            if (w >= 100 && h2 >= 100) found = w to h2
        }
        flush()
        var r: Pair<Int, Int>? = best
        var src = "activeBuffer"
        if (r == null) { r = geomBufferRes(txt, pkg); src = "geomBufferSize" }
        if (r == null) { r = outputSourceCrop(txt, pkg); src = "sourceCrop" }
        if (r == null) { r = hwcSourceCrop(txt, pkg); src = "HWC crop" }
        if (r == null) { r = snapshotBufferSize(txt, pkg); src = "bufferSize" }
        if (r == null) {
            val hits = txt.lineSequence().filter { it.contains(pkg) }.toList()
            dbg = "tidak terbaca (${txt.length} karakter, ${hits.size} baris cocok) " + hits.take(2).joinToString(" | ") { it.trim().take(90) }
            return null
        }
        dbg = "$src ${r.first}x${r.second}"
        if (!normalize) return r
        // Samakan orientasi dengan layar saat ini (buffer kadang dilaporkan terputar)
        val pt = realScreen(ctx) ?: return r
        val hi = max(r.first, r.second); val lo = min(r.first, r.second)
        return if (pt.first >= pt.second) hi to lo else lo to hi
    }

    /** Format dump Android 14+/16: "Layer [id] nama", ukuran buffer di baris "geomBufferSize=[L T R B]" sesudahnya. */
    private fun geomBufferRes(txt: String, pkg: String): Pair<Int, Int>? {
        val rx = Regex("""geomBufferSize=\[\s*(-?\d+)\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)\s*]""")
        var best: Pair<Int, Int>? = null; var bestScore = -1L
        var header: String? = null; var found: Pair<Int, Int>? = null
        fun flush() {
            val h = header ?: return; val f = found ?: return
            if (!h.contains(pkg) || SKIP_LAYER.containsMatchIn(h)) return
            val score = (if (h.contains("SurfaceView")) 1L shl 40 else 0L) + f.first.toLong() * f.second
            if (score > bestScore) { bestScore = score; best = f }
        }
        for (l in txt.lineSequence()) {
            if (LAYER_HDR.containsMatchIn(l)) { flush(); header = l; found = null; continue }
            if (header == null || found != null) continue
            val m = rx.find(l) ?: continue
            val g = m.groupValues
            val w = g[3].toInt() - g[1].toInt(); val h2 = g[4].toInt() - g[2].toInt()
            if (w >= 100 && h2 >= 100) found = w to h2
        }
        flush()
        return best
    }

    /** "sourceCrop=[L T R B]" di blok "Output Layer" layer SurfaceView game: ukuran buffer render (bukan displayFrame = ukuran layar). */
    private fun outputSourceCrop(txt: String, pkg: String): Pair<Int, Int>? {
        val lines = txt.lines()
        var best: Pair<Int, Int>? = null; var bestArea = -1L
        for (i in lines.indices) {
            val l = lines[i]
            if (!l.contains(pkg) || !l.contains("SurfaceView") || SKIP_LAYER.containsMatchIn(l)) continue
            for (j in i + 1..minOf(i + 40, lines.lastIndex)) {
                if (j > i + 1 && (LAYER_HDR.containsMatchIn(lines[j]) || lines[j].trimStart().startsWith("- Output Layer"))) break
                val m = SRC_CROP_RE.find(lines[j]) ?: continue
                val w = ((m.groupValues[3].toFloatOrNull() ?: continue) - (m.groupValues[1].toFloatOrNull() ?: continue)).toInt()
                val h = ((m.groupValues[4].toFloatOrNull() ?: continue) - (m.groupValues[2].toFloatOrNull() ?: continue)).toInt()
                if (w < 100 || h < 100) break
                if (w.toLong() * h > bestArea) { bestArea = w.toLong() * h; best = w to h }
                break
            }
        }
        return best
    }

    /** Tabel "HWC layers": Source Crop (L T R B) tiap layer = bagian buffer yang ditampilkan = ukuran render game. */
    private fun hwcSourceCrop(txt: String, pkg: String): Pair<Int, Int>? {
        val num = Regex("""(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)""")
        val lines = txt.lines()
        var best: Pair<Int, Int>? = null; var bestScore = -1L
        for (i in lines.indices) {
            val l = lines[i]
            if (!l.contains(pkg) || SKIP_LAYER.containsMatchIn(l) || !l.contains("SurfaceView")) continue
            for (j in i..minOf(i + 2, lines.lastIndex)) {
                val m = num.find(lines[j]) ?: continue
                val w = (m.groupValues[3].toFloat() - m.groupValues[1].toFloat()).toInt()
                val h = (m.groupValues[4].toFloat() - m.groupValues[2].toFloat()).toInt()
                if (w < 100 || h < 100) break
                val score = (1L shl 40) + w.toLong() * h
                if (score > bestScore) { bestScore = score; best = w to h }
                break
            }
        }
        return best
    }

    /** Cadangan terakhir (format dump baru): geomBufferSize / bufferSize di beberapa baris sesudah nama layer game. */
    private fun snapshotBufferSize(txt: String, pkg: String): Pair<Int, Int>? {
        val rx = Regex("""(?i)(?:geomBufferSize|bufferSize)\D{1,8}(-?\d+)\D+(-?\d+)(?:\D+(-?\d+)\D+(-?\d+))?""")
        val lines = txt.lines()
        var best: Pair<Int, Int>? = null; var bestScore = -1L
        for (i in lines.indices) {
            val l = lines[i]
            if (!l.contains(pkg) || SKIP_LAYER.containsMatchIn(l)) continue
            for (j in i..minOf(i + 15, lines.lastIndex)) {
                val m = rx.find(lines[j]) ?: continue
                val g = m.groupValues
                val w: Int; val h: Int
                if (g[3].isNotEmpty() && g[4].isNotEmpty()) { w = g[3].toInt() - g[1].toInt(); h = g[4].toInt() - g[2].toInt() }
                else { w = g[1].toInt(); h = g[2].toInt() }
                if (w < 100 || h < 100) continue
                val score = (if (l.contains("SurfaceView")) 1L shl 40 else 0L) + w.toLong() * h
                if (score > bestScore) { bestScore = score; best = w to h }
                break
            }
        }
        return best
    }
}
