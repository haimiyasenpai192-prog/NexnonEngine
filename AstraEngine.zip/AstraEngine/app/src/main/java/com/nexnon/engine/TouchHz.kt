package com.nexnon.engine

import android.os.SystemClock

/**
 * Laju sampling sentuhan (Hz) layar, dibaca dari `getevent -lt` (hak shell/root) pada perangkat yang mengirim ABS_MT_*.
 * Hz = jumlah SYN_REPORT per detik selama jari menyentuh layar (pakai stempel waktu kernel, jadi tidak terpengaruh buffering pipa).
 * Nilai terakhir tetap ditampilkan setelah jari diangkat; "-" bila belum pernah disentuh.
 */
object TouchHz {
    @Volatile private var hz = -1
    @Volatile private var proc: Process? = null
    @Volatile private var thread: Thread? = null
    @Volatile private var gen = 0
    @Volatile private var giveUp = false

    /** Angka Hz tanpa satuan untuk kotak, "-" bila belum terbaca. */
    fun value(): String = if (hz > 0) "$hz" else "-"

    /** Teks untuk overlay, mis. "TCH 240Hz". */
    fun label(): String = "TCH " + (if (hz > 0) "${hz}Hz" else "-")

    @Synchronized fun start() {
        if (giveUp || thread?.isAlive == true) return
        val g = ++gen
        thread = Thread({ supervise(g) }, "touchhz").apply { isDaemon = true; start() }
    }

    @Synchronized fun stop() {
        gen++
        runCatching { proc?.destroy() }
        thread?.interrupt(); thread = null; proc = null
    }

    private fun sleep(ms: Long) { try { Thread.sleep(ms) } catch (_: InterruptedException) {} }

    private fun supervise(g: Int) {
        var quick = 0
        while (g == gen && !giveUp) {
            if (Shell.mode() == "-") { sleep(3000); continue }
            val t0 = SystemClock.elapsedRealtime()
            runCatching { runOnce(g) }.onFailure { AppLog.w("TouchHz", "getevent gagal: $it") }
            if (g != gen || giveUp) break
            quick = if (SystemClock.elapsedRealtime() - t0 < 5000L) quick + 1 else 0
            if (quick >= 5) { giveUp = true; AppLog.w("TouchHz", "getevent mati <5 dtk 5x berturut-turut, dinonaktifkan"); break }
            sleep(2000)
        }
    }

    private fun runOnce(g: Int) {
        val p = Shell.spawn("exec getevent -lt 2>&1") ?: return
        proc = p
        val touchDevs = HashSet<String>()
        val ts = ArrayList<Double>()    // stempel waktu SYN_REPORT dalam satu rangkaian sentuhan
        try {
            p.inputStream.bufferedReader().use { r ->
                while (g == gen) {
                    val l = r.readLine() ?: break
                    // "[  1234.567890] /dev/input/event3: EV_SYN  SYN_REPORT  00000000"
                    val rb = l.indexOf(']')
                    if (!l.startsWith("[") || rb < 0) continue
                    val colon = l.indexOf(':', rb)
                    if (colon < 0) continue
                    val dev = l.substring(rb + 1, colon).trim()
                    val rest = l.substring(colon + 1)
                    if (rest.contains("ABS_MT_")) { touchDevs.add(dev); continue }
                    if (!rest.contains("SYN_REPORT") || dev !in touchDevs) continue
                    val t = l.substring(1, rb).trim().toDoubleOrNull() ?: continue
                    if (ts.isNotEmpty() && t - ts.last() > 0.1) ts.clear()   // jeda >100 ms = sentuhan baru
                    ts.add(t)
                    while (ts.size > 2 && t - ts.first() > 0.5) ts.removeAt(0)
                    if (ts.size >= 6) {
                        val dt = t - ts.first()
                        if (dt > 0.0) hz = Math.round((ts.size - 1) / dt).toInt()
                    }
                }
            }
        } finally {
            runCatching { p.destroy() }
            if (proc === p) proc = null
        }
    }
}
