package com.nexnon.engine

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/**
 * Tombol overlay di panel Pengaturan Cepat (Control Center), sama seperti tombol "Jangan ganggu":
 * mati = overlay FPS tidak tampil, nyala = overlay tampil. Ikut berubah kalau overlay dinyalakan dari
 * aplikasi. Kalau izin "Tampil di atas aplikasi lain" belum ada, diketuk akan membuka halaman izinnya.
 */
class OverlayTileService : TileService() {
    companion object {
        /** Minta sistem memperbarui tampilan tombol (dipanggil dari OverlayService.sync / onDestroy). */
        fun refresh(ctx: Context) {
            runCatching { requestListeningState(ctx.applicationContext, ComponentName(ctx.applicationContext, OverlayTileService::class.java)) }
        }
    }

    override fun onStartListening() { render() }

    override fun onTileAdded() { render() }

    override fun onClick() {
        OverlayPrefs.load(this)
        if (!OverlayPrefs.on && !Settings.canDrawOverlays(this)) { openPermission(); return }
        OverlayPrefs.on = !OverlayPrefs.on
        OverlayPrefs.save(this)
        OverlayService.sync(this)
        render()
    }

    private fun render() {
        val t = qsTile ?: return
        OverlayPrefs.load(this)
        val active = OverlayPrefs.on && Settings.canDrawOverlays(this)
        t.state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Overlay"
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = if (active) OverlayPrefs.STYLES[OverlayPrefs.style] else "Mati"
        t.updateTile()
    }

    /** Buka halaman izin overlay dan tutup panel Pengaturan Cepat. */
    private fun openPermission() {
        val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        } else {
            @Suppress("DEPRECATION") startActivityAndCollapse(i)
        }
    }
}
