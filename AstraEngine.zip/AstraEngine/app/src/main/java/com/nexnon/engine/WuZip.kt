package com.nexnon.engine

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream

/**
 * Satu zip = satu versi config (nama file = nama versi, contoh v1.0.zip).
 * Susunan folder yang dikenali:
 *  - Bernomor: "[ 1 ] Flagship/", "Balanced/[ 1 ] High/", "Balanced/[ 2 ] Medium/" (nomor = urutan, teks = label)
 *  - Biasa   : flagship/, mid-range/, balanced/high/, balanced/medium/, atau langsung ultra/ high/ medium/
 *  - File .ini langsung di root zip juga diterima.
 * Folder yang namanya mengandung "balanc" = mode Balanced; "flagship" atau "mid..." = mode Flagship.
 * Folder "Mediatek" atau "Snapdragon" / "Qualcomm" = pilihan chipset (zip per chipset, contoh Mediatek/[ 1 ] Ultra/, Snapdragon/[ 2 ] High/);
 * aplikasi memilih otomatis sesuai chipset HP (lihat detectChipset di Device.kt).
 */
object WuZip {
    class Tier(val label: String, val order: Int, val files: Map<String, String>)
    class Parsed(val byMode: Map<String, List<Tier>>)
    class Imp(val name: String?, val err: String?)

    private val cache = HashMap<String, Parsed>()
    private fun dirOf(ctx: Context) = File(ctx.filesDir, "wuwa_presets").apply { mkdirs() }

    /** Config bawaan APK: disimpan terenkripsi (assets/nx.dat, tanpa nama/format yang terbaca), didekripsi saat pertama dibuka ke penyimpanan privat app. */
    private val BUNDLED = listOf("nx.dat" to "v1.2", "nx2.dat" to "v1.3 beta")
    private fun bundledKey(): ByteArray =
        java.security.MessageDigest.getInstance("SHA-256").digest(listOf("02b19b", "1029d2", "a38673", "3a8903").joinToString("").toByteArray())

    private val BUNDLED_TITLE = mapOf("v1.2" to "Config v1.2 release", "v1.3 beta" to "Config v1.3 beta")

    /** Judul rapi untuk daftar: nama bawaan, atau nama zip dengan huruf awal besar ("Config" ditambah bila hanya nomor versi). */
    fun title(version: String): String {
        BUNDLED_TITLE[version]?.let { return it }
        val n = version.trim().replace('_', ' ').replace(Regex("\\bv(\\d+) (\\d+)\\b"), "v$1.$2")
        return if (Regex("^v?\\d", RegexOption.IGNORE_CASE).containsMatchIn(n)) "Config $n" else n.replaceFirstChar { it.uppercase() }
    }

    /** Ringkasan isi satu versi, mis. "3 tingkat kualitas" atau "Flagship 2 • Balanced 2". */
    fun summary(ctx: Context, version: String): String {
        val by = load(ctx, version)?.byMode?.filterValues { it.isNotEmpty() } ?: return "Config kosong"
        if (by.isEmpty()) return "Config kosong"
        val named = listOf("Flagship", "Balanced", "Mediatek", "Snapdragon").mapNotNull { m -> by[m]?.let { "$m ${it.size}" } }
        return if (named.isEmpty()) "${by.values.sumOf { it.size }} tingkat kualitas" else named.joinToString(" • ")
    }

    /** True bila [version] adalah config bawaan APK (tidak bisa dihapus; hanya zip hasil impor yang bisa dihapus). */
    fun isBundled(version: String): Boolean = BUNDLED.any { it.second == version }

    private fun seedBundled(ctx: Context) {
        runCatching {
            val d = dirOf(ctx)
            val prefs = ctx.getSharedPreferences("wuwa_seed", Context.MODE_PRIVATE)
            BUNDLED.forEach { (asset, ver) ->
                val f = File(d, "$ver.zip")
                // Cukup sekali per versi: kalau nanti dihapus pengguna lewat tombol Hapus, tidak dipasang ulang
                if (!f.exists() && !prefs.getBoolean("seeded_$ver", false)) {
                    val blob = ctx.assets.open(asset).use { it.readBytes() }
                    val c = javax.crypto.Cipher.getInstance("AES/GCM/NoPadding")
                    c.init(javax.crypto.Cipher.DECRYPT_MODE, javax.crypto.spec.SecretKeySpec(bundledKey(), "AES"),
                        javax.crypto.spec.GCMParameterSpec(128, blob, 0, 12))
                    f.writeBytes(c.doFinal(blob, 12, blob.size - 12))
                }
                prefs.edit().putBoolean("seeded_$ver", true).apply()
            }
        }
    }

    fun versions(ctx: Context): List<String> =
        seedBundled(ctx).let { dirOf(ctx) }.listFiles { f -> f.extension.equals("zip", true) }?.map { it.nameWithoutExtension }?.sortedDescending() ?: emptyList()

    private fun clean(s: String) = s.replace('~', '-').replace('_', ' ').trim()
    private fun modeOf(seg: String): String? {
        val n = clean(seg).lowercase()
        return when {
            n.contains("balanc") -> "Balanced"
            n.contains("flagship") || n.startsWith("mid") -> "Flagship"
            n.contains("mediatek") -> "Mediatek"
            n.contains("snapdragon") || n.contains("qualcomm") -> "Snapdragon"
            else -> null
        }
    }
    private fun rank(label: String): Int = when (label.lowercase()) { "ultra" -> 0; "high" -> 1; "medium" -> 2; "low" -> 3; else -> 9 }

    fun parse(stream: InputStream): Parsed {
        val groups = LinkedHashMap<String, MutableMap<String, String>>()
        ZipInputStream(stream).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val path = e.name.replace('\\', '/')
                val base = path.substringAfterLast('/')
                if (!e.isDirectory && !path.contains("__MACOSX") && !base.startsWith("._")) {
                    val std = WuWa.ALL_FILES.firstOrNull { it.equals(base, true) }
                    if (std != null) groups.getOrPut(path.substringBeforeLast('/', "")) { LinkedHashMap() }[std] = zin.readBytes().toString(Charsets.UTF_8)
                }
                e = zin.nextEntry
            }
        }
        class Raw(val mode: String, val tier: Tier)
        val raws = groups.map { (dir, files) ->
            val segs = dir.split('/').filter { it.isNotEmpty() }
            var mode = ""
            for (s in segs) modeOf(s)?.let { mode = it }
            val last = segs.lastOrNull()?.takeIf { modeOf(it) == null }
            val m = last?.let { Regex("^\\[\\s*(\\d+)\\s*]\\s*(.*)$").find(it) }
            val label = if (m != null) clean(m.groupValues[2]) else if (last != null) clean(last) else "Default"
            val shownLabel = label.replaceFirstChar { it.uppercase() }
            val order = m?.groupValues?.get(1)?.toIntOrNull() ?: rank(shownLabel)
            val sorted = WuWa.ALL_FILES.filter { it in files }.associateWith { files[it]!! }
            Raw(mode, Tier(shownLabel, order, sorted))
        }
        val by = raws.groupBy { it.mode }.mapValues { (_, l) -> l.map { it.tier }.sortedWith(compareBy({ it.order }, { it.label })) }
        return Parsed(by)
    }

    fun load(ctx: Context, version: String): Parsed? = cache[version] ?: runCatching {
        File(dirOf(ctx), "$version.zip").inputStream().use { parse(it) }
    }.getOrNull()?.also { cache[version] = it }

    private fun displayName(ctx: Context, uri: Uri): String =
        runCatching {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
        }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/') ?: "config.zip"

    fun importZip(ctx: Context, uri: Uri): Imp {
        val name = displayName(ctx, uri).removeSuffix(".zip").removeSuffix(".ZIP")
            .replace(Regex("[\\\\/:*?\"<>|]"), "").trim().ifEmpty { "config" }
        val tmp = File(dirOf(ctx), "$name.tmp")
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { i.copyTo(it) } } ?: return Imp(null, "Tidak bisa membuka file")
            val p = tmp.inputStream().use { parse(it) }
            if (p.byMode.isEmpty()) { tmp.delete(); return Imp(null, "Zip tidak berisi file config (Engine.ini, DeviceProfiles.ini, Scalability.ini, GameUserSettings.ini)") }
            tmp.copyTo(File(dirOf(ctx), "$name.zip"), overwrite = true); tmp.delete()
            cache.remove(name)
            Imp(name, null)
        } catch (e: Exception) { tmp.delete(); Imp(null, "Gagal impor: ${e.message}") }
    }

    fun delete(ctx: Context, version: String) { File(dirOf(ctx), "$version.zip").delete(); cache.remove(version) }
}
