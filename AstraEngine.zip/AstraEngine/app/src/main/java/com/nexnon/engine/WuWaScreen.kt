package com.nexnon.engine

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun QChip(label: String, sel: Boolean, onClick: () -> Unit) =
    Box(Modifier.clip(RoundedCornerShape(16.dp)).background(if (sel) VIOLET else Color(0xFF23252D)).clickable { onClick() }
        .padding(horizontal = 11.dp, vertical = 10.dp)) { T(label, 13, Color.White, true) }

@Composable
fun WuWaDetail(p: Preset) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var versions by remember { mutableStateOf(WuZip.versions(ctx)) }
    var showVer by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<String?>(null) }
    var open by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var dexDlg by remember { mutableStateOf(false) }
    var cleanDlg by remember { mutableStateOf(false) }
    var dexNow by remember { mutableStateOf<String?>(null) }
    val sh = RoundedCornerShape(22.dp)
    val mimes = arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")

    val doImport: (android.net.Uri) -> Unit = { uri ->
        scope.launch {
            val r = withContext(Dispatchers.IO) { WuZip.importZip(ctx, uri) }
            versions = WuZip.versions(ctx)
            if (r.name != null) { Store.wuVersion = r.name; Store.wuTier = 0; msg = "Zip ${r.name} diimpor." } else msg = r.err ?: "Gagal impor."
        }
    }
    val pickOther = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.data?.let { doImport(it) }
    }
    // Impor / Impor zip langsung membuka daftar aplikasi file manager (tanpa dialog perantara)
    val openFm: () -> Unit = {
        val i = android.content.Intent(android.content.Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"; addCategory(android.content.Intent.CATEGORY_OPENABLE); putExtra(android.content.Intent.EXTRA_MIME_TYPES, mimes)
        }
        try { pickOther.launch(android.content.Intent.createChooser(i, "Pilih file manager")) }
        catch (_: Exception) { msg = "Tidak ada file manager yang tersedia." }
    }

    val ver = if (Store.wuVersion in versions) Store.wuVersion else versions.firstOrNull() ?: ""
    val parsed = if (ver.isEmpty()) null else WuZip.load(ctx, ver)
    val modes = parsed?.byMode?.keys?.sortedBy { if (it == "Flagship") 0 else if (it == "Balanced") 1 else 2 } ?: emptyList()
    // Config per chipset (folder Mediatek / Snapdragon): dipilih otomatis sesuai chipset HP, tidak perlu dipilih manual
    val chip = remember { detectChipset() }
    val chipCfg = modes.any { it == "Mediatek" || it == "Snapdragon" }
    val chipLocked = chipCfg && chip != null && chip in modes
    val mode = when {
        chipLocked -> chip!!
        Store.wuMode in modes -> Store.wuMode
        else -> modes.firstOrNull() ?: ""
    }
    val tiers = parsed?.byMode?.get(mode) ?: emptyList()
    val ti = Store.wuTier.coerceIn(0, maxOf(0, tiers.size - 1))
    val pkg = remember { WuWa.installedPackage(ctx) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = NAV_SPACE), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Kembali + judul di kiri, avatar di pojok kanan atas (sama seperti avatar di header WuWaConfig)
        Box(Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                T("‹ Kembali", 15, AC, true, Modifier.clickable { Store.game = null }.padding(vertical = 4.dp))
                T(p.name, 24, TX, true)
            }
            Image(androidx.compose.ui.res.painterResource(R.drawable.live_avatar), null,
                Modifier.size(64.dp).align(Alignment.TopEnd), contentScale = androidx.compose.ui.layout.ContentScale.Fit)
        }
        // Versi config
        Row(Modifier.fillMaxWidth().background(cardBg, sh).border(1.dp, BD, sh).padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Ico(4, Color(0xFF4F8FE0))
            T(if (ver.isEmpty()) "Belum ada config" else WuZip.title(ver), 14, TX, true, Modifier.weight(1f), 1)
            T(if (ver.isEmpty()) "Impor ›" else "Ganti ›", 14, PINK, true, Modifier.clickable { if (ver.isEmpty()) openFm() else showVer = true })
        }
        // Mode (Flagship / Balanced), hanya jika zip memilikinya
        if (modes.any { it.isNotEmpty() }) Row(Modifier.fillMaxWidth().background(cardBg, sh).border(1.dp, BD, sh).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Ico(1, AC); T(if (chipCfg) "Chipset" else "Mode", 14, TX, true); Spacer(Modifier.weight(1f))
            // Chipset terdeteksi: hanya chipset HP ini yang tampil (terkunci). Tidak terdeteksi / tidak ada di config: pilih manual.
            modes.filter { it.isNotEmpty() && (!chipLocked || it == mode) }.forEach { m ->
                QChip(m, m == mode) { if (!chipLocked) { Store.wuMode = m; Store.wuTier = 0 } }
            }
        }
        // Kualitas (tingkat dari zip)
        Row(Modifier.fillMaxWidth().background(cardBg, sh).border(1.dp, BD, sh).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Ico(5, Color(0xFFE0B040)); T("Kualitas", 14, TX, true)
            Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End)) {
                if (tiers.isEmpty()) T("-", 14, MUT)
                tiers.forEachIndexed { i, t -> QChip(t.label, i == ti) { Store.wuTier = i } }
            }
        }
        // Install
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF5B9BDC), VIOLET, PINK)))
            .clickable {
                when {
                    Report.busy -> {}
                    tiers.isEmpty() -> Report.fail("Gagal memasang config", "Belum ada config. Ketuk Impor lalu pilih zip.")
                    pkg == null -> Report.fail("Gagal memasang config", "Wuthering Waves tidak ditemukan.")
                    Shell.mode() == "-" -> Report.fail("Gagal memasang config", "Akses belum aktif. Buka tab Settings lalu pilih Shizuku atau Root.")
                    else -> scope.launch {
                        val t = tiers[ti]
                        val label = listOf(ver, mode, t.label).filter { it.isNotEmpty() }.joinToString(" · ")
                        Report.begin("install", "Memasang config…", t.files.keys.filter { k -> WuWa.SHOWN.any { it.equals(k, true) } })
                        Report.addLog("Mulai pasang: $label | akses=${Shell.mode()} | paket=$pkg")
                        val err = withContext(Dispatchers.IO) { WuWa.installFiles(pkg, t.files) }
                        val rows = withContext(Dispatchers.IO) { WuWa.verify(pkg, t.files) }
                        rows.forEach { Report.addLog("${it.name}: ${if (it.state == 1) "OK" else it.note}") }
                        if (err != null) Report.addLog("GAGAL: $err")
                        val allOk = err == null && rows.all { it.state == 1 }
                        if (allOk) {
                            Store.configured[p.key] = label; Store.installs++; Store.last = "${p.name} · $label"
                            Report.end("install", true, "Config berhasil terpasang", label + " · " + Report.fmtTime(System.currentTimeMillis()), rows.filter { r -> WuWa.SHOWN.any { it.equals(r.name, true) } })
                        } else Report.end("install", false,
                            if (err != null) "Gagal memasang config" else "Config belum sepenuhnya terpasang",
                            err ?: "Ada file yang tidak sesuai di folder game.", rows.filter { r -> WuWa.SHOWN.any { it.equals(r.name, true) } }.ifEmpty { rows })
                    }
                }
            }.padding(vertical = 16.dp), contentAlignment = Alignment.Center) { T("Install", 20, Color.White, true) }
        ResultBox()
        if (msg.isNotEmpty()) T(msg, 13, MUT)
        T(if (open) "Detail ▾" else "Detail ›", 14, MUT, true, Modifier.clickable { open = !open }.padding(vertical = 8.dp))
        if (open) {
            if (tiers.isNotEmpty()) T("File yang akan dipasang: ${tiers[ti].files.keys.filter { k -> WuWa.SHOWN.any { it.equals(k, true) } }.joinToString(", ")}", 13, MUT)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(cardBg).border(1.dp, BD, RoundedCornerShape(16.dp)).clickable {
                when {
                    Report.busy -> {}
                    pkg == null -> Report.fail("Gagal cek status", "Wuthering Waves tidak ditemukan.")
                    Shell.mode() == "-" -> Report.fail("Gagal cek status", "Akses belum aktif. Buka tab Settings.")
                    else -> scope.launch {
                        Report.begin("check", "Memeriksa file…", WuWa.SHOWN)
                        val rows = withContext(Dispatchers.IO) { WuWa.inspect(pkg) }
                        if (rows == null) Report.end("check", false, "Gagal membaca folder game", "Cek akses Shizuku atau Root.", emptyList())
                        else {
                            val good = rows.none { it.state == 2 }
                            rows.forEach { Report.addLog("Cek ${it.name}: ${it.note.ifEmpty { "OK" }}") }
                            Report.end("check", good, if (good) "Config terdeteksi" else "Config belum lengkap atau bermasalah", Report.fmtTime(System.currentTimeMillis()), rows)
                        }
                    }
                }
            }.padding(vertical = 12.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) { Ico(2, Color(0xFF5BD68E), 18.dp); Spacer(Modifier.width(8.dp)); T("Cek status", 14, TX, true) }
            Row(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(cardBg).border(1.dp, BD, RoundedCornerShape(16.dp)).clickable {
                when {
                    Report.busy -> {}
                    pkg == null -> Report.fail("Gagal DEX2OAT", "Wuthering Waves tidak ditemukan.")
                    Shell.mode() == "-" -> Report.fail("Gagal DEX2OAT", "Akses belum aktif. Buka tab Settings.")
                    else -> {
                        dexNow = null; dexDlg = true
                        scope.launch { dexNow = withContext(Dispatchers.IO) { WuWa.dexStatus(pkg) } }
                    }
                }
            }.padding(vertical = 12.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Ico(8, Color(0xFFE0B040), 18.dp); Spacer(Modifier.width(8.dp)); T(if (Report.busy && Report.kind == "dex2oat") "Mengompilasi…" else "DEX2OAT", 14, TX, true)
            }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(cardBg).border(1.dp, BD, RoundedCornerShape(16.dp)).clickable {
                when {
                    Report.busy -> {}
                    pkg == null -> Report.fail("Gagal membersihkan", "Wuthering Waves tidak ditemukan.")
                    Shell.mode() == "-" -> Report.fail("Gagal membersihkan", "Akses belum aktif. Buka tab Settings.")
                    else -> cleanDlg = true
                }
            }.padding(vertical = 12.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Ico(11, Color(0xFF5B9BE0), 18.dp); Spacer(Modifier.width(8.dp)); T("Bersihkan", 14, TX, true)
            }
            Row(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(cardBg).border(1.dp, BD, RoundedCornerShape(16.dp)).clickable {
                when {
                    Report.busy -> {}
                    pkg == null -> Report.fail("Gagal menghapus config", "Wuthering Waves tidak ditemukan.")
                    Shell.mode() == "-" -> Report.fail("Gagal menghapus config", "Akses belum aktif. Buka tab Settings.")
                    else -> scope.launch {
                        Report.begin("delete", "Menghapus config…", WuWa.SHOWN)
                        val err = withContext(Dispatchers.IO) { WuWa.delete(pkg, WuWa.REMOVABLE) }
                        if (err == null) {
                            Store.configured.remove(p.key); Report.addLog("Config dihapus")
                            // Sukses: kotak hasil disembunyikan (tidak menampilkan daftar file lagi); muncul lagi setelah menekan Cek status
                            Report.visible = false; Report.busy = false
                            android.widget.Toast.makeText(ctx, "Config dihapus", android.widget.Toast.LENGTH_SHORT).show()
                        } else { Report.addLog("GAGAL hapus: $err"); Report.end("delete", false, "Gagal menghapus config", err, WuWa.SHOWN.map { FileRow(it, 2) }) }
                    }
                }
            }.padding(vertical = 12.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) { Ico(10, Color(0xFFE06070), 18.dp); Spacer(Modifier.width(8.dp)); T("Hapus config", 14, TX, true) }
            }
            DownscaleCard(pkg)
        }
    }

    if (dexDlg) {
        val runDex: (String?, String) -> Unit = { m, label ->
            dexDlg = false
            if (pkg != null) scope.launch {
                Report.begin("dex2oat", "Mengompilasi DEX2OAT…", emptyList())
                Report.sub = "Jangan tutup aplikasi, bisa beberapa menit"
                val err = withContext(Dispatchers.IO) { WuWa.dexopt(pkg, m) }
                val st = withContext(Dispatchers.IO) { WuWa.dexStatus(pkg) }
                if (err == null) Report.end("dex2oat", true, "DEX2OAT selesai", "$label · status: ${st ?: "tidak terbaca"} · " + Report.fmtTime(System.currentTimeMillis()), emptyList())
                else Report.end("dex2oat", false, "DEX2OAT gagal", err, emptyList())
            }
        }
        AlertDialog(
            onDismissRequest = { dexDlg = false }, containerColor = Color.Black, shape = RoundedCornerShape(28.dp),
            title = { Text("DEX2OAT", color = TX, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    T("Kompilasi ulang game supaya loading dan performa lebih stabil. Prosesnya bisa beberapa menit, jangan tutup aplikasi.", 14, Color(0xFFC4CACE))
                    T("Status sekarang: ${dexNow ?: "tidak diketahui"}", 13, Color(0xFF5B9BE0), true)
                    ActOption("Speed-profile", "Seimbang, disarankan.", 8, Color(0xFF5BD68E), Color(0xFF0F1A14)) { runDex("speed-profile", "speed-profile") }
                    ActOption("Speed", "Kompilasi penuh, lebih lama dan memakai lebih banyak ruang.", 1, Color(0xFFE0B040), Color(0xFF17140C)) { runDex("speed", "speed") }
                    ActOption("Reset", "Hapus hasil kompilasi, kembali ke bawaan sistem.", 9, Color(0xFFFF6B6B), Color(0xFF1A1010)) { runDex(null, "reset") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { dexDlg = false }) { Text("Batal", color = VIOLET) } }
        )
    }
    if (cleanDlg) {
        val runClean: (String, String) -> Unit = { what, title ->
            cleanDlg = false
            if (pkg != null) scope.launch {
                Report.begin("bersih", "$title…", emptyList())
                Report.sub = "Sebentar…"
                val (err, sum) = withContext(Dispatchers.IO) { WuWa.sweep(pkg, what) }
                if (err == null) Report.end("bersih", true, "$title selesai", sum + " · " + Report.fmtTime(System.currentTimeMillis()), emptyList())
                else Report.end("bersih", false, "$title gagal", err, emptyList())
            }
        }
        AlertDialog(
            onDismissRequest = { cleanDlg = false }, containerColor = Color.Black, shape = RoundedCornerShape(28.dp),
            title = { Text("Bersihkan", color = TX, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    T("Pembersih ini hanya menyentuh folder data game dan tidak menghapus config.", 14, Color(0xFFC4CACE))
                    ActOption("Hapus shader", "Hapus cache shader. Dibuat ulang otomatis saat game dibuka.", 10, Color(0xFF5B9BE0), Color(0xFF0F1420)) { runClean("shader", "Hapus shader") }
                    ActOption("Hapus laporan crash", "Hapus file laporan crash game untuk melegakan ruang.", 11, Color(0xFFE0B040), Color(0xFF17140C)) { runClean("junk", "Hapus laporan crash") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { cleanDlg = false }) { Text("Batal", color = VIOLET) } }
        )
    }

    if (showVer) AlertDialog(
        onDismissRequest = { showVer = false }, containerColor = Color.Black, shape = RoundedCornerShape(28.dp),
        title = { Text("Pilih config", color = TX, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold, fontSize = 22.sp) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (versions.isEmpty()) T("Belum ada config. Impor zip untuk mulai.", 14, MUT)
                versions.forEach { v ->
                    VersionCard(WuZip.title(v), WuZip.summary(ctx, v), v == ver, canDelete = !WuZip.isBundled(v),
                        onDelete = { showVer = false; deleteTarget = v }) { Store.wuVersion = v; Store.wuTier = 0; showVer = false }
                }
                Spacer(Modifier.height(2.dp))
                ImportCard { showVer = false; openFm() }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = { showVer = false }) { Text("Batal", color = VIOLET, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium, fontSize = 16.sp) } }
    )
    deleteTarget?.let { v ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null }, containerColor = Color.Black, shape = RoundedCornerShape(28.dp),
            title = { Text("Hapus config?", color = TX, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold, fontSize = 22.sp) },
            text = { T("${WuZip.title(v)} akan dihapus dari aplikasi. File zip aslinya di HP tidak ikut terhapus.", 15, Color(0xFFC4CACE)) },
            confirmButton = {
                TextButton(onClick = {
                    WuZip.delete(ctx, v); versions = WuZip.versions(ctx); msg = "${WuZip.title(v)} dihapus."; deleteTarget = null
                }) { Text("Hapus", color = Color(0xFFFF6B6B), fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold, fontSize = 16.sp) }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Batal", color = VIOLET, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium, fontSize = 16.sp) } }
        )
    }
}

/** Pilihan di dialog (ikon + judul berwarna + keterangan), seperti di dialog DEX2OAT / Bersihkan. */
@Composable
fun ActOption(title: String, desc: String, icon: Int, tint: Color, bg: Color, onClick: () -> Unit) {
    val sh = RoundedCornerShape(22.dp)
    Row(Modifier.fillMaxWidth().clip(sh).background(bg).border(1.dp, tint.copy(alpha = 0.45f), sh).clickable { onClick() }
        .padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Ico(icon, tint, 28.dp)
        Column(Modifier.weight(1f)) { T(title, 17, tint, true); T(desc, 14, Color(0xFFD5D9DD)) }
    }
}

/** Kartu satu config di dialog "Pilih config": judul ungu + ringkasan, bingkai tebal bila terpilih, tombol hapus hanya untuk zip hasil impor. */
@Composable
fun VersionCard(title: String, summary: String, selected: Boolean, canDelete: Boolean, onDelete: () -> Unit, onClick: () -> Unit) {
    val sh = RoundedCornerShape(28.dp)
    Row(Modifier.fillMaxWidth().clip(sh).background(Color(0xFF13111F), sh)
        .border(if (selected) 2.dp else 1.dp, if (selected) VIOLET else VIOLET.copy(alpha = 0.35f), sh)
        .clickable { onClick() }.padding(horizontal = 18.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(44.dp), contentAlignment = Alignment.CenterStart) { Ico(4, VIOLET, 32.dp) }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            T(title, 19, VIOLET, true)
            T(summary, 15, TX)
        }
        if (canDelete) Box(Modifier.padding(start = 8.dp).size(40.dp).clip(CircleShape).background(Color(0x22FF6B6B))
            .clickable { onDelete() }, contentAlignment = Alignment.Center) { Ico(10, Color(0xFFFF6B6B), 22.dp) }
    }
}

/** Kartu "Impor zip" bergaris putus-putus kuning di bawah daftar config. */
@Composable
fun ImportCard(onClick: () -> Unit) {
    val amber = Color(0xFFE0B040)
    Row(Modifier.fillMaxWidth().background(Color(0xFF17140C), RoundedCornerShape(20.dp))
        .drawBehind {
            val w = 1.5.dp.toPx()
            drawRoundRect(amber.copy(alpha = 0.6f), topLeft = Offset(w / 2, w / 2), size = Size(size.width - w, size.height - w),
                cornerRadius = CornerRadius(20.dp.toPx()), style = Stroke(width = w, pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 12f))))
        }
        .clip(RoundedCornerShape(20.dp)).clickable { onClick() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(amber.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) { Ico(13, amber, 24.dp) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            T("Impor zip", 17, amber, true)
            T("Tambah config dari file .zip", 14, Color(0xFFC4CACE))
            T("Engine, DeviceProfiles, Scalability, GameUserSettings", 12, Color(0xFF8A9096), false, Modifier.padding(top = 2.dp))
        }
    }
}
