package com.nexnon.engine

import android.os.SystemClock
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable fun Sp(h: Int) = Spacer(Modifier.height(h.dp))
@Composable fun Label(s: String) = T(s, 12, MUT, true)

@Composable
fun Chip(text: String, bg: Color = Color(0x1FFFFFFF)) =
    Text(text, color = TX, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1,
        modifier = Modifier.background(bg, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 4.dp))

@Composable
fun Tile(label: String, value: String, mod: Modifier) =
    Column(mod.background(Color(0x14FFFFFF), RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 10.dp)) {
        T(label, 11, MUT, maxLines = 1); T(value, 17, TX, true, maxLines = 1)
    }

@Composable
fun Bar(frac: Float, h: Int = 6, colors: List<Color> = listOf(MUT, TX)) =
    Box(Modifier.fillMaxWidth().height(h.dp).clip(RoundedCornerShape(50)).background(Color(0x1FFFFFFF))) {
        Box(Modifier.fillMaxWidth(frac.coerceIn(0.02f, 1f)).fillMaxHeight().background(Brush.horizontalGradient(colors)))
    }

// ---- Judul hero bergaya teknologi (huruf digambar sendiri, tanpa file font) ----
private const val GH = 14f      // tinggi huruf
private const val GW = 10f      // lebar huruf
private const val GSW = 2.4f    // tebal garis
private const val GGAP = 2.6f   // jarak antar huruf
private const val GSPACE = 6f   // spasi antar kata

private fun glyphW(c: Char) = if (c == 'I') 0f else GW

private fun DrawScope.glyph(c: Char, ox: Float, s: Float) {
    val h = GSW / 2
    val st = Stroke(GSW * s, cap = StrokeCap.Square)
    fun ln(x1: Float, y1: Float, x2: Float, y2: Float) =
        drawLine(Color.White, Offset((ox + x1 + h) * s, (y1 + h) * s), Offset((ox + x2 + h) * s, (y2 + h) * s), GSW * s, StrokeCap.Square)
    clipRect((ox) * s, 0f, (ox + glyphW(c) + GSW) * s, (GH + GSW) * s) {
        when (c) {
            'N' -> { ln(0f, 0f, 0f, GH); ln(GW, 0f, GW, GH); ln(0f, 0f, GW, GH) }
            'E' -> { ln(0f, 0f, 0f, GH); ln(0f, 0f, GW, 0f); ln(0f, GH / 2, GW - 2f, GH / 2); ln(0f, GH, GW, GH) }
            'X' -> { ln(0f, 0f, GW, GH); ln(GW, 0f, 0f, GH) }
            'O' -> drawRoundRect(Color.White, Offset((ox + h) * s, h * s), Size(GW * s, GH * s), CornerRadius(3.2f * s), st)
            'G' -> { ln(GW, 0f, 0f, 0f); ln(0f, 0f, 0f, GH); ln(0f, GH, GW, GH); ln(GW, GH, GW, GH / 2); ln(GW, GH / 2, GW / 2, GH / 2) }
            'I' -> ln(0f, 0f, 0f, GH)
        }
    }
}

@Composable
fun TechTitle(text: String, modifier: Modifier = Modifier) {
    val total = text.sumOf { ch -> if (ch == ' ') (GSPACE - GGAP).toDouble() else (glyphW(ch) + GSW + GGAP).toDouble() }.toFloat() - GGAP
    Canvas(modifier.aspectRatio(total / (GH + GSW))) {
        val s = size.width / total
        var x = 0f
        for (ch in text) {
            if (ch == ' ') { x += GSPACE - GGAP; continue }
            glyph(ch, x, s)
            x += glyphW(ch) + GSW + GGAP
        }
    }
}

/** Tinggi kotak hero Beranda; dipakai juga untuk rasio potong wallpaper hero di Settings. */
val HERO_H = 240.dp

@Composable
fun Hero() {
    val img = Wallpaper.heroImage
    // Foto tidak lagi menembus bilah status: kartu dengan jarak di tepi dan sudut membulat, dimulai di bawah jam
    Box(Modifier.fillMaxWidth().statusBarsPadding().padding(start = 16.dp, end = 16.dp, top = 8.dp)) {
    Box(Modifier.fillMaxWidth().heightIn(min = HERO_H - 40.dp).clip(RoundedCornerShape(28.dp))
        .then(if (img != null) Modifier else Modifier
            .background(Brush.linearGradient(listOf(Color(0xFFFF7A2F), Color(0xFFD6246E), Color(0xFF2B1466))))
            .drawBehind {
                var x = -size.height
                while (x < size.width) {
                    drawLine(Color.White.copy(alpha = 0.07f), Offset(x, size.height), Offset(x + size.height * 0.47f, 0f), 2.dp.toPx())
                    x += 18.dp.toPx()
                }
            })) {
        if (img != null) {
            androidx.compose.foundation.Image(remember(img) { img.asImageBitmap() }, null, Modifier.matchParentSize(),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop)
            // Pudar ke hitam di bagian bawah supaya foto menyatu dengan latar (tanpa tepi keras)
            Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(90.dp)
                .background(Brush.verticalGradient(listOf(Color.Transparent, BG.copy(alpha = 0.45f), BG.copy(alpha = 0.9f)))))
        }
        Box(Modifier.matchParentSize().padding(start = 18.dp, end = 16.dp, top = 14.dp, bottom = 14.dp)) {
            Text("ASTRA ENGINE", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, style = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(Color(0xCC000000), Offset(0f, 2f), 8f)), letterSpacing = 1.sp, maxLines = 1, modifier = Modifier.align(Alignment.TopStart))
        }
    }
    }
}

@Composable
fun DeviceCard() {
    val dev by produceState(DevInfo()) { value = withContext(Dispatchers.IO) { loadDevInfo() } }
    val up by produceState(0L to 0L) { while (true) { value = SystemClock.elapsedRealtime() to SystemClock.uptimeMillis(); delay(1000) } }
    val awake = up.first
    val sleep = (up.first - up.second).coerceAtLeast(0L)
    val pct = if (awake > 0) (sleep * 100 / awake).toInt() else 0
    val poco = dev.brand.equals("POCO", true)
    Card2 {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(Modifier.size(56.dp).background(if (poco) Color(0xFFFFD500) else Color(0xFF101116), RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                T(if (poco) "POCO" else dev.brand.take(7), 12, if (poco) Color.Black else Color.White, true)
            }
            Column(Modifier.weight(1f)) {
                T(dev.name, 18, TX, true, maxLines = 1)
                Sp(6)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (dev.soc.isNotEmpty()) Chip(dev.soc)
                    Chip(dev.android, Color(0x33FFFFFF))
                }
            }
        }
        Sp(14)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile("Waktu aktif", fmtUp(awake), Modifier.weight(1f))
            Tile("Deep sleep • $pct%", fmtUp(sleep), Modifier.weight(1f))
        }
        Sp(12)
        Bar(pct / 100f)
    }
}

@Composable
fun Toggle(on: Boolean, compact: Boolean = false, onChange: (Boolean) -> Unit) =
    if (compact) Box(Modifier.size(40.dp, 24.dp).clip(RoundedCornerShape(12.dp)).background(if (on) CYAN else Color(0xFF2B2F3A)).clickable { onChange(!on) }) {
        Box(Modifier.padding(3.dp).offset(x = if (on) 16.dp else 0.dp).size(18.dp).background(Color.White, CircleShape))
    } else Box(Modifier.size(50.dp, 30.dp).clip(RoundedCornerShape(15.dp)).background(if (on) CYAN else Color(0xFF2B2F3A)).clickable { onChange(!on) }) {
        Box(Modifier.padding(4.dp).offset(x = if (on) 20.dp else 0.dp).size(22.dp).background(Color.White, CircleShape))
    }

@Composable
fun FpsCard() = Card2(pad = 12.dp) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Column { T("FPS", 12, MUT); T("${FpsMeter.fps}", 24, PINK_LT, true) }
        Column(horizontalAlignment = Alignment.End) {
            T("Frametime", 12, MUT)
            T("%.1f ms".format(FpsMeter.frameMs).replace('.', ','), 18, TX, true)
        }
    }
    Sp(6)
    Canvas(Modifier.fillMaxWidth().height(36.dp).clip(RoundedCornerShape(12.dp)).background(PINK_LT.copy(alpha = 0.12f))) {
        // Grafik: kecepatan frame (fps = 1000 / frametime terburuk tiap ~250 ms).
        // Stabil -> garis menempel di ATAS; frame melambat -> garis turun. Rentang minimal 30 fps supaya turunnya kelihatan.
        val h = FpsMeter.ftHistory.map { 1000f / it.coerceAtLeast(1f) }
        if (h.size >= 2) {
            val hi = h.max()
            val lo = minOf(h.min(), hi - 30f).coerceAtLeast(0f)
            val step = size.width / 119f
            val x0 = size.width - (h.size - 1) * step
            val path = Path()
            h.forEachIndexed { i, v ->
                val x = x0 + i * step
                val y = 4.dp.toPx() + (1f - (v - lo) / (hi - lo)) * (size.height - 8.dp.toPx())
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            // Warna ikut tombol Mulai: pink muda di kiri ke pink di kanan
            val pinkBrush = Brush.horizontalGradient(listOf(PINK_LT, PINK), startX = 0f, endX = size.width)
            drawPath(path, pinkBrush, style = Stroke(2.dp.toPx()))
            path.lineTo(size.width, size.height); path.lineTo(x0, size.height); path.close()
            drawPath(path, pinkBrush, alpha = 0.18f)
        }
    }
    Sp(5)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        T("Frametime · 30 detik terakhir", 11); T("AVG ${FpsMeter.avg} · LOW ${FpsMeter.low}", 11)
    }
    Sp(8); Box(Modifier.fillMaxWidth().height(1.dp).background(BD)); Sp(8)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        val octx = androidx.compose.ui.platform.LocalContext.current
        Column { T("Overlay", 14, TX, true); T(if (OverlayPrefs.on) "Aktif · ${OverlayPrefs.STYLES[OverlayPrefs.style]}" else "Mati", 11, MUT) }
        Toggle(OverlayPrefs.on, compact = true) { on ->
            if (on && !android.provider.Settings.canDrawOverlays(octx)) { OverlayService.openPermission(octx); return@Toggle }
            OverlayPrefs.on = on; OverlayPrefs.save(octx); OverlayService.sync(octx)
        }
    }
}

/** Refresh rate layar saat ini (Hz), ikut berubah kalau pengguna mengganti 30/60/120 Hz. */
@Composable
fun rememberRefreshRate(): Int {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val dm = remember { ctx.getSystemService(android.hardware.display.DisplayManager::class.java) }
    fun now() = Math.round(dm.getDisplay(android.view.Display.DEFAULT_DISPLAY).refreshRate)
    var hz by remember { mutableStateOf(now()) }
    DisposableEffect(dm) {
        val l = object : android.hardware.display.DisplayManager.DisplayListener {
            override fun onDisplayAdded(id: Int) {}
            override fun onDisplayRemoved(id: Int) {}
            override fun onDisplayChanged(id: Int) { hz = now() }
        }
        dm.registerDisplayListener(l, android.os.Handler(android.os.Looper.getMainLooper()))
        onDispose { dm.unregisterDisplayListener(l) }
    }
    return hz
}

/** Kartu suhu CPU (GPU di bawahnya). Dibaca tiap ~1 detik lewat Shizuku/root (jalur ringan khusus suhu). Tanpa akses, kartu menampilkan "Perlu Shizuku/root"; nilai terakhir ditahan saat gagal baca sesaat. */
@Composable
fun TempCard(mod: Modifier) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var d by remember { mutableStateOf<Sensors.QuickTemps?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            val r = withContext(Dispatchers.IO) {
                // Overlay / rekaman sudah membaca sensor: pakai hasilnya. Selain itu baca suhu saja,
                // tanpa menunggu pembacaan penuh yang berat (sleep + dumpsys) supaya angka langsung muncul dan tidak telat.
                val shared = if (Recorder.active || Sampler.overlayWanted)
                    Sampler.lastSensors?.let { Sensors.QuickTemps(it.tCpu, it.tGpu, it.tBat, it.tSkin) } else null
                shared ?: if (Shell.mode() != "-") runCatching { Sensors.readTemps(ctx) }.getOrNull() else null
            }
            // Gagal baca sesaat (Shizuku belum siap) jangan menghapus angka terakhir; coba lagi
            if (r != null) d = r
            delay(1000L)
        }
    }
    val cpu = d?.tCpu?.takeIf { it > 0f }
    val gpu = d?.tGpu?.takeIf { it > 0f }
    val col = when { cpu == null -> MUT; cpu >= 40f -> AC; else -> Color(0xFF4ADE80) }
    fun f(v: Float) = "%.0f°C".format(v)
    Card2(mod) {
        T("SUHU CPU", 11, MUT, true); Sp(4)
        T(if (cpu != null) f(cpu) else "-", 28, col, true); Sp(6)
        Bar(((cpu ?: 0f) / 60f).coerceIn(0f, 1f), 6, listOf(col.copy(alpha = 0.6f), col))
        Sp(6)
        T(when {
            cpu != null -> "GPU " + (gpu?.let { f(it) } ?: "-")
            Shell.mode() == "-" -> "Perlu Shizuku/root"
            else -> "Membaca sensor…"
        }, 11, MUT, maxLines = 1)
    }
}

/** Kartu baterai: persen di atas (besar), suhu baterai di bawahnya. Tidak butuh Shizuku/root: dibaca dari sistem tiap ~1 detik. */
@Composable
fun BatteryTempCard(mod: Modifier) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var pct by remember { mutableStateOf<Int?>(null) }
    var bat by remember { mutableStateOf<Float?>(null) }
    LaunchedEffect(Unit) {
        while (true) {
            val r = withContext(Dispatchers.IO) {
                val i = runCatching { ctx.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED)) }.getOrNull()
                val l = i?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val sc = i?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1) ?: -1
                val p = if (l >= 0 && sc > 0) Math.round(l * 100f / sc) else null
                p to Sensors.quickBatteryTemp(ctx).takeIf { it > 0f }
            }
            if (r.first != null) pct = r.first
            if (r.second != null) bat = r.second
            delay(1000L)
        }
    }
    val pcol = when { pct == null -> MUT; pct!! <= 20 -> Color(0xFFF87171); else -> Color(0xFF4ADE80) }
    val tcol = when { bat == null -> MUT; bat!! >= 40f -> AC; else -> Color(0xFF4ADE80) }
    Card2(mod) {
        T("BATERAI", 11, MUT, true); Sp(4)
        T(pct?.let { "$it%" } ?: "-", 28, pcol, true); Sp(6)
        Bar(((pct ?: 0) / 100f).coerceIn(0f, 1f), 6, listOf(pcol.copy(alpha = 0.6f), pcol))
        Sp(6)
        T("Suhu " + (bat?.let { "%.0f°C".format(it) } ?: "-"), 11, tcol, maxLines = 1)
    }
}

@Composable
fun HomeScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Hero()
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            DeviceCard()
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BatteryTempCard(Modifier.weight(1f))
                TempCard(Modifier.weight(1f))
            }
            FpsCard()
            RecCard()
            Spacer(Modifier.height(NAV_SPACE))
        }
    }
}

@Composable
fun Pill(text: String, ok: Boolean) =
    Text(text, color = if (ok) Color(0xFF4ADE80) else MUT, fontSize = 13.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.background(if (ok) Color(0x2E2EA043) else BD, RoundedCornerShape(50)).padding(horizontal = 14.dp, vertical = 8.dp))

@Composable
fun GameCard(p: Preset) {
    val sh = RoundedCornerShape(20.dp)
    val cfg = Store.configured[p.key]
    val ctx = androidx.compose.ui.platform.LocalContext.current
    Row(Modifier.fillMaxWidth().background(cardBg, sh).border(1.dp, BD, sh).clickable {
        if (p.key == "silverpalace") android.widget.Toast.makeText(ctx, "Config Silver Palace belum tersedia", android.widget.Toast.LENGTH_SHORT).show()
        else Store.game = p.key
    }.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        val img = when (p.key) { "wuwa" -> R.drawable.game_wuwa; "silverpalace" -> R.drawable.game_silverpalace; else -> 0 }
        if (img != 0) {
            androidx.compose.foundation.Image(androidx.compose.ui.res.painterResource(img), null,
                Modifier.size(76.dp).clip(RoundedCornerShape(16.dp)))
        } else {
            Box(Modifier.size(76.dp).background(p.color, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) { Ico(p.icon, Color.White, 32.dp) }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            T(p.name, 18, Color.White, true, maxLines = 1)
            Pill(if (cfg != null) "Terkonfigurasi" else "Belum dikonfigurasi", cfg != null)
            if (cfg != null) T(cfg, 12, MUT)
        }
        T("›", 28, AC)
    }
}

@Composable
fun ConfigList() = Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = NAV_SPACE), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Text("GAME PROFILES", color = TX, fontSize = 20.sp, letterSpacing = 3.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, style = TitleShadow, modifier = Modifier.padding(horizontal = 4.dp))
    T("Kelola config dan pengaturan game.", 14, MUT, mod = Modifier.padding(horizontal = 4.dp))
    PRESETS.filter { it.key == "wuwa" }.forEach { GameCard(it) }
    GameCard(SILVER_PALACE)
}

@Composable
fun GameDetail(p: Preset) {
    val scope = rememberCoroutineScope()
    var msg by remember(p.key) { mutableStateOf("") }
    var open by remember { mutableStateOf(false) }
    val path = Store.paths[p.key] ?: p.defaultPath
    val content = p.content(Store.profile)
    val sh = RoundedCornerShape(22.dp)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = NAV_SPACE), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        T("‹ Kembali", 15, AC, true, Modifier.clickable { Store.game = null }.padding(vertical = 4.dp))
        T(p.name, 24, TX, true)
        // Baris game + Ganti
        Row(Modifier.fillMaxWidth().background(cardBg, sh).border(1.dp, BD, sh).padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Ico(4, Color(0xFF4F8FE0))
            T("${p.name} · ${p.file}", 14, TX, true, Modifier.weight(1f), 1)
            T("Ganti ›", 14, PINK, true, Modifier.clickable { Store.game = null })
        }
        // Baris Kualitas
        Row(Modifier.fillMaxWidth().background(cardBg, sh).border(1.dp, BD, sh).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Ico(5, Color(0xFFE0B040))
            T("Kualitas", 14, TX, true)
            Spacer(Modifier.weight(1f))
            listOf("Ultra" to 2, "High" to 1, "Medium" to 0).forEach { (label, idx) ->
                Box(Modifier.clip(RoundedCornerShape(16.dp)).background(if (Store.profile == idx) VIOLET else Color(0xFF23252D))
                    .clickable { Store.profile = idx }.padding(horizontal = 11.dp, vertical = 10.dp)) { T(label, 13, Color.White, true) }
            }
        }
        // Tombol Install
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF5B9BDC), VIOLET, PINK)))
            .clickable {
                scope.launch {
                    val r = withContext(Dispatchers.IO) { ConfigInstaller.install(path, content) }
                    msg = r.msg
                    if (r.ok) {
                        Store.configured[p.key] = PROFILES[Store.profile] + " · " + FPS[Store.profile] + " FPS"
                        Store.installs++; Store.last = p.name + " · " + PROFILES[Store.profile]
                    }
                }
            }.padding(vertical = 16.dp), contentAlignment = Alignment.Center) { T("Install", 20, Color.White, true) }
        if (msg.isNotEmpty()) T(msg, 13, MUT)
        T(if (open) "Detail config ▾" else "Detail config ›", 14, MUT, true, Modifier.clickable { open = !open }.padding(vertical = 8.dp))
        if (open) {
            OutlinedTextField(path, { Store.paths[p.key] = it }, label = { Text("Path file config") }, modifier = Modifier.fillMaxWidth())
            if (p.editable) OutlinedTextField(Store.customText, { Store.customText = it }, label = { Text("Isi config") },
                modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp))
            else Box(Modifier.fillMaxWidth().background(Color(0xFF07090E), RoundedCornerShape(10.dp)).padding(12.dp)) {
                T(content, 12, Color(0xFF9BF09A))
            }
            Box(Modifier.fillMaxWidth().border(1.dp, BD, RoundedCornerShape(16.dp)).clickable {
                scope.launch { msg = withContext(Dispatchers.IO) { ConfigInstaller.restore(path) }.msg }
            }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) { T("Kembalikan backup", 14, TX, true) }
        }
    }
}

@Composable
fun StatRow(label: String, value: String) =
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) { T(label, 14, MUT); T(value, 14, TX, true) }

const val DISCORD_URL = "https://discord.gg/EFaCxujTcC"
const val AUTHOR_NAME = "lismoyca"
const val AUTHOR_URL = "https://discord.com/users/1426827460187656223"

/** Satu baris berpanah (gaya Pulse Monitor): judul, keterangan, tanda ›. */
@Composable
fun SetItem(title: String, sub: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cardBg).clickable { onClick() }.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            T(title, 16, Color.White, true)
            T(sub, 12, subTx)
        }
        T("›", 22, subTx)
    }
}

@Composable
fun AccessOption(title: String, desc: String, color: Color, bg: Color, selected: Boolean, shield: Boolean, onClick: () -> Unit) {
    val sh = RoundedCornerShape(28.dp)
    Row(Modifier.fillMaxWidth().clip(sh).background(bg, sh)
        .border(if (selected) 2.dp else 1.dp, if (selected) color else color.copy(alpha = 0.35f), sh)
        .clickable { onClick() }.padding(horizontal = 18.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(56.dp), contentAlignment = Alignment.Center) {
            if (shield) Ico(6, color, 36.dp) else Box(Modifier.size(26.dp, 40.dp).background(color, RoundedCornerShape(7.dp)))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            T(title, 22, color, true)
            T(desc, 16, TX)
        }
    }
}

@Composable
fun SettingCard(title: String, content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxWidth().background(cardBg, RoundedCornerShape(20.dp)).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
) { T(title, 16, Color.White, true); content() }

/** Dialog umum: judul, keterangan, isi bisa digulir, tombol Tutup. */
@Composable
fun TabDialog(title: String, sub: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Color.Black, shape = RoundedCornerShape(28.dp),
        title = { Column { Text(title, color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp); Text(sub, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp)) } },
        text = { Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) { content() } },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = VIOLET, fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
    )
}

@Composable
fun SettingsScreen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var dlg by remember { mutableStateOf(false) }
    var wall by remember { mutableStateOf(false) }
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) Thread { Wallpaper.decodePreview(ctx, u)?.let { Wallpaper.cropSrc = it } }.start()
    }
    val heroPicker = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) Thread { Wallpaper.decodePreview(ctx, u)?.let { Wallpaper.heroCropSrc = it } }.start()
    }
    fun open(url: String) {
        try { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { android.widget.Toast.makeText(ctx, "Tidak ada aplikasi untuk membuka tautan", android.widget.Toast.LENGTH_SHORT).show() }
    }
    val green = Color(0xFF4ADE80)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = NAV_SPACE), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("SETTINGS", color = TX, fontSize = 20.sp, letterSpacing = 3.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, style = TitleShadow, modifier = Modifier.weight(1f))
            val live = Access.status == 2
            Row(Modifier.background(Color(0x14FFFFFF), RoundedCornerShape(10.dp)).padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).background(if (live) green else MUT, CircleShape)); Spacer(Modifier.width(5.dp))
                Text(if (live) "LIVE" else "OFF", color = if (live) green else MUT, fontSize = 11.sp, letterSpacing = 1.5.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
            }
        }
        Sp(4)

        SetItem("Akses", when {
            Access.busy > 0 -> "Memeriksa…"
            Access.status == 2 -> (if (Access.choice == Access.ROOT) "Root" else "Shizuku") + " · Terhubung"
            Access.status == 1 -> "Ketuk untuk beri izin"
            else -> "Pilih Shizuku atau Root"
        }, { Access.refresh(); dlg = true })
        if (Access.message.isNotEmpty() && Access.status != 2) T(Access.message, 12, subTx, false, Modifier.padding(horizontal = 12.dp))

        SetItem("Warna dan ukuran overlay", "Gaya ${OverlayPrefs.STYLES[OverlayPrefs.style]} · teks, latar, transparansi, ukuran", { Store.overlayColorDlg = true })
        SetItem("Notifikasi pantauan", if (MonitorPrefs.notifOn) "Aktif · baterai + tombol rekam FPS" else "Mati", { Store.monitorDlg = true })
        SetItem("Wallpaper", "Latar belakang dan kotak atas Beranda", { wall = true })
        SetItem("Kesehatan & log", "Cek fitur jalan atau tidak, lalu kirim laporannya", { Store.health = true })

        SettingCard("Komunitas") {
            LinkRow({ GamepadIcon(Color(0xFF8E86F0), Modifier.size(26.dp)) }, "Komunitas Discord", "") { open(DISCORD_URL) }
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x14FFFFFF)))
            LinkRow({ PersonIcon(Color(0xFFE49A72), Modifier.size(26.dp)) }, "Pembuat aplikasi", AUTHOR_NAME) { open(AUTHOR_URL) }
        }
        Sp(8)
    }

    OverlayDialogs()
    if (Store.monitorDlg) TabDialog("Notifikasi pantauan", "Baterai, layar nyala/mati, dan tombol rekam FPS", { Store.monitorDlg = false }) {
        SettingCard("Notifikasi") {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("Tetap aktif di latar belakang", 14, Color.White, true)
                    T("Persen, arus, daya, dan suhu di notifikasi.", 12, Color.White)
                }
                Toggle(MonitorPrefs.notifOn) { on ->
                    MonitorPrefs.notifOn = on; MonitorPrefs.save(ctx)
                    if (on) RecService.ensureRunning(ctx) else RecService.stop(ctx)
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("Nama aplikasi di notifikasi", 14, Color.White, true)
                    T("Menampilkan game / aplikasi yang sedang di depan.", 12, Color.White)
                }
                Toggle(MonitorPrefs.notifApp) { on -> MonitorPrefs.notifApp = on; MonitorPrefs.save(ctx); Watchdog.sync(ctx, MonitorPrefs.notifOn) }
            }
            if (!android.provider.Settings.canDrawOverlays(ctx)) {
                T("Tips: izinkan \"Tampil di atas aplikasi lain\" supaya nama aplikasi di notifikasi tidak telat saat HP menghemat daya (HyperOS / MIUI).", 12, Color.White)
                PillButton("Buka pengaturan izin", filled = false) {
                    ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        android.net.Uri.parse("package:" + ctx.packageName)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }
    }

    if (wall) TabDialog("Wallpaper", "Latar belakang dan kotak atas Beranda", { wall = false }) {
        SettingCard("Latar belakang aplikasi") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton(if (Wallpaper.image == null) "Pilih gambar" else "Ganti gambar") {
                    picker.launch(androidx.activity.result.PickVisualMediaRequest(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                if (Wallpaper.image != null) PillButton("Hapus", filled = false) { Wallpaper.clear(ctx) }
            }
            T(if (Wallpaper.image == null) "Belum ada gambar. Latar di belakang kartu masih hitam polos." else "Tampil di belakang semua kartu dan halaman.", 12, Color.White)
            if (Wallpaper.image != null) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { T("Gelap", 13, Color.White); T("${(Wallpaper.dim * 100).toInt()}%", 13, Color.White, true) }
                AccSlider(Wallpaper.dim, 0.2f..1f, { Wallpaper.dim = it }) { Wallpaper.saveDim(ctx) }
            }
        }
        SettingCard("Wallpaper kotak atas") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton(if (Wallpaper.heroImage == null) "Pilih gambar" else "Ganti gambar") {
                    heroPicker.launch(androidx.activity.result.PickVisualMediaRequest(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                if (Wallpaper.heroImage != null) PillButton("Hapus", filled = false) { Wallpaper.clearHero(ctx) }
            }
            T(if (Wallpaper.heroImage == null) "Belum ada gambar. Kotak ASTRA ENGINE di Beranda memakai gradasi bawaan." else "Dipakai sebagai latar kotak ASTRA ENGINE di Beranda.", 12, Color.White)
        }
    }

    Wallpaper.heroCropSrc?.let { src ->
        val dm = ctx.resources.displayMetrics
        CropDialog(src, (dm.widthPixels - 32 * dm.density) / ((HERO_H.value - 40f) * dm.density), "Potong wallpaper kotak atas", onCancel = { Wallpaper.heroCropSrc = null }) { cropped ->
            Wallpaper.heroCropSrc = null
            Thread { Wallpaper.saveHero(ctx, cropped) }.start()
        }
    }

    Wallpaper.cropSrc?.let { src ->
        val dm = ctx.resources.displayMetrics
        CropDialog(src, dm.widthPixels.toFloat() / dm.heightPixels, "Potong wallpaper aplikasi", onCancel = { Wallpaper.cropSrc = null }) { cropped ->
            Wallpaper.cropSrc = null
            Thread { Wallpaper.saveCropped(ctx, cropped) }.start()
        }
    }

    if (dlg) androidx.compose.ui.window.Dialog(onDismissRequest = { dlg = false }) {
        val dsh = RoundedCornerShape(36.dp)
        Column(Modifier.fillMaxWidth().background(Color.Black, dsh).padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            T("Izinkan Akses", 30, TX, true)
            T("Pilih metode yang ingin dipakai untuk akses tingkat tinggi.", 17, TX)
            AccessOption("Shizuku", "Tanpa root, jalan lewat Wireless Debugging atau ADB.", VIOLET, Color(0xFF131120), Access.choice != Access.ROOT, false) { Access.select(Access.SHIZUKU); dlg = false }
            AccessOption("Root", "Butuh perangkat yang di-root (Magisk, KernelSU, APatch, dll).", Color(0xFFE8A27C), Color(0xFF17120F), Access.choice == Access.ROOT, true) { Access.select(Access.ROOT); dlg = false }
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                TextButton(onClick = { dlg = false }) { Text("Batal", color = VIOLET, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

/** Ruang di ujung bawah halaman untuk bilah navigasi melayang (bilah + jarak + bilah gestur sistem). */
val NAV_SPACE = 100.dp

/** Bayangan teks untuk judul halaman (sama dengan judul BATERAI dan STATISTIK) supaya terbaca di atas wallpaper terang. */
private val TitleShadow = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(Color.Black.copy(alpha = 0.6f), Offset(0f, 2f), 8f))

@Composable
fun NavBar(tab: Int, onTab: (Int) -> Unit) {
    val items = listOf("Beranda" to 0, "Config" to 1, "Settings" to 2)
    val sh = RoundedCornerShape(26.dp)
    // warna tab aktif per tab: Beranda merah, Config biru, Settings ungu
    val navColors = listOf(Color(0xFFEF4444), Color(0xFF3B82F6), Color(0xFFA855F7))
    // Dengan wallpaper: bilah 45% tembus (opasitas 55%); kartu lain 80% tembus. Tanpa wallpaper tetap warna kartu
    val navBg = if (Wallpaper.image != null) Color(0xFF1E1F26).copy(alpha = 0.55f) else cardBg
    // Bilah selebar isinya (tiap tab 76 dp) dan di tengah, jadi tab rapat, tidak melebar ke seluruh layar
    Box(Modifier.fillMaxWidth().padding(bottom = 8.dp), contentAlignment = Alignment.Center) {
    Row(Modifier.background(navBg, sh).border(1.dp, BD, sh).padding(5.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        items.forEachIndexed { i, (label, icon) ->
            val on = tab == i
            val navAc = navColors[i]
            Column(Modifier.width(76.dp)
                .drawBehind { if (on) drawRoundRect(navAc, Offset(size.width * 0.28f, -5.dp.toPx()), Size(size.width * 0.44f, 3.dp.toPx()), CornerRadius(1.5f.dp.toPx())) }
                .background(if (on) navAc.copy(alpha = 0.16f) else Color.Transparent, RoundedCornerShape(14.dp))
                .clickable { onTab(i) }.padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                // ikon: 0 home, 1 petir, 3 gerigi
                Ico(listOf(0, 1, 3)[icon], if (on) navAc else MUT, 20.dp)
                T(if (on) label.uppercase() else label, 10, if (on) navAc else MUT, on, maxLines = 1)
            }
        }
    }
    }
}
