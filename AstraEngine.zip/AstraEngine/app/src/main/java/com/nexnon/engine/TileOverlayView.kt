package com.nexnon.engine

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import kotlin.math.ceil

/**
 * Overlay gaya "Pill": SATU BARIS pil gelap, tiap item = ikon terisi di kiri + nilai di kanan ikon.
 * Urutan: FPS, CPU, GPU, baterai (%), suhu baterai (C), sentuhan (Hz).
 * Angka memakai spasi sebelum satuan ("51 %", "32 °C").
 *
 *   [FPS] 61   [CPU] 51 %   [GPU] 69 %   [baterai] 62 %   [termometer] 32 °C   [sentuhan] 240 Hz
 */
class TileOverlayView(ctx: Context) : View(ctx) {
    var snap = OvSnap()
    var rec = false
    var touch = "-"
    var scale = 1f
    var bgColor = 0xE6101014.toInt()
    var strokeColor = 0x22FFFFFF
    var textColor = 0xFFFFFFFF.toInt()

    private val d = ctx.resources.displayMetrics.density
    private fun u(v: Float) = v * d * scale
    private val RED = 0xFFFF5C5C.toInt()
    private val ORG = 0xFFFF9F43.toInt()
    private val DARK = 0xFF101014.toInt()      // warna huruf di dalam ikon terisi

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val valP = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }
    private val ip = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labP = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
    private val rect = RectF()
    private var shadow = false         // true saat menggambar lapisan bayangan (satu warna, tanpa huruf)

    private class Tile(val value: String, val kind: Int, val frac: Float = 0f, val fill: Int = 0, val worst: String)

    private fun pct(v: Int) = if (v >= 0) "$v %" else "-"

    // kind ikon: 0 FPS, 1 CPU, 2 GPU, 3 baterai vertikal, 4 termometer, 5 sentuhan (kartu TOUCH)
    private fun tiles(): List<Tile> {
        val s = snap
        val batFill = when { s.batPct in 0..15 -> RED; s.batPct in 16..30 -> ORG; else -> 0xFFD6D6D6.toInt() }
        return listOf(
            Tile("${s.fps}", 0, worst = "000"),
            Tile(pct(s.cpu), 1, worst = "100 %"),
            Tile(pct(s.gpu), 2, worst = "100 %"),
            Tile(pct(s.batPct), 3, s.batPct.coerceIn(0, 100) / 100f, batFill, "100 %"),
            Tile(if (s.tBat >= 0f) "%.0f \u00B0C".format(s.tBat) else "-", 4, worst = "88 \u00B0C"),
            Tile(if (touch == "-" || touch.isBlank()) "-" else "$touch Hz", 5, worst = "000 Hz")
        )
    }

    private fun padX() = u(10f)
    private fun padY() = u(5f)
    private fun rowH() = u(22f)
    private fun icoW() = u(22f)
    private fun icoGap() = u(5f)
    private fun itemGap() = u(14f)
    private fun txtSize() = u(14f)

    /** Lebar tiap item dihitung dari teks TERPANJANG, supaya overlay tidak berubah lebar saat angka berubah. */
    private fun itemWidths(): List<Float> {
        valP.textSize = txtSize()
        return tiles().map { icoW() + icoGap() + valP.measureText(it.worst) }
    }

    /** Skala terbesar (maks 1) agar lebar overlay muat dalam [maxPx]; dipakai pratinjau di dialog supaya tidak terpotong. */
    fun fitScale(maxPx: Float): Float {
        val keep = scale; scale = 1f
        val w1 = padX() * 2 + itemWidths().sum() + itemGap() * (tiles().size - 1)
        scale = keep
        return if (w1 > maxPx) maxPx / w1 else 1f
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val ws = itemWidths()
        val w = padX() * 2 + ws.sum() + itemGap() * (ws.size - 1)
        val h = padY() * 2 + rowH()
        setMeasuredDimension(ceil(w).toInt(), ceil(h).toInt())
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val rad = u(10f)
        p.style = Paint.Style.FILL; p.color = bgColor
        rect.set(0f, 0f, w, h); c.drawRoundRect(rect, rad, rad, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = strokeColor
        rect.set(d / 2, d / 2, w - d / 2, h - d / 2); c.drawRoundRect(rect, rad, rad, p)

        val cy = padY() + rowH() / 2f
        val ts = tiles(); val ws = itemWidths()
        valP.textAlign = Paint.Align.LEFT
        valP.textSize = txtSize()
        valP.color = textColor
        var x = padX()
        ts.forEachIndexed { i, t ->
            val icx = x + icoW() / 2f
            // bayangan: ikon yang sama, satu warna pudar, bergeser ke kanan bawah
            val n = c.saveLayerAlpha(null, 89)
            c.translate(u(1.6f), u(1.6f))
            shadow = true; icon(c, t, icx, cy); shadow = false
            c.restoreToCount(n)
            icon(c, t, icx, cy)
            c.drawText(t.value, x + icoW() + icoGap(), cy - (valP.ascent() + valP.descent()) / 2f, valP)
            x += ws[i] + itemGap()
        }
        if (rec) { p.style = Paint.Style.FILL; p.color = RED; c.drawCircle(u(5f), u(5f), u(3f), p) }
    }

    private fun label(c: Canvas, txt: String, cx: Float, cy: Float, size: Float) {
        if (shadow) return
        labP.textSize = u(size); labP.color = DARK
        c.drawText(txt, cx, cy - (labP.ascent() + labP.descent()) / 2f, labP)
    }

    /** Ikon digambar langsung (tanpa berkas gambar), gaya terisi seperti referensi. */
    private fun icon(c: Canvas, t: Tile, cx: Float, cy: Float) {
        val half = u(10.5f)
        ip.style = Paint.Style.FILL; ip.color = textColor
        ip.strokeCap = Paint.Cap.ROUND; ip.strokeJoin = Paint.Join.ROUND
        when (t.kind) {
            1, 2 -> {   // chip terisi + huruf CPU / GPU. CPU: 2 kaki tebal per sisi; GPU: 3 kaki tipis per sisi
                val r = half * 0.74f
                val cpu = t.kind == 1
                val pw = if (cpu) u(2.1f) else u(1.3f)
                val offs = if (cpu) floatArrayOf(-r * 0.45f, r * 0.45f) else floatArrayOf(-r * 0.55f, 0f, r * 0.55f)
                for (o in offs) {
                    rect.set(cx + o - pw / 2, cy - half, cx + o + pw / 2, cy - r + u(0.5f)); c.drawRect(rect, ip)
                    rect.set(cx + o - pw / 2, cy + r - u(0.5f), cx + o + pw / 2, cy + half); c.drawRect(rect, ip)
                    rect.set(cx - half, cy + o - pw / 2, cx - r + u(0.5f), cy + o + pw / 2); c.drawRect(rect, ip)
                    rect.set(cx + r - u(0.5f), cy + o - pw / 2, cx + half, cy + o + pw / 2); c.drawRect(rect, ip)
                }
                rect.set(cx - r, cy - r, cx + r, cy + r); c.drawRoundRect(rect, u(2.5f), u(2.5f), ip)
                label(c, if (cpu) "CPU" else "GPU", cx, cy, 5.6f)
            }
            3 -> {   // baterai vertikal: badan outline, kepala di atas, isi naik dari bawah
                val bw = u(5.4f); val top = cy - half * 0.9f; val bot = cy + half * 0.9f
                ip.style = Paint.Style.STROKE; ip.strokeWidth = u(1.5f)
                rect.set(cx - bw, top + u(2.2f), cx + bw, bot); c.drawRoundRect(rect, u(2f), u(2f), ip)
                ip.style = Paint.Style.FILL
                rect.set(cx - u(2.2f), top, cx + u(2.2f), top + u(2.4f)); c.drawRoundRect(rect, u(0.8f), u(0.8f), ip)
                val inT = top + u(2.2f) + u(2.2f); val inB = bot - u(2.2f)
                val fy = inB - (inB - inT) * t.frac
                if (t.frac > 0f) { ip.color = if (shadow) textColor else t.fill; rect.set(cx - bw + u(2.2f), fy, cx + bw - u(2.2f), inB); c.drawRoundRect(rect, u(0.8f), u(0.8f), ip) }
            }
            4 -> {   // termometer: tabung + bola terisi + garis skala di kanan
                val x0 = cx - u(2f)
                val tw = u(2.4f); val top = cy - half * 0.95f; val bulbR = u(3.8f); val bulbC = cy + half * 0.95f - bulbR
                ip.style = Paint.Style.STROKE; ip.strokeWidth = u(1.5f)
                rect.set(x0 - tw, top, x0 + tw, bulbC); c.drawRoundRect(rect, tw, tw, ip)
                ip.style = Paint.Style.FILL
                c.drawCircle(x0, bulbC, bulbR, ip)
                rect.set(x0 - u(0.8f), cy - half * 0.35f, x0 + u(0.8f), bulbC); c.drawRect(rect, ip)
                ip.style = Paint.Style.STROKE; ip.strokeWidth = u(1.2f)
                for (k in 0..2) { val y = top + u(2.2f) + k * u(3.4f); c.drawLine(x0 + tw + u(1.6f), y, x0 + tw + u(4.2f), y, ip) }
            }
            5 -> {   // sentuhan: kartu terisi bertuliskan TOUCH (gaya sama dengan kartu FPS)
                val cw = u(16f); val ch = u(13f)
                val l = cx - u(9f); val t0 = cy - u(7f)
                ip.color = textColor
                rect.set(l, t0, l + cw, t0 + ch); c.drawRoundRect(rect, u(2.5f), u(2.5f), ip)
                label(c, "TOUCH", l + cw / 2f, t0 + ch / 2f, 4.3f)
            }
            else -> {   // FPS: satu kartu terisi bertuliskan FPS
                val cw = u(16f); val ch = u(13f)
                val l = cx - u(9f); val t0 = cy - u(7f)
                ip.color = textColor
                rect.set(l, t0, l + cw, t0 + ch); c.drawRoundRect(rect, u(2.5f), u(2.5f), ip)
                label(c, "FPS", l + cw / 2f, t0 + ch / 2f, 5.8f)
            }
        }
    }
}
