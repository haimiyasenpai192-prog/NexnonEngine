package com.nexnon.engine

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/** Ikon baterai tegak: badan bergaris, kepala kecil di atas, dan petir di dalamnya. */
@Composable
fun BatteryNavIcon(color: Color, modifier: Modifier = Modifier) {
    Box(Modifier.fillMaxWidth().height(26.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier.size(width = 15.dp, height = 19.dp)) {
            val w = size.width; val h = size.height
            val sw = 1.6.dp.toPx()
            drawRoundRect(color, topLeft = Offset(w * 0.36f, 0f), size = Size(w * 0.28f, h * 0.10f), cornerRadius = CornerRadius(1.5.dp.toPx()))
            drawRoundRect(color, topLeft = Offset(w * 0.08f + sw / 2f, h * 0.12f + sw / 2f),
                size = Size(w * 0.84f - sw, h * 0.88f - sw), cornerRadius = CornerRadius(3.dp.toPx()), style = Stroke(width = sw))
            val bolt = Path().apply {
                moveTo(w * 0.58f, h * 0.30f); lineTo(w * 0.40f, h * 0.55f)
                lineTo(w * 0.60f, h * 0.60f); lineTo(w * 0.42f, h * 0.84f)
            }
            drawPath(bolt, color, style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

/** Ikon matahari (layar menyala): lingkaran dengan delapan sinar. */
@Composable
fun SunIcon(color: Color) {
    Canvas(Modifier.size(22.dp)) {
        val c = center; val w = size.width; val sw = 1.8.dp.toPx()
        drawCircle(color, radius = w * 0.20f, center = c, style = Stroke(width = sw))
        for (i in 0 until 8) {
            val a = Math.toRadians(i * 45.0); val dx = Math.cos(a).toFloat(); val dy = Math.sin(a).toFloat()
            drawLine(color, Offset(c.x + dx * w * 0.32f, c.y + dy * w * 0.32f), Offset(c.x + dx * w * 0.46f, c.y + dy * w * 0.46f),
                strokeWidth = sw, cap = StrokeCap.Round)
        }
    }
}

/** Ikon bulan sabit (layar mati). */
@Composable
fun MoonIcon(color: Color) {
    Canvas(Modifier.size(22.dp)) {
        val w = size.width
        val a = Path().apply { addOval(Rect(Offset(w * 0.12f, w * 0.10f), Size(w * 0.76f, w * 0.76f))) }
        val b = Path().apply { addOval(Rect(Offset(w * 0.38f, 0f), Size(w * 0.70f, w * 0.70f))) }
        drawPath(Path.combine(PathOperation.Difference, a, b), color)
    }
}

/** Ikon mata terbuka (terjaga). */
@Composable
fun EyeIcon(color: Color) {
    Canvas(Modifier.size(22.dp)) {
        val w = size.width; val h = size.height
        val p = Path().apply {
            moveTo(w * 0.04f, h * 0.5f); quadraticBezierTo(w * 0.5f, h * 0.02f, w * 0.96f, h * 0.5f)
            quadraticBezierTo(w * 0.5f, h * 0.98f, w * 0.04f, h * 0.5f); close()
        }
        drawPath(p, color, style = Stroke(width = 1.8.dp.toPx(), join = StrokeJoin.Round))
        drawCircle(color, radius = w * 0.15f, center = center)
    }
}
