package com.nexnon.engine

import android.os.Build

class DevInfo(val name: String = "Perangkat Android", val soc: String = "", val brand: String = "ANDROID", val android: String = "Android")

fun sysProp(k: String): String = runCatching {
    Class.forName("android.os.SystemProperties").getMethod("get", String::class.java).invoke(null, k) as String
}.getOrDefault("")

/** Sama seperti DeviceCard di Pulse Monitor: nama pasar, chipset, versi Android. */
fun loadDevInfo(): DevInfo {
    val market = sysProp("ro.product.marketname").ifEmpty { sysProp("ro.product.model") }.ifEmpty { Build.MODEL }
    val brand = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
    val name = if (market.startsWith(brand, true)) market else "$brand $market"
    val soc = if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotEmpty() && Build.SOC_MODEL != "unknown")
        "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}".trim() else Build.HARDWARE
    return DevInfo(name, soc, Build.BRAND.uppercase(), "Android ${Build.VERSION.RELEASE}")
}

fun fmtUp(ms: Long): String {
    val t = ms / 1000
    return "%dj %dm %dd".format(t / 3600, (t % 3600) / 60, t % 60)
}

/**
 * Chipset HP untuk memilih config otomatis: "Mediatek", "Snapdragon", atau null bila tidak dikenali.
 * Dibaca dari SOC_MANUFACTURER / SOC_MODEL (Android 12+), HARDWARE, BOARD, ro.board.platform, dan ro.hardware.
 */
fun detectChipset(): String? {
    val t = buildList {
        if (Build.VERSION.SDK_INT >= 31) { add(Build.SOC_MANUFACTURER); add(Build.SOC_MODEL) }
        add(Build.HARDWARE); add(Build.BOARD); add(sysProp("ro.board.platform")); add(sysProp("ro.hardware"))
    }.joinToString(" ").lowercase()
    return when {
        t.contains("mediatek") || Regex("\\bmt\\d{3,4}").containsMatchIn(t) -> "Mediatek"
        t.contains("qualcomm") || t.contains("qcom") || t.contains("snapdragon") ||
            Regex("\\b(sm|sdm|msm|sxr)\\d{3,4}").containsMatchIn(t) -> "Snapdragon"
        else -> null
    }
}
