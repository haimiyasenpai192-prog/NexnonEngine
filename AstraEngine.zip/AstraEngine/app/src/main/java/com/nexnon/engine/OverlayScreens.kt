package com.nexnon.engine

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val OV_ACC = Color(0xFF3DF0FF)
private val OV_YEL = Color(0xFFFFD866)
private val OV_GRN = Color(0xFF7CFFB2)

/** Dialog Gaya overlay + dialog Warna dan ukuran overlay. Dipasang di SettingsScreen. */
@Composable
fun OverlayDialogs() {
    if (Store.styleDlg) StyleDialog { Store.styleDlg = false }
    if (Store.overlayColorDlg) TabDialog("Warna dan ukuran overlay", "Perubahan muncul dalam sekitar 1 detik", { Store.overlayColorDlg = false }) { OverlayColorContent() }
}

@Composable
private fun StyleDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Color.Black, shape = RoundedCornerShape(28.dp),
        title = { Text("Gaya overlay", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 24.sp) },
        text = {
            Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Pratinjau mengikuti warna dan transparansi di Settings.", color = Color(0xFFA9B0B5), fontSize = 13.sp)
                StyleOption(0, "Simple", "Satu baris: FPS, CPU, GPU, baterai", onDismiss)
                StyleOption(1, "Normal", "FPS besar dan cincin CPU, GPU", onDismiss)
                StyleOption(2, "Compact", "Bilah per baris: FPS, CPU, GPU, dan baterai", onDismiss)
                StyleOption(3, "Pill", "Satu baris ikon + angka: FPS, CPU, GPU, baterai, suhu, sentuhan", onDismiss)
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = VIOLET, fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
    )
}

@Composable
private fun StyleOption(idx: Int, title: String, sub: String, onPicked: () -> Unit) {
    val ctx = LocalContext.current
    val sel = OverlayPrefs.style == idx
    val shape = RoundedCornerShape(20.dp)
    Column(Modifier.fillMaxWidth().clip(shape)
        .background(if (sel) OV_ACC.copy(alpha = 0.10f) else Color(0x12FFFFFF))
        .border(if (sel) 2.dp else 1.dp, if (sel) OV_ACC else Color(0x22FFFFFF), shape)
        .clickable { OverlayPrefs.style = idx; OverlayPrefs.save(ctx); onPicked() }.padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(sub, color = MUT, fontSize = 12.sp)
            }
            Box(Modifier.size(24.dp).background(if (sel) OV_ACC else Color.Transparent, CircleShape)
                .border(2.dp, if (sel) OV_ACC else MUT, CircleShape), contentAlignment = Alignment.Center) {
                if (sel) Text("✓", color = Color(0xFF101014), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        when (idx) {
            1 -> NormalPreview()
            2 -> BarPreview()
            3 -> TilePreview()
            else -> {
                val pv = RoundedCornerShape(20.dp)
                Text(simplePreview(), color = Color(OverlayPrefs.text), fontSize = 10.5.sp, lineHeight = 15.sp, fontFamily = FontFamily.Monospace,
                    modifier = Modifier.clip(pv).background(Color(withAlpha(OverlayPrefs.bg, OverlayPrefs.alpha)))
                        .border(1.dp, Color(withAlpha(OverlayPrefs.text, 14)), pv).padding(horizontal = 12.dp, vertical = 6.dp))
            }
        }
    }
}

/** Pratinjau Simple: label gradasi biru-ungu-pink, isi sama dengan overlay asli. */
private fun simplePreview(): AnnotatedString {
    val s0 = Color(0xFF5E9BF5); val s1 = Color(0xFF9A86E8); val s2 = Color(0xFFEE8FBE)
    fun at(f: Float): Color = if (f < 0.5f) androidx.compose.ui.graphics.lerp(s0, s1, f * 2f) else androidx.compose.ui.graphics.lerp(s1, s2, (f - 0.5f) * 2f)
    return buildAnnotatedString {
        fun p(t: String, c: Color = Color.Unspecified, b: Boolean = false) = withStyle(SpanStyle(color = c, fontWeight = if (b) FontWeight.Bold else null)) { append(t) }
        fun g(t: String) = t.forEachIndexed { i, ch -> p(ch.toString(), at(if (t.length > 1) i / (t.length - 1f) else 1f)) }
        g("FPS"); p(" "); p("60", b = true)
        p("  "); g("CPU"); p(" 35% 42°")
        p("  "); g("GPU"); p(" 45% 41°")
        p("  "); g("RAM"); p(" 62%")
        p("  "); g("BAT"); p(" 85% 36°")
    }
}

/** Pratinjau Normal: FPS besar di kiri, cincin CPU/GPU (label + persen di dalam, MHz di bawah), garis tipis, baris RAM/BAT. */
@Composable
private fun NormalPreview() {
    val tx = Color(OverlayPrefs.text)
    val pv = RoundedCornerShape(12.dp)
    val mono = FontFamily.Monospace
    @Composable fun Ring(label: String, pct: Int, mhz: String) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(58.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val sw = 4.5.dp.toPx(); val r = 23.dp.toPx()
                    val tl = Offset(size.width / 2f - r, size.height / 2f - r)
                    val sz = androidx.compose.ui.geometry.Size(r * 2f, r * 2f)
                    drawArc(color = tx.copy(alpha = 0.16f), startAngle = -90f, sweepAngle = 360f, useCenter = false, topLeft = tl, size = sz, style = Stroke(width = sw))
                    drawArc(color = Color(loadCol(pct)), startAngle = -90f, sweepAngle = 360f * pct / 100f, useCenter = false,
                        topLeft = tl, size = sz, style = Stroke(width = sw, cap = StrokeCap.Round))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(label, color = tx, fontSize = 9.5.sp, lineHeight = 11.sp, fontWeight = FontWeight.Bold, fontFamily = mono)
                    Text("$pct%", color = tx, fontSize = 12.5.sp, lineHeight = 14.sp, fontWeight = FontWeight.Bold)
                }
            }
            Text(mhz, color = OV_YEL, fontSize = 10.5.sp, lineHeight = 15.sp, fontFamily = mono, softWrap = false)
        }
    }
    Column(Modifier.width(IntrinsicSize.Max).clip(pv).background(Color(withAlpha(OverlayPrefs.bg, OverlayPrefs.alpha)))
        .border(1.dp, Color(withAlpha(OverlayPrefs.text, 14)), pv).padding(horizontal = 14.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.Top) {
            Column(Modifier.height(58.dp).widthIn(min = 32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text("FPS", color = tx, fontSize = 10.5.sp, lineHeight = 14.sp, fontFamily = mono)
                Text("60", color = tx, fontSize = 26.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(16.dp)); Ring("CPU", 35, "2840MHz")
            Spacer(Modifier.width(14.dp)); Ring("GPU", 45, "680MHz")
        }
        Box(Modifier.padding(vertical = 8.dp).fillMaxWidth().height(0.5.dp).background(tx.copy(alpha = 0.14f)))
        Text(buildAnnotatedString {
            withStyle(SpanStyle(color = tx)) { append("RAM 62%   BAT ") }
            withStyle(SpanStyle(color = OV_GRN)) { append("36°") }
            withStyle(SpanStyle(color = OV_YEL)) { append(" 2.4W") }
        }, fontSize = 10.5.sp, lineHeight = 15.sp, fontFamily = mono, softWrap = false)
    }
}

/** Pratinjau Compact: baris FPS + bilah CPU/GPU + baris teks BAT/TMP. */
@Composable
private fun BarPreview() {
    val tx = Color(OverlayPrefs.text)
    val pv = RoundedCornerShape(14.dp)
    @Composable fun Bar(label: String, frac: Float, col: Color, value: String) {
        Row(Modifier.width(196.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = tx, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(32.dp))
            Box(Modifier.width(86.dp).height(6.dp).clip(RoundedCornerShape(3.dp)).background(tx.copy(alpha = 0.16f))) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(frac).clip(RoundedCornerShape(3.dp)).background(col))
            }
            Text(value, color = OV_YEL, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.End, modifier = Modifier.weight(1f))
        }
    }
    Column(Modifier.clip(pv).background(Color(withAlpha(OverlayPrefs.bg, OverlayPrefs.alpha)))
        .border(1.dp, Color(withAlpha(OverlayPrefs.text, 14)), pv).padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.width(196.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("FPS", color = tx, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(32.dp))
            Text("60", color = tx, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("16.7ms", color = OV_YEL, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Bar("CPU", 0.35f, Color(loadCol(35)), "3300MHz")
        Bar("GPU", 0.92f, Color(loadCol(92)), "702MHz")
        Text(buildAnnotatedString {
            withStyle(SpanStyle(color = tx)) { append("BAT ") }; withStyle(SpanStyle(color = OV_YEL)) { append("85%") }
            withStyle(SpanStyle(color = tx)) { append("   TMP ") }; withStyle(SpanStyle(color = OV_YEL)) { append("36") }
            withStyle(SpanStyle(color = tx)) { append("   TCH ") }; withStyle(SpanStyle(color = OV_YEL)) { append("240Hz") }
        }, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun TilePreview() {
    // Pakai view aslinya supaya pratinjau persis sama dengan overlay; diperkecil bila lebih lebar dari dialog
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val maxPx = with(androidx.compose.ui.platform.LocalDensity.current) { maxWidth.toPx() }
        androidx.compose.ui.viewinterop.AndroidView(factory = { ctx ->
            TileOverlayView(ctx).apply { snap = OvSnap(fps = 60, cpu = 35, gpu = 92, batPct = 85, tBat = 32f); touch = "240" }
        }, update = { v ->
            v.bgColor = withAlpha(OverlayPrefs.bg, OverlayPrefs.alpha)
            v.strokeColor = withAlpha(OverlayPrefs.text, 14); v.textColor = OverlayPrefs.text
            v.scale = v.fitScale(maxPx)
            v.requestLayout(); v.invalidate()
        })
    }
}

@Composable
private fun Swatches(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        colors.forEach { c ->
            Box(Modifier.size(34.dp).background(Color(c), CircleShape)
                .border(if (c == selected) 3.dp else 1.dp, if (c == selected) OV_ACC else Color(0x33FFFFFF), CircleShape)
                .clickable { onPick(c) })
        }
    }
}

/** Warna teks, latar, transparansi, dan ukuran overlay. */
@Composable
private fun OverlayColorContent() {
    val ctx = LocalContext.current
    SettingCard("Gaya overlay") {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x12FFFFFF)).clickable { Store.styleDlg = true }.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            T(OverlayPrefs.STYLES[OverlayPrefs.style], 14, Color.White, true, Modifier.weight(1f))
            T("Ubah ›", 13, MUT)
        }
    }
    SettingCard("Warna teks overlay") { Swatches(OverlayPrefs.TEXTS, OverlayPrefs.text) { OverlayPrefs.text = it; OverlayPrefs.save(ctx) } }
    SettingCard("Latar overlay") {
        Swatches(OverlayPrefs.BGS, OverlayPrefs.bg) { OverlayPrefs.bg = it; OverlayPrefs.save(ctx) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { T("Transparan", 13, Color.White); T("${OverlayPrefs.alpha}%", 13, Color.White, true) }
        AccSlider(OverlayPrefs.alpha / 100f, 0.2f..1f, { OverlayPrefs.alpha = (it * 100).toInt().coerceIn(20, 100) }) { OverlayPrefs.save(ctx) }
    }
    SettingCard("Ukuran overlay") {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { T("Besar kecil", 13, Color.White); T("${OverlayPrefs.size}%", 13, Color.White, true) }
        AccSlider(OverlayPrefs.size / 100f, 0.6f..2f, { OverlayPrefs.size = ((it * 100).toInt() / 5 * 5).coerceIn(60, 200) }) { OverlayPrefs.save(ctx) }
        PillButton("Ukuran normal", filled = false) { OverlayPrefs.size = OverlayPrefs.DEF_SIZE; OverlayPrefs.save(ctx) }
    }
}
