# Astra Engine (Android)

Build lewat GitHub: push folder ini, lalu jalankan workflow *Build APK* di tab Actions.

- Akses: Shizuku atau Root (Settings > Akses). Dipakai untuk menulis config ke folder game.
- Beranda: kartu perangkat, target FPS, grafik FPS layar app ini, **Rekam FPS game** (daftar Rekaman + laporan).
- Statistik: gaya Pulse Monitor. Kartu Memori (RAM + ZRAM, ukuran RAM di kotak) yang bisa digeser ke Status CPU (frekuensi tiap inti, beban, governor, grafik), lalu grid Baterai / Jaringan / RAM / Penyimpanan; ketuk kotak untuk rincian. Memori, baterai, jaringan, dan penyimpanan dibaca tanpa Shizuku/Root; Status CPU butuh akses (atau ikut pembacaan perekam saat merekam).
- Config: daftar game, panel Kualitas (Ultra/High/Medium) dan tombol Install (backup otomatis ke .bak).
- Ganti NAMA.PAKET di Detail config dengan nama paket game sebelum Install.

## Wuthering Waves
- Config diimpor dari zip di HP (kartu Wuthering Waves > Impor / Ganti). Satu zip = satu versi (nama file = nama versi, mis. v1.0.zip).
- Susunan zip: `[ 1 ] Flagship/`, `Balanced/[ 1 ] High/`, `Balanced/[ 2 ] Medium/`, atau langsung `ultra/ high/ medium/`, atau file .ini di root.
- File yang dikenali: Engine.ini, DeviceProfiles.ini, Scalability.ini, GameUserSettings.ini (satu file tambahan dari zip ikut dipasang otomatis dan tidak ditampilkan di daftar).
- Tujuan: Android/data/<paket>/files/UE4Game/Client/Client/Saved/Config/Android, ditambah satu folder Engine game untuk file tambahan.
- Setiap file ditulis lewat Shizuku/Root lalu dibaca ulang untuk verifikasi.

### Kotak hasil
Di halaman Wuthering Waves, kotak di bawah tombol Install terisi otomatis: spinner saat memasang, lalu centang/silang per file setelah dibaca ulang dari folder game (OK, tidak ada, kosong, atau isi berbeda). Cek status dan Hapus config juga memakai kotak ini. Kalau gagal, tombol Log menampilkan riwayat dan bisa disalin.

## Rekam FPS game + notifikasi pantauan (dari Pulse Monitor)
- **Rekam FPS**: kartu di Beranda. Buka game, FPS game itu yang diukur (bukan layar app ini). Butuh Shizuku atau Root.
- Sumber FPS: TaskFps (daemon hak shell, Android 14+) -> cadangan SurfaceFlinger timestats -> cadangan `--latency`. Frametime asli per frame dipakai untuk 5% / 1% low, Jank, BigJank (definisi PerfDog).
- **Rekaman** (ikon daftar di kartu): ikon game, nama, tanggal, rata-rata FPS, durasi, grafik mini, chip Min / 5% low / Maks. Ketuk untuk laporan: statistik, grafik, catatan, Bagikan, Simpan CSV (Download), Hapus. Data di `filesDir/records/*.json`.
- **Notifikasi pantauan**: ringkas (persen, nama app di depan + status, arus, daya, suhu) dan diperluas (bilah, Layar Nyala / Mati / Tidur lelap, laju kuras Aktif / Diam). Atur di Settings > Notifikasi pantauan.
- Izin: notifikasi (Android 13+), dan opsional "Tampil di atas aplikasi lain" (jangkar 1x1 agar HyperOS tidak membekukan proses). Izin akses penggunaan diberikan otomatis lewat Shizuku/Root.
- Belum dibawa dari Pulse Monitor: overlay FPS di atas game, kolom resolusi game, suhu/CPU/GPU di rekaman, gambar laporan, penjaga di luar proses (Watchdog).

## Perbaikan: FPS / CPU / GPU overlay tidak lagi beku (disamakan dengan Pulse Monitor)
- Penyebab (dari video): tick Sampler keluar lebih awal bila aplikasi fokus diabaikan (TikTok, SystemUI) atau pengukuran gagal sesaat, sebelum overlay diperbarui. Akibatnya FPS 0 dan angka CPU / GPU menempel.
- Sekarang sensor selalu dibaca dan overlay selalu diperbarui tiap tick. Fokus yang diabaikan tidak menghentikan pengukuran: dipakai layer paling aktif (busiestLayerPkg), atau fokus tetap diukur.
- Gagal ukur bukan 0 FPS: nilai terakhir ditahan (3 tick untuk 0 sungguhan, 6 tick untuk gagal ukur). Aplikasi non-game yang diam menampilkan refresh rate layar, bukan 0.
- Jalur cepat (Sampler.fastTick, 1 proses shell per detik) untuk FPS / CPU / GPU dan frekuensinya, langsung ke overlay, seperti Pulse Monitor.
- Semua perintah shell Sampler dibatasi waktu (3,5 dtk, maks 4 menggantung) lewat Shell.execLimited, supaya dumpsys macet tidak membekukan putaran.
- Belum dikompilasi / diuji di perangkat; cek hasil build GitHub.

## Beranda: Suhu CPU/GPU + Suhu Baterai (Gamebar dihapus)
- Kartu **GAMEBAR** dihapus total (Gamebar.kt, GamebarService, entri manifest, dan semua pemanggilnya).
- Kiri: kartu **BATERAI**: persen di atas (besar), suhu baterai di bawahnya. Selalu tampil tanpa Shizuku/root.
- Kanan: kartu **SUHU CPU** (GPU di bawahnya). Butuh Shizuku/root; tanpa akses tampil "-" dan "Perlu Shizuku/root".
- Belum dikompilasi / diuji di perangkat; cek hasil build GitHub.

## Perbaikan: statistik laporan FPS disamakan dengan grafik, frametime asli
- FPS dihitung dari jumlah frame dalam 1 detik terakhir (`dumpsys SurfaceFlinger --latency`). Game yang dikunci 60 FPS memang terbaca 59-61; stutter terlihat di frametime dan Jank, bukan di angka FPS.
- Min / Maks / Drop tidak lagi memakai despike() (median 3 titik) yang menghapus penurunan 1 detik. Sekarang memakai deret yang sama dengan grafik FPS.
- Drop = detik dengan FPS < 90% dari FPS tengah, atau detik yang memuat Jank / BigJank.
- Garis Frametime di grafik FPS = rata-rata per detik (1000 / FPS). Frame terburuk ada di kartu Frame maks, low, dan Drop. Frame avg = durasi / jumlah frame terbaca.
- Frametime / Jank / 1% & 5% low memakai layer yang sama dengan penghitung FPS.
- Belum dikompilasi / diuji di perangkat.

## Navigasi
- Tab **Baterai** dan **Statistik** dihapus dari bilah navigasi. Sekarang hanya: Beranda, Config, Settings.
- Kode layarnya (BatteryTab, StatsScreen, dll.) masih ada di proyek tapi tidak dipanggil; aman dihapus. Perekaman baterai untuk notifikasi tetap jalan.
- Belum dikompilasi / diuji di perangkat; cek hasil build GitHub.

## Beranda: kartu FPS dan Rekam diperkecil
- FPS 32 ke 24, frametime 24 ke 18, grafik 56 ke 36 dp, padding kartu 16 ke 12 dp, toggle Overlay lebih kecil (Toggle compact), kartu Rekam FPS lebih pendek (padding, teks, tombol).
- Belum dikompilasi / diuji di perangkat; cek hasil build GitHub.

## Bilah navigasi diperkecil
- Padding, tinggi item, ikon (24 ke 20 dp), sudut, dan jarak bawah dikurangi; NAV_SPACE 130 ke 100 dp; pudar gelap di bawah bilah 150 ke 110 dp.
- Belum dikompilasi / diuji di perangkat; cek hasil build GitHub.

## Bilah navigasi dirapatkan
- Bilah tidak lagi melebar penuh: tiap tab 76 dp, jarak antar tab 2 dp, bilah di tengah bawah.
- Belum dikompilasi / diuji di perangkat; cek hasil build GitHub.

## Config per chipset (v1.3 beta)
- Config v1.3 beta ikut di APK (assets/nx2.dat, terenkripsi seperti nx.dat). v1.2 tetap ada; v1.3 beta jadi pilihan awal karena urutan nama.
- Zip boleh berisi folder Mediatek/ dan Snapdragon/ (masing-masing Ultra, High, Medium). Aplikasi membaca chipset HP (detectChipset di Device.kt) dan otomatis memakai folder yang cocok. Baris "Chipset" hanya menampilkan chipset HP itu (terkunci).
- Chipset tidak terdeteksi, atau config tidak punya folder untuk chipset itu: baris Chipset menampilkan semua pilihan untuk dipilih manual.
- Zip lama tanpa folder chipset (Flagship / Balanced atau tanpa mode) tetap bekerja seperti sebelumnya.
- Ultra tidak punya DeviceProfiles.ini (sama seperti v1.2).
- Belum dikompilasi / diuji di perangkat; cek hasil build GitHub.

## Ganti nama jadi Astra Engine
- Nama aplikasi (label di launcher), judul kotak Beranda (ASTRA ENGINE), judul notifikasi, laporan kesehatan, log, gambar/CSV laporan, dan folder keluaran (Download/AstraEngine, Pictures/AstraEngine) diganti.
- Tidak diubah: nama paket (com.nexnon.engine), nama aksi internal, skrip penjaga, dan nama tema. Mengganti nama paket akan membuat aplikasi terpasang sebagai aplikasi baru dan data lama tidak terbawa.
- Ikon aplikasi, logo splash (animasi buka), ikon tombol Pengaturan Cepat, dan ikon notifikasi diganti dari huruf N jadi huruf A (vektor + PNG ic_stat_nexnon dan ic_notif_large).
- Belum dikompilasi / diuji di perangkat; cek hasil build GitHub.
